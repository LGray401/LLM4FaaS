# Given the functional description and the provided source code, we need to implement the `function.py` file to handle the "MORNING PLAN", "LEAVE HOME PLAN", and "MOVIE PLAN" scenarios. The main function in `function.py` will execute these plans by interacting with the actuators in the home.
# 
# Here is how the `function.py` can be implemented:

# functions/function.py

from home.home_plan import home_plan, get_room_actuators
from home.actuator import Curtain, CoffeeMachine, Door, Light

def execute_morning_plan(home):
    print("Executing Morning Plan: 拉开窗帘，制作咖啡")
    living_room = get_room_actuators(home, "LivingRoom")
    kitchen = get_room_actuators(home, "Kitchen")

    for actuator in living_room:
        if isinstance(actuator, Curtain):
            actuator.turn_on()  # 拉开窗帘

    for actuator in kitchen:
        if isinstance(actuator, CoffeeMachine):
            actuator.turn_on()
            actuator.make_coffee("Espresso")  # 制作咖啡

def execute_leave_home_plan(home):
    print("Executing Leave Home Plan: 关闭入户门，关闭灯")
    living_room = get_room_actuators(home, "LivingRoom")

    for actuator in living_room:
        if isinstance(actuator, Door):
            actuator.turn_off()  # 关闭入户门
        if isinstance(actuator, Light):
            actuator.turn_off()  # 关闭灯

def execute_movie_plan(home):
    print("Executing Movie Plan: 关闭窗帘，调暗灯光")
    living_room = get_room_actuators(home, "LivingRoom")

    for actuator in living_room:
        if isinstance(actuator, Curtain):
            actuator.turn_off()  # 关闭窗帘
        if isinstance(actuator, Light):
            actuator.turn_on()
            actuator.set_brightness_level("low")  # 调暗灯光

def main():
    home = home_plan()
    
    # Execute different plans
    execute_morning_plan(home)
    execute_leave_home_plan(home)
    execute_movie_plan(home)

if __name__ == "__main__":
    main()