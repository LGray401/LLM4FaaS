# Based on your provided functional description and source code, I will create a `function.py` file that includes the main functions for your smart home project. The main function will implement the MORNING PLAN, LEAVE HOME PLAN, and MOVIE PLAN as described.
# 
# Here is the `function.py` file located in the `functions` folder:
# 
# ### function.py

from home.home_plan import home_plan, get_all_actuators

def morning_plan(home):
    print("Executing MORNING PLAN:")
    curtains = get_all_actuators(home, "Curtain")
    coffee_machines = get_all_actuators(home, "CoffeeMachine")
    
    for curtain in curtains:
        curtain.turn_on()
    
    for coffee_machine in coffee_machines:
        coffee_machine.turn_on()
        coffee_machine.make_coffee("regular")

def leave_home_plan(home):
    print("Executing LEAVE HOME PLAN:")
    doors = get_all_actuators(home, "Door")
    lights = get_all_actuators(home, "Light")
    
    for door in doors:
        door.turn_off()
    
    for light in lights:
        light.turn_off()

def movie_plan(home):
    print("Executing MOVIE PLAN:")
    curtains = get_all_actuators(home, "Curtain")
    lights = get_all_actuators(home, "Light")
    
    for curtain in curtains:
        curtain.turn_off()
    
    for light in lights:
        light.turn_on()
        light.set_brightness_level("low")

def main():
    home = home_plan()
    print("Home setup completed.")
    
    # Execute different plans
    morning_plan(home)
    leave_home_plan(home)
    movie_plan(home)

if __name__ == "__main__":
    main()