# Given the functional requirements and the provided source code, we can create the `function.py` file with the main function to manage the different home plans: "MORNING PLAN", "LEAVE HOME PLAN", and "MOVIE PLAN".
# 
# Here's the implementation of `function.py`:

# function.py

from home.home_plan import home_plan, print_home_plan, get_room_actuators

def main():
    home = home_plan()
    print_home_plan(home)

    def morning_plan():
        print("\nExecuting MORNING PLAN...")
        living_room_actuators = get_room_actuators(home, "LivingRoom")
        kitchen_actuators = get_room_actuators(home, "Kitchen")

        # 拉开窗帘
        for actuator in living_room_actuators:
            if actuator.actuator_type == "Curtain":
                actuator.turn_on()

        # 制作咖啡
        for actuator in kitchen_actuators:
            if actuator.actuator_type == "CoffeeMachine":
                actuator.turn_on()
                actuator.make_coffee("Espresso")  # Assume making an Espresso

    def leave_home_plan():
        print("\nExecuting LEAVE HOME PLAN...")
        living_room_actuators = get_room_actuators(home, "LivingRoom")

        # 关闭入户门
        for actuator in living_room_actuators:
            if actuator.actuator_type == "Door":
                actuator.turn_off()

        # 关闭灯
        for actuator in living_room_actuators:
            if actuator.actuator_type == "Light":
                actuator.turn_off()

    def movie_plan():
        print("\nExecuting MOVIE PLAN...")
        living_room_actuators = get_room_actuators(home, "LivingRoom")

        # 关闭窗帘
        for actuator in living_room_actuators:
            if actuator.actuator_type == "Curtain":
                actuator.turn_off()

        # 调暗灯光
        for actuator in living_room_actuators:
            if actuator.actuator_type == "Light":
                actuator.turn_on()
                actuator.set_brightness_level("low")

    # Execute the plans
    morning_plan()
    leave_home_plan()
    movie_plan()

if __name__ == "__main__":
    main()