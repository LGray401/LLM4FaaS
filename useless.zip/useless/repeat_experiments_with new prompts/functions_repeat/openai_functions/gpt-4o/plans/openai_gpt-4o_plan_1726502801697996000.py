# Sure, based on your functional description, I will create a `function.py` file with a main function to handle the different plans: MORNING PLAN, LEAVE HOME PLAN, and MOVIE PLAN. 
# 
# Here's the `function.py` file:

# function.py

from home.home_plan import home_plan, get_room_actuators
from home.actuator import Curtain, CoffeeMachine, Door, Light

def morning_plan(home):
    # 拉开窗帘，制作咖啡
    curtain_list = get_room_actuators(home, "LivingRoom")
    for curtain in curtain_list:
        if isinstance(curtain, Curtain):
            curtain.turn_on()
    
    coffee_machines = get_room_actuators(home, "Kitchen")
    for coffee_machine in coffee_machines:
        if isinstance(coffee_machine, CoffeeMachine):
            coffee_machine.turn_on()
            coffee_machine.make_coffee("Espresso")

def leave_home_plan(home):
    # 关闭入户门，关闭灯
    doors = get_room_actuators(home, "LivingRoom")
    for door in doors:
        if isinstance(door, Door):
            door.turn_off()
    
    lights = get_room_actuators(home, "LivingRoom")
    for light in lights:
        if isinstance(light, Light):
            light.turn_off()

def movie_plan(home):
    # 关闭窗帘，调暗灯光
    curtain_list = get_room_actuators(home, "LivingRoom")
    for curtain in curtain_list:
        if isinstance(curtain, Curtain):
            curtain.turn_off()

    lights = get_room_actuators(home, "LivingRoom")
    for light in lights:
        if isinstance(light, Light):
            light.turn_on()
            light.set_brightness_level("low")

def main():
    home = home_plan()
    
    # Execute plans based on user choice
    user_choice = input("Choose a plan (morning/leave_home/movie): ").strip().lower()
    
    if user_choice == "morning":
        morning_plan(home)
    elif user_choice == "leave_home":
        leave_home_plan(home)
    elif user_choice == "movie":
        movie_plan(home)
    else:
        print("Invalid choice.")

if __name__ == "__main__":
    main()