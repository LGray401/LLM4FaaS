# Sure, based on your provided functional description and source code files, I'll create a `function.py` file that will implement the main function to carry out the MORNING PLAN, LEAVE HOME PLAN, and MOVIE PLAN.
# 
# Here's the `function.py` content:

# function.py
from home.home_plan import home_plan, get_room_actuators
from home.actuator import Curtain, CoffeeMachine, Door, Light

def morning_plan(home):
    print("Executing MORNING PLAN...")
    living_room_curtains = get_room_actuators(home, "LivingRoom")
    kitchen_coffee_machine = get_room_actuators(home, "Kitchen")

    # 拉开窗帘 (Open Curtains)
    for actuator in living_room_curtains:
        if isinstance(actuator, Curtain):
            actuator.turn_on()

    # 制作咖啡 (Make Coffee)
    for actuator in kitchen_coffee_machine:
        if isinstance(actuator, CoffeeMachine):
            actuator.turn_on()
            actuator.make_coffee("Espresso")  # Making an Espresso coffee

def leave_home_plan(home):
    print("Executing LEAVE HOME PLAN...")
    living_room_actuators = get_room_actuators(home, "LivingRoom")

    # 关闭入户门 (Close Door)
    for actuator in living_room_actuators:
        if isinstance(actuator, Door):
            actuator.turn_off()

    # 关闭灯 (Turn off Lights)
    for actuator in living_room_actuators:
        if isinstance(actuator, Light):
            actuator.turn_off()

def movie_plan(home):
    print("Executing MOVIE PLAN...")
    living_room_actuators = get_room_actuators(home, "LivingRoom")

    # 关闭窗帘 (Close Curtains)
    for actuator in living_room_actuators:
        if isinstance(actuator, Curtain):
            actuator.turn_off()

    # 调暗灯光 (Dim Lights)
    for actuator in living_room_actuators:
        if isinstance(actuator, Light):
            actuator.turn_on()
            actuator.set_brightness_level("low")

def main():
    home = home_plan()
    print_home_plan(home)

    # Execute plans
    morning_plan(home)
    leave_home_plan(home)
    movie_plan(home)

if __name__ == "__main__":
    main()