# Sure, based on the provided functional description and source code, I'll create a `function.py` file that implements the main function for the specified plans: MORNING PLAN, LEAVE HOME PLAN, and MOVIE PLAN.
# 
# Here's the `function.py` file:
# 
# ### `functions/function.py`

from home.home_plan import home_plan, get_all_actuators, get_room_actuators

def morning_plan(home):
    # 拉开窗帘，制作咖啡
    curtains = get_all_actuators(home, "Curtain")
    coffee_machines = get_all_actuators(home, "CoffeeMachine")
    
    for curtain in curtains:
        curtain.turn_on()  # 拉开窗帘
    
    for coffee_machine in coffee_machines:
        coffee_machine.turn_on()
        coffee_machine.make_coffee("Espresso")  # 制作咖啡


def leave_home_plan(home):
    # 关闭入户门，关闭灯
    doors = get_all_actuators(home, "Door")
    lights = get_all_actuators(home, "Light")
    
    for door in doors:
        door.turn_off()  # 关闭入户门
    
    for light in lights:
        light.turn_off()  # 关闭灯


def movie_plan(home):
    # 关闭窗帘，调暗灯光
    curtains = get_all_actuators(home, "Curtain")
    lights = get_all_actuators(home, "Light")
    
    for curtain in curtains:
        curtain.turn_off()  # 关闭窗帘
    
    for light in lights:
        light.turn_on()  # Ensure the light is on before setting brightness
        light.set_brightness_level("low")  # 调暗灯光


def main():
    home = home_plan()

    print("Executing Morning Plan")
    morning_plan(home)

    print("\nExecuting Leave Home Plan")
    leave_home_plan(home)

    print("\nExecuting Movie Plan")
    movie_plan(home)


if __name__ == "__main__":
    main()