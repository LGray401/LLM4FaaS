# Here's the `function.py` file based on your functional description and the provided source code:

from home.home_plan import home_plan, get_room_actuators
from home.actuator import Curtain, CoffeeMachine, Door, Light

def morning_plan(home):
    print("Executing Morning Plan...")
    living_room_actuators = get_room_actuators(home, "LivingRoom")
    bedroom_actuators = get_room_actuators(home, "Bedroom")
    kitchen_actuators = get_room_actuators(home, "Kitchen")
    
    # 拉开窗帘 (Open Curtain)
    for actuator in living_room_actuators + bedroom_actuators:
        if isinstance(actuator, Curtain):
            actuator.turn_on()

    # 制作咖啡 (Make Coffee)
    for actuator in kitchen_actuators:
        if isinstance(actuator, CoffeeMachine):
            actuator.turn_on()
            actuator.make_coffee("Espresso")

def leave_home_plan(home):
    print("Executing Leave Home Plan...")
    living_room_actuators = get_room_actuators(home, "LivingRoom")
    bedroom_actuators = get_room_actuators(home, "Bedroom")
    kitchen_actuators = get_room_actuators(home, "Kitchen")
    bathroom_actuators = get_room_actuators(home, "Bathroom")
    balcony_actuators = get_room_actuators(home, "Balcony")
    
    # 关闭入户门 (Close Door)
    for room_actuators in [living_room_actuators, bedroom_actuators, kitchen_actuators, bathroom_actuators, balcony_actuators]:
        for actuator in room_actuators:
            if isinstance(actuator, Door):
                actuator.turn_off()
    
    # 关闭灯 (Turn off Lights)
    for room_actuators in [living_room_actuators, bedroom_actuators, kitchen_actuators, bathroom_actuators]:
        for actuator in room_actuators:
            if isinstance(actuator, Light):
                actuator.turn_off()

def movie_plan(home):
    print("Executing Movie Plan...")
    living_room_actuators = get_room_actuators(home, "LivingRoom")

    # 关闭窗帘 (Close Curtain)
    for actuator in living_room_actuators:
        if isinstance(actuator, Curtain):
            actuator.turn_off()

    # 调暗灯光 (Dim Lights)
    for actuator in living_room_actuators:
        if isinstance(actuator, Light):
            actuator.turn_on()
            actuator.set_brightness_level("low")

def main():
    home = home_plan()
    
    # Execute plans here
    morning_plan(home)
    leave_home_plan(home)
    movie_plan(home)

if __name__ == "__main__":
    main()