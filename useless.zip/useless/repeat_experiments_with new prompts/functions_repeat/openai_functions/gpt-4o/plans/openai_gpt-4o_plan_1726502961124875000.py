# Based on your provided functional description and the source code, I'll create the `function.py` file located in the `functions` folder. This file will contain the main function to execute the specified home plans: MORNING PLAN, LEAVE HOME PLAN, and MOVIE PLAN.
# 
# Here is the `function.py`:

# functions/function.py

from home.home_plan import home_plan, get_room_actuators
from home.actuator import Curtain, CoffeeMachine, Door, Light

def execute_morning_plan(home):
    print("Executing MORNING PLAN:")
    living_room_actuators = get_room_actuators(home, "LivingRoom")
    kitchen_actuators = get_room_actuators(home, "Kitchen")
    
    for actuator in living_room_actuators:
        if isinstance(actuator, Curtain):
            actuator.turn_on()
            print("Curtains in the living room are now open.")
    
    for actuator in kitchen_actuators:
        if isinstance(actuator, CoffeeMachine):
            actuator.turn_on()
            actuator.make_coffee("Espresso")
            print("Coffee is being made in the kitchen.")

def execute_leave_home_plan(home):
    print("Executing LEAVE HOME PLAN:")
    living_room_actuators = get_room_actuators(home, "LivingRoom")
    
    for actuator in living_room_actuators:
        if isinstance(actuator, Door):
            actuator.turn_off()
            actuator.lock()
            print("Front door is now closed and locked.")
        if isinstance(actuator, Light):
            actuator.turn_off()
            print("Lights in the living room are turned off.")

def execute_movie_plan(home):
    print("Executing MOVIE PLAN:")
    living_room_actuators = get_room_actuators(home, "LivingRoom")
    
    for actuator in living_room_actuators:
        if isinstance(actuator, Curtain):
            actuator.turn_off()
            print("Curtains in the living room are now closed.")
        if isinstance(actuator, Light):
            actuator.turn_on()
            actuator.set_brightness_level("low")
            print("Lights in the living room are dimmed.")

def main():
    home = home_plan()
    execute_morning_plan(home)
    execute_leave_home_plan(home)
    execute_movie_plan(home)

if __name__ == "__main__":
    main()