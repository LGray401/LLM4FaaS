# Sure, here is the `function.py` file based on your functional description. This file will define a main function that can execute the different home plans: "MORNING PLAN", "LEAVE HOME PLAN", and "MOVIE PLAN".

# function.py
from home.home_plan import home_plan, get_all_actuators
from home.actuator import Curtain, CoffeeMachine, Door, Light

def morning_plan(home):
    # 拉开窗帘，制作咖啡
    curtains = get_all_actuators(home, "Curtain")
    coffee_machines = get_all_actuators(home, "CoffeeMachine")
    
    for curtain in curtains:
        curtain.turn_on()
    
    for coffee_machine in coffee_machines:
        coffee_machine.turn_on()
        coffee_machine.make_coffee("Espresso")  # Example coffee type

def leave_home_plan(home):
    # 关闭入户门，关闭灯
    doors = get_all_actuators(home, "Door")
    lights = get_all_actuators(home, "Light")
    
    for door in doors:
        door.turn_off()
    
    for light in lights:
        light.turn_off()

def movie_plan(home):
    # 关闭窗帘，调暗灯光
    curtains = get_all_actuators(home, "Curtain")
    lights = get_all_actuators(home, "Light")
    
    for curtain in curtains:
        curtain.turn_off()
    
    for light in lights:
        light.turn_on()
        light.set_brightness_level("low")

def main(plan):
    home = home_plan()
    
    if plan == "MORNING PLAN":
        morning_plan(home)
    elif plan == "LEAVE HOME PLAN":
        leave_home_plan(home)
    elif plan == "MOVIE PLAN":
        movie_plan(home)
    else:
        print(f"Plan {plan} is not recognized.")

if __name__ == "__main__":
    # Example usage
    main("MORNING PLAN")
    main("LEAVE HOME PLAN")
    main("MOVIE PLAN")