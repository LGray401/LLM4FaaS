# Based on the provided functional description and existing source code, I'll create a `function.py` file located in the `functions` folder. The `function.py` file will contain the main function that integrates and controls the behavior of your smart home system.
# 
# Here's the `function.py` file:

# functions/function.py
import time
from home.home_plan import home_plan, get_all_sensors, get_all_actuators
from home.config import TEMP_CHANGE_DURATION_WINDOW, TEMP_LOW, LIGHT_INTENSITY_HIGH

def main():
    # Initialize the home plan
    home = home_plan()

    # Get all necessary sensors and actuators
    indoor_temp_sensors = get_all_sensors(home, "IndoorTemperature")
    light_sensors = get_all_sensors(home, "LightIntensive")
    ac_units = get_all_actuators(home, "AC")
    windows = get_all_actuators(home, "Window")
    lights = get_all_actuators(home, "Light")

    # Main loop for checking conditions
    while True:
        # Check indoor temperature and control AC and windows
        for sensor in indoor_temp_sensors:
            sensor.turn_on()
            temp_reading = sensor.get_reading()
            if temp_reading is not None:
                for ac in ac_units:
                    if ac.room_name == sensor.room_name:
                        ac.set_target_temperature(23)
                        ac.adjust_temperature(temp_reading)
                        if ac.get_status() == "on":
                            for window in windows:
                                if window.room_name == sensor.room_name:
                                    window.turn_off()  # Close the window if the AC is on
                                    print(f"Window in {window.room_name} is closed because AC is on.")
        
        # Check light intensity and control lights
        for sensor in light_sensors:
            sensor.turn_on()
            light_reading = sensor.get_reading()
            if light_reading is not None and light_reading > LIGHT_INTENSITY_HIGH:
                for light in lights:
                    if light.room_name == sensor.room_name:
                        light.turn_off()  # Turn off the light if light intensity is too high
                        print(f"Light in {light.room_name} is turned off due to high light intensity.")
        
        # Sleep for the configured duration before the next check
        time.sleep(TEMP_CHANGE_DURATION_WINDOW)

if __name__ == "__main__":
    main()