from home.home_plan import home_plan, get_room_sensors, get_room_actuators, get_all_sensors, \
    get_all_actuators, get_room
from home.sensor import IndoorTemperatureSensor
from home.actuator import AC, Light, Window
from home.config import TEMP_HIGH, LIGHT_INTENSITY_HIGH

# Example invocation
# home_plan()
# get_room_sensors(home_plan(), "LivingRoom")
# get_room_actuators(home_plan(), "LivingRoom")
# get_all_sensors(home_plan(), "IndoorTemperature")
# get_all_actuators(home_plan(), "Light")


def main():
    home = home_plan()

    # Function 1: 空调开启时关闭窗户
    living_room = get_room(home, "LivingRoom")
    if living_room is not None:
        ac = get_room_actuators(home, "LivingRoom")
        windows = get_room_actuators(home, "LivingRoom")

        if ac and windows:
            for ac_unit in ac:
                if ac_unit.actuator_type == "AC" and ac_unit.status == "on":
                    for window in windows:
                        if window.actuator_type == "Window":
                            window.turn_off()
                            print(f"Window in LivingRoom is closed.")

    # Function 2: 当温度低于23度时，关闭空调。
    living_room = get_room(home, "LivingRoom")
    if living_room is not None:
        ac = get_room_actuators(home, "LivingRoom")
        indoor_temp_sensors = get_room_sensors(home, "LivingRoom")

        if ac and indoor_temp_sensors:
            for temp_sensor in indoor_temp_sensors:
                if temp_sensor.sensor_type == "IndoorTemperature":
                    temp_reading = temp_sensor.get_reading()
                    if temp_reading is not None:
                        for ac_unit in ac:
                            if ac_unit.actuator_type == "AC" and temp_reading < TEMP_HIGH:
                                ac_unit.turn_off()
                                print(f"AC in LivingRoom is turned off.")

    # Function 3: 当光照过强时，调暗灯光或关闭灯光
    living_room = get_room(home, "LivingRoom")
    if living_room is not None:
        lights = get_room_actuators(home, "LivingRoom")
        light_intensity_sensors = get_room_sensors(home, "LivingRoom")

        if lights and light_intensity_sensors:
            for light_sensor in light_intensity_sensors:
                if light_sensor.sensor_type == "LightIntensive":
                    light_reading = light_sensor.get_reading()
                    if light_reading is not None:
                        for light_unit in lights:
                            if light_unit.actuator_type == "Light":
                                if light_reading > LIGHT_INTENSITY_HIGH:
                                    light_unit.turn_off()
                                    print(f"Light in LivingRoom is turned off.")
                                else:
                                    light_unit.set_brightness_level("low")
                                    print(f"Light in LivingRoom is set to low brightness.")
                                    

if __name__ == '__main__':
    main()
