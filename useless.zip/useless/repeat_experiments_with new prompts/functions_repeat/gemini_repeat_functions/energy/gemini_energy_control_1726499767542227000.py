from home.home_plan import get_room, get_room_sensors, get_room_actuators, get_all_sensors, get_all_actuators
from home.sensor import IndoorTemperatureSensor, HumiditySensor, LightIntensiveSensor
from home.actuator import AC, Light, Window, Curtain
from home.config import TEMP_LOW, TEMP_HIGH, LIGHT_INTENSITY_HIGH, LIGHT_INTENSITY_LOW
from home.logger_config import logger


def main():
    home = home_plan()

    # Function 1: 空调开启时关闭窗户
    for ac in get_all_actuators(home, "AC"):
        if ac.get_status() == "on":
            for window in get_all_actuators(home, "Window"):
                if window.room_name == ac.room_name:
                    window.turn_off()
                    logger.info(f"Close window in {ac.room_name} because AC is on")

    # Function 2: 当温度低于23度时，关闭空调
    for ac in get_all_actuators(home, "AC"):
        for temperature_sensor in get_all_sensors(home, "IndoorTemperature"):
            if temperature_sensor.room_name == ac.room_name:
                temperature_reading = temperature_sensor.get_reading()
                if temperature_reading is not None and temperature_reading < TEMP_LOW:
                    ac.turn_off()
                    logger.info(f"Turn off AC in {ac.room_name} because temperature is below {TEMP_LOW}°C")

    # Function 3: 当光照过强时，调暗灯光或关闭灯光
    for light in get_all_actuators(home, "Light"):
        for light_sensor in get_all_sensors(home, "LightIntensive"):
            if light_sensor.room_name == light.room_name:
                light_reading = light_sensor.get_reading()
                if light_reading is not None and light_reading > LIGHT_INTENSITY_HIGH:
                    if light.get_status() == "on":
                        light.set_brightness_level("low")
                        logger.info(f"Dim the light in {light.room_name} because light intensity is high")
                    else:
                        light.turn_off()
                        logger.info(f"Turn off light in {light.room_name} because light intensity is high")


if __name__ == "__main__":
    main()
