from home.home_plan import home_plan, get_room_sensors, get_room_actuators, get_all_sensors, get_all_actuators
from home.config import TEMP_LOW, TEMP_HIGH, LIGHT_INTENSITY_HIGH
from home.logger_config import logger

def main():
    home = home_plan()

    # 1. 空调开启时关闭窗户
    # Find all ACs in the home
    acs = get_all_actuators(home, "AC")
    # Find all Windows in the home
    windows = get_all_actuators(home, "Window")

    for ac in acs:
        if ac.get_status() == "on":
            for window in windows:
                if window.get_status() == "on":
                    window.turn_off()
                    logger.info(f"Turning off {window.id} because AC {ac.id} is on.")
                    print(f"Turning off {window.id} because AC {ac.id} is on.")

    # 2. 当温度低于23度时，关闭空调。
    # Find all indoor temperature sensors
    temp_sensors = get_all_sensors(home, "IndoorTemperature")
    # Find all ACs in the home
    acs = get_all_actuators(home, "AC")

    for temp_sensor in temp_sensors:
        # Get the temperature reading
        temp = temp_sensor.get_reading()
        if temp is not None:
            if temp < TEMP_LOW:
                for ac in acs:
                    if ac.get_status() == "on":
                        ac.turn_off()
                        logger.info(f"Turning off AC {ac.id} because temperature is below {TEMP_LOW}°C.")
                        print(f"Turning off AC {ac.id} because temperature is below {TEMP_LOW}°C.")

    # 3. 当光照过强时，调暗灯光或关闭灯光。
    # Find all light intensity sensors
    light_sensors = get_all_sensors(home, "LightIntensive")
    # Find all lights in the home
    lights = get_all_actuators(home, "Light")

    for light_sensor in light_sensors:
        # Get the light intensity reading
        light_intensity = light_sensor.get_reading()
        if light_intensity is not None:
            if light_intensity > LIGHT_INTENSITY_HIGH:
                for light in lights:
                    if light.get_status() == "on":
                        light.set_brightness_level("low")
                        logger.info(f"Setting {light.id} brightness level to low because light intensity is high.")
                        print(f"Setting {light.id} brightness level to low because light intensity is high.")

if __name__ == "__main__":
    main()

# **Explanation:**

# 1. **Import necessary modules:**
#    - `home.home_plan`: Provides functions to work with the home plan (rooms, sensors, actuators).
#    - `home.config`: Contains configuration values like temperature thresholds.
#    - `home.logger_config`: Provides logging functionality.

# 2. **`main()` function:**
#    - Calls `home_plan()` to get the home structure.
#    - **Rule 1:**
#       - Gets all ACs and Windows using `get_all_actuators()`.
#       - Iterates through ACs and checks if they are on.
#       - If an AC is on, iterates through windows and turns off any that are on.
#    - **Rule 2:**
#       - Gets all indoor temperature sensors using `get_all_sensors()`.
#       - Iterates through temperature sensors, gets readings, and turns off ACs if the temperature is below `TEMP_LOW`.
#    - **Rule 3:**
#       - Gets all light intensity sensors and lights.
#       - Iterates through light sensors, gets readings, and sets the brightness of lights to "low" if the intensity is above `LIGHT_INTENSITY_HIGH`.

# 3. **Logging:**
#    - The code uses the `logger` object to log messages to a file. You can customize the logging configuration in `home/logger_config.py`.

# **How to run:**

# 1. Make sure you have the `home` folder with the source code files `sensor.py`, `actuator.py`, `home_plan.py`, and `config.py`.
# 2. Create a `functions` folder.
# 3. Save the above code as `function.py` in the `functions` folder.
# 4. Run the script: `python functions/function.py`

# **Note:** This code simulates the interaction between sensors, actuators, and rules. It doesn't interact with any real smart home devices. You would need to integrate it with a specific smart home platform or use libraries like `paho-mqtt` for actual device communication.
