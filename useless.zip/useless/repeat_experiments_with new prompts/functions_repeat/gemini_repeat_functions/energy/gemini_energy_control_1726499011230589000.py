from home.home_plan import get_all_sensors, get_all_actuators, get_room_actuators
from home.config import TEMP_LOW, TEMP_HIGH, HUMIDITY_LOW, HUMIDITY_HIGH, LIGHT_INTENSITY_LOW, LIGHT_INTENSITY_HIGH
from home.logger_config import logger


def main():
    """
    Main function for the smart home system.
    """
    home = home_plan()

    while True:
        # Get sensor readings
        temperature_sensors = get_all_sensors(home, "IndoorTemperature")
        for temperature_sensor in temperature_sensors:
            temperature_sensor.turn_on()
            temperature_reading = temperature_sensor.get_reading()
            if temperature_reading is not None:
                # Adjust AC/Heater based on temperature
                if temperature_reading < TEMP_LOW:
                    # Turn on the heater
                    heaters = get_all_actuators(home, "Heater")
                    for heater in heaters:
                        heater.turn_on()
                        heater.set_target_temperature(TEMP_HIGH)  # Set target temperature to comfortable level
                elif temperature_reading > TEMP_HIGH:
                    # Turn on the AC
                    acs = get_all_actuators(home, "AC")
                    for ac in acs:
                        ac.turn_on()
                        ac.set_target_temperature(TEMP_LOW)  # Set target temperature to comfortable level
                else:
                    # Turn off AC and heater if temperature is within range
                    heaters = get_all_actuators(home, "Heater")
                    for heater in heaters:
                        heater.turn_off()
                    acs = get_all_actuators(home, "AC")
                    for ac in acs:
                        ac.turn_off()
            else:
                print("Could not get temperature reading")
                logger.warning("Could not get temperature reading")

        # Get light intensity readings
        light_sensors = get_all_sensors(home, "LightIntensive")
        for light_sensor in light_sensors:
            light_sensor.turn_on()
            light_intensity_reading = light_sensor.get_reading()
            if light_intensity_reading is not None:
                # Adjust lights based on light intensity
                if light_intensity_reading > LIGHT_INTENSITY_HIGH:
                    # Dim or turn off lights
                    lights = get_all_actuators(home, "Light")
                    for light in lights:
                        light.turn_on()
                        light.set_brightness_level("low")  # Set brightness level to low
                else:
                    # Keep lights at normal brightness
                    lights = get_all_actuators(home, "Light")
                    for light in lights:
                        light.turn_on()
                        light.set_brightness_level("medium")  # Set brightness level to medium
            else:
                print("Could not get light intensity reading")
                logger.warning("Could not get light intensity reading")

        # Get humidity readings
        humidity_sensors = get_all_sensors(home, "Humidity")
        for humidity_sensor in humidity_sensors:
            humidity_sensor.turn_on()
            humidity_reading = humidity_sensor.get_reading()
            if humidity_reading is not None:
                # Adjust humidifier/dehumidifier based on humidity
                if humidity_reading < HUMIDITY_LOW:
                    # Turn on the humidifier
                    humidifiers = get_all_actuators(home, "Humidifier")
                    for humidifier in humidifiers:
                        humidifier.increase_humidity()
                elif humidity_reading > HUMIDITY_HIGH:
                    # Turn on the dehumidifier
                    # (Assume dehumidifier is implemented as a separate actuator type)
                    pass  # Placeholder for dehumidifier functionality
                else:
                    # Turn off humidifier and dehumidifier if humidity is within range
                    humidifiers = get_all_actuators(home, "Humidifier")
                    for humidifier in humidifiers:
                        pass  # Placeholder for stopping dehumidifier functionality
            else:
                print("Could not get humidity reading")
                logger.warning("Could not get humidity reading")

        # Get smoke sensor readings
        smoke_sensors = get_all_sensors(home, "Smoke")
        for smoke_sensor in smoke_sensors:
            smoke_sensor.turn_on()
            smoke_reading = smoke_sensor.get_reading()
            if smoke_reading is not None:
                # Send a notification if smoke is detected
                if smoke_reading > 0:
                    # Get notification sender actuator
                    notification_senders = get_all_actuators(home, "NotificationSender")
                    for notification_sender in notification_senders:
                        notification_sender.notification_sender("Smoke detected!")
            else:
                print("Could not get smoke sensor reading")
                logger.warning("Could not get smoke sensor reading")

        # Get outdoor temperature readings
        outdoor_temperature_sensors = get_all_sensors(home, "OutdoorTemperature")
        for outdoor_temperature_sensor in outdoor_temperature_sensors:
            outdoor_temperature_sensor.turn_on()
            outdoor_temperature_reading = outdoor_temperature_sensor.get_reading()
            if outdoor_temperature_reading is not None:
                # Open/close windows based on temperature difference
                if outdoor_temperature_reading < TEMP_LOW and get_all_actuators(home, "AC") == []:
                    # Open the windows
                    windows = get_all_actuators(home, "Window")
                    for window in windows:
                        window.turn_on()
                elif outdoor_temperature_reading > TEMP_HIGH:
                    # Close the windows
                    windows = get_all_actuators(home, "Window")
                    for window in windows:
                        window.turn_off()
                else:
                    pass
            else:
                print("Could not get outdoor temperature reading")
                logger.warning("Could not get outdoor temperature reading")

        # Sleep for a short duration to avoid excessive checking
        time.sleep(1)

    # Loop continues indefinitely until the program is terminated


if __name__ == "__main__":
    main()

# **Explanation:**

# 1. **Imports:** Imports necessary modules like `get_all_sensors`, `get_all_actuators`, `get_room_actuators`, `TEMP_LOW`, `TEMP_HIGH`, `HUMIDITY_LOW`, `HUMIDITY_HIGH`, `LIGHT_INTENSITY_LOW`, `LIGHT_INTENSITY_HIGH`, and `logger`.
# 2. **`main` function:** Contains the main logic of the smart home system.
# 3. **Get Sensor Readings:** Iterates through sensors of each type (temperature, light intensity, humidity, smoke, and outdoor temperature) and retrieves readings.
# 4. **Logic Based on Readings:**
#     - **Temperature:** If the temperature is below `TEMP_LOW`, turn on the heater. If above `TEMP_HIGH`, turn on the AC. If within range, turn off both.
#     - **Light Intensity:** If light intensity is above `LIGHT_INTENSITY_HIGH`, dim or turn off the lights. Otherwise, keep lights at normal brightness.
#     - **Humidity:** If humidity is below `HUMIDITY_LOW`, turn on the humidifier. If above `HUMIDITY_HIGH`, turn on the dehumidifier. If within range, turn off both.
#     - **Smoke:** If smoke is detected, send a notification.
#     - **Outdoor Temperature:** If the outdoor temperature is below `TEMP_LOW` and there is no AC, open the windows. If above `TEMP_HIGH`, close the windows.
# 5. **Sleep:** Pauses the program for 1 second to avoid constant checking.
# 6. **Infinite Loop:** The `while True` loop ensures the program runs indefinitely, monitoring the sensors and adjusting actuators accordingly.

# **Note:** The code assumes that you have already implemented the `home_plan` function and the other classes in your project. You can modify the logic and thresholds based on your specific needs and preferences.

# This script provides a basic structure for your smart home system. You can expand it by adding more rules, actions, and integration with other smart home devices. Remember to always prioritize security and privacy when developing your system.
