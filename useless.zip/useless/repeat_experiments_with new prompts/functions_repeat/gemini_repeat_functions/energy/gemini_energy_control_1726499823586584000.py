from home.home_plan import home_plan, get_room, get_all_sensors, get_all_actuators
from home.config import TEMP_LOW, TEMP_HIGH, HUMIDITY_LOW, HUMIDITY_HIGH, LIGHT_INTENSITY_LOW, LIGHT_INTENSITY_HIGH
from home.logger_config import logger

def main():
    home = home_plan()

    # Rule 1: 空调开启时关闭窗户
    ac = get_all_actuators(home, "AC")
    windows = get_all_actuators(home, "Window")
    for ac_unit in ac:
        if ac_unit.status == "on":
            for window in windows:
                if window.status == "on":
                    window.turn_off()
                    logger.info(f"Closed window {window.id} because AC {ac_unit.id} is on.")

    # Rule 2: 当温度低于23度时，关闭空调。
    indoor_temp_sensors = get_all_sensors(home, "IndoorTemperature")
    for sensor in indoor_temp_sensors:
        sensor.turn_on()  # Ensure the sensor is on
        temp = sensor.get_reading()
        if temp is not None and temp < TEMP_LOW:
            for ac_unit in ac:
                if ac_unit.status == "on":
                    ac_unit.turn_off()
                    logger.info(f"Turned off AC {ac_unit.id} because temperature in {sensor.room_name} is below {TEMP_LOW}°C.")

    # Rule 3: 当光照过强时，调暗灯光或关闭灯光。
    light_intensive_sensors = get_all_sensors(home, "LightIntensive")
    lights = get_all_actuators(home, "Light")
    for sensor in light_intensive_sensors:
        sensor.turn_on()  # Ensure the sensor is on
        light_intensity = sensor.get_reading()
        if light_intensity is not None and light_intensity > LIGHT_INTENSITY_HIGH:
            for light_bulb in lights:
                if light_bulb.status == "on":
                    light_bulb.set_brightness_level("low")
                    logger.info(f"Dimmed light {light_bulb.id} in {sensor.room_name} due to high light intensity.")

if __name__ == "__main__":
    main()

# **Explanation:**

# 1. **Import Necessary Modules:**
#    - `home.home_plan`: This imports functions for working with the home plan, including getting rooms, sensors, and actuators.
#    - `home.config`: This imports the predefined thresholds for temperature, humidity, and light intensity from the `config.py` file.
#    - `home.logger_config`: This imports the logger setup to record events.

# 2. **`main` Function:**
#    - **Get Actuators and Sensors:**
#      - `ac = get_all_actuators(home, "AC")`: This retrieves all AC units from the home plan.
#      - `windows = get_all_actuators(home, "Window")`: This retrieves all windows from the home plan.
#      - `indoor_temp_sensors = get_all_sensors(home, "IndoorTemperature")`: This retrieves all indoor temperature sensors.
#      - `light_intensive_sensors = get_all_sensors(home, "LightIntensive")`: This retrieves all light intensity sensors.
#      - `lights = get_all_actuators(home, "Light")`: This retrieves all lights from the home plan.

#    - **Rule 1: AC and Windows**
#      - Iterate through all AC units and check their status.
#      - If an AC unit is on, iterate through all windows and turn off any that are on.
#      - Log the action (turning off a window) when it occurs.

#    - **Rule 2: Temperature and AC**
#      - Iterate through all indoor temperature sensors and turn them on to get readings.
#      - For each sensor, check the temperature reading.
#      - If the temperature is below `TEMP_LOW`, iterate through all AC units and turn off any that are on.
#      - Log the action (turning off an AC unit) when it occurs.

#    - **Rule 3: Light Intensity and Lights**
#      - Iterate through all light intensity sensors and turn them on to get readings.
#      - For each sensor, check the light intensity reading.
#      - If the light intensity is above `LIGHT_INTENSITY_HIGH`, iterate through all lights and dim their brightness to low.
#      - Log the action (dimming a light) when it occurs.

# 3. **`if __name__ == "__main__":` Block:**
#    - Calls the `main` function to execute the smart home logic.

# **Key Points:**

# - The code defines actions based on sensor readings and actuator states.
# - It uses the `get_all_actuators` and `get_all_sensors` functions from `home.home_plan` to easily retrieve specific devices.
# - The `logger.info` statements provide detailed logs for debugging and monitoring.

# **Remember to:**

# - Place this `function.py` file in the `functions` folder.
# - Ensure that the other files (`sensor.py`, `actuator.py`, `home_plan.py`, and `config.py`) are correctly located in the `home` folder.
# - Execute `function.py` to run the smart home logic.
