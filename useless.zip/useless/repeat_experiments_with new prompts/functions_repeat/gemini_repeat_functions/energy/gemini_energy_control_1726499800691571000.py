from home.home_plan import get_room, get_room_sensors, get_room_actuators, get_all_sensors, get_all_actuators
from home.config import TEMP_LOW, TEMP_HIGH, HUMIDITY_LOW, HUMIDITY_HIGH, LIGHT_INTENSITY_LOW, LIGHT_INTENSITY_HIGH
from home.logger_config import logger

def main():
    home = home_plan()

    # 1. 空调开启时关闭窗户
    # Get all AC actuators
    all_acs = get_all_actuators(home, "AC")

    # Get all Window actuators in the same rooms as the ACs
    for ac in all_acs:
        room_name = ac.room_name
        windows = get_room_actuators(home, room_name)
        for window in windows:
            if window.actuator_type == "Window":
                if ac.status == "on":
                    # Close the window
                    window.turn_off()

    # 2. 当温度低于23度时，关闭空调。
    # Get all IndoorTemperatureSensors
    all_indoor_temp_sensors = get_all_sensors(home, "IndoorTemperature")

    # Adjust ACs based on temperature readings
    for sensor in all_indoor_temp_sensors:
        # Get the AC in the same room
        room_name = sensor.room_name
        ac = get_room_actuators(home, room_name)[0]
        current_temperature = sensor.get_reading()

        if current_temperature is not None and current_temperature < TEMP_LOW:
            ac.turn_off()
            print(f"Temperature in {room_name} is below {TEMP_LOW}°C. Turning off AC.")
            logger.info(format(f"Temperature in {room_name} is below {TEMP_LOW}°C. Turning off AC."))

    # 3. 当光照过强时，调暗灯光或关闭灯光。
    # Get all LightIntensiveSensors
    all_light_intensive_sensors = get_all_sensors(home, "LightIntensive")

    # Adjust lights based on light intensity readings
    for sensor in all_light_intensive_sensors:
        current_light_intensity = sensor.get_reading()
        if current_light_intensity is not None and current_light_intensity > LIGHT_INTENSITY_HIGH:
            # Get the light in the same room
            room_name = sensor.room_name
            lights = get_room_actuators(home, room_name)
            for light in lights:
                if light.actuator_type == "Light":
                    light.set_brightness_level("low")
                    print(f"Light intensity in {room_name} is high. Setting lights to low brightness.")
                    logger.info(format(f"Light intensity in {room_name} is high. Setting lights to low brightness."))

if __name__ == "__main__":
    main()

# **Explanation:**

# 1. **Import necessary modules:**
#    - `home.home_plan`: Functions to retrieve room information, sensors, and actuators.
#    - `home.config`: Constants for temperature, humidity, and light intensity thresholds.
#    - `home.logger_config`: Logger for recording events.

# 2. **`main()` function:**
#    - **Retrieve home plan:** Calls `home_plan()` to get the home structure.
#    - **Rule 1: AC and Windows:**
#      - **Get ACs:** Retrieves all "AC" actuators using `get_all_actuators()`.
#      - **Iterate through ACs:**
#        - Get the room name where the AC is located.
#        - Get all actuators in the room using `get_room_actuators()`.
#        - Find the "Window" actuators in the room.
#        - If the AC is on (`ac.status == "on"`), turn off the windows.
#    - **Rule 2: Temperature and AC:**
#      - **Get Indoor Temperature Sensors:** Retrieves all "IndoorTemperature" sensors.
#      - **Iterate through sensors:**
#        - Get the room name of the sensor.
#        - Find the AC in the same room.
#        - Read the current temperature using `sensor.get_reading()`.
#        - If the temperature is below the threshold (`TEMP_LOW`), turn off the AC.
#    - **Rule 3: Light Intensity and Lights:**
#      - **Get Light Intensive Sensors:** Retrieves all "LightIntensive" sensors.
#      - **Iterate through sensors:**
#        - Read the current light intensity using `sensor.get_reading()`.
#        - If the intensity is above the threshold (`LIGHT_INTENSITY_HIGH`), find the lights in the same room and set them to "low" brightness.

# 3. **`if __name__ == "__main__":` block:**
#    - This block ensures that the `main()` function is only called when the script is executed directly, not when imported as a module.

# **To use the code:**

# 1. Make sure the code is saved as `function.py` in the `functions` folder.
# 2. Run the `function.py` file. The code will:
#    - Read sensor data (simulated using random values in the `sensor.py` file).
#    - Apply the rules based on the sensor readings and update the status of actuators (AC, windows, lights).
#    - Log the events to the console using `logger.info()`.

# Remember to configure the thresholds in `config.py` to suit your needs.
