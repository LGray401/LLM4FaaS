from home.home_plan import home_plan, get_room_sensors, get_room_actuators, get_all_sensors, get_all_actuators
from home.config import TEMP_LOW, TEMP_HIGH, HUMIDITY_LOW, HUMIDITY_HIGH, LIGHT_INTENSITY_LOW, LIGHT_INTENSITY_HIGH
from home.logger_config import logger

def main():
    """Main function for the smart home system."""
    home = home_plan()

    # Rule 1: 空调开启时关闭窗户
    # Get all ACs
    acs = get_all_actuators(home, "AC")
    # Get all windows
    windows = get_all_actuators(home, "Window")
    for ac in acs:
        if ac.status == "on":
            for window in windows:
                if window.status == "on":
                    print(f"Closing window {window.id} as AC {ac.id} is on.")
                    window.turn_off()
                    logger.info(format(f"Closing window {window.id} as AC {ac.id} is on."))

    # Rule 2: 当温度低于23度时，关闭空调。
    # Get all indoor temperature sensors
    indoor_temps = get_all_sensors(home, "IndoorTemperature")
    for indoor_temp in indoor_temps:
        if indoor_temp.status == "on":
            temperature = indoor_temp.get_reading()
            if temperature is not None and temperature < TEMP_LOW:
                print(f"Turning off AC in {indoor_temp.room_name} as temperature is below {TEMP_LOW}°C.")
                for ac in acs:
                    if ac.room_name == indoor_temp.room_name and ac.status == "on":
                        ac.turn_off()
                        logger.info(format(f"Turning off AC {ac.id} in {indoor_temp.room_name} as temperature is below {TEMP_LOW}°C."))

    # Rule 3: 当光照过强时，调暗灯光或关闭灯光。
    # Get all light intensive sensors
    light_intensives = get_all_sensors(home, "LightIntensive")
    # Get all lights
    lights = get_all_actuators(home, "Light")
    for light_intensive in light_intensives:
        if light_intensive.status == "on":
            light_intensity = light_intensive.get_reading()
            if light_intensity is not None and light_intensity > LIGHT_INTENSITY_HIGH:
                print(f"Dimming or turning off lights in {light_intensive.room_name} as light intensity is high.")
                for light in lights:
                    if light.room_name == light_intensive.room_name and light.status == "on":
                        light.set_brightness_level("low")
                        logger.info(format(f"Dimming lights in {light_intensive.room_name} as light intensity is high."))


if __name__ == "__main__":
    main()

# **Explanation:**

# 1. **Imports:** The code imports necessary modules:
#    - `home.home_plan`: Provides functions for managing the home plan, sensors, and actuators.
#    - `home.config`: Contains configuration variables like temperature thresholds.
#    - `home.logger_config`: Handles logging for debugging and monitoring.

# 2. **`main()` Function:** This function contains the main logic for the smart home system. It does the following:
#    - **Loads the Home Plan:**  `home = home_plan()` initializes the home plan with rooms and their components.
#    - **Rule 1: AC on, Windows off:**
#      - It gets all ACs and windows from the home plan.
#      - If an AC is on, it iterates through windows and turns them off.
#    - **Rule 2: Temperature Low, AC Off:**
#      - It gets all indoor temperature sensors.
#      - If a temperature sensor is on and reads a temperature below `TEMP_LOW`, it turns off the AC in the same room.
#    - **Rule 3: Light Intensity High, Dim Lights:**
#      - It gets all light intensity sensors and lights.
#      - If a light intensity sensor reads a value above `LIGHT_INTENSITY_HIGH`, it dims or turns off the lights in the same room.

# **To run this code:**

# 1. Make sure all the code files (`sensor.py`, `actuator.py`, `home_plan.py`, `config.py`, and `function.py`) are in their respective folders.
# 2. Run `python functions/function.py` from the root directory of your project.

# **Key Points:**

# - **Rule Implementation:**  The code implements the three rules using loops, conditional statements, and object properties to interact with the smart home components.
# - **Logging:** It uses the `logger` to record events and potential errors for debugging and analysis.
# - **Configuration:**  Constants in `config.py` allow you to easily customize thresholds and other settings.
# - **Extensibility:**  The structure of the code makes it easy to add more rules or components to your smart home system. 
