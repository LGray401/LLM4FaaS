from home.home_plan import home_plan, get_room, get_room_sensors, get_room_actuators, get_all_sensors, \
    get_all_actuators
from home.sensor import IndoorTemperatureSensor
from home.actuator import AC, Window, Light
from home.config import TEMP_LOW, TEMP_HIGH, LIGHT_INTENSITY_LOW, LIGHT_INTENSITY_HIGH
from home.logger_config import logger

def main():
    home = home_plan()
    
    while True:
        # Rule 1: 空调开启时关闭窗户
        # Find all ACs and windows
        acs = get_all_actuators(home, "AC")
        windows = get_all_actuators(home, "Window")
        for ac in acs:
            if ac.get_status() == "on":
                for window in windows:
                    # Assuming we want to close all windows in the same room as the AC
                    if window.room_name == ac.room_name:
                        window.turn_off()
                        print(f"Window in {window.room_name} closed due to AC being on.")
                        logger.info(f"Window in {window.room_name} closed due to AC being on.")

        # Rule 2: 当温度低于23度时，关闭空调。
        indoor_temp_sensors = get_all_sensors(home, "IndoorTemperature")
        for sensor in indoor_temp_sensors:
            temperature = sensor.get_reading()
            if temperature is not None and temperature < TEMP_LOW:
                room = get_room(home, sensor.room_name)
                if room:
                    ac = get_room_actuators(room, "AC")
                    if ac:
                        for ac_unit in ac:
                            ac_unit.turn_off()
                            print(f"AC in {sensor.room_name} turned off due to low temperature.")
                            logger.info(f"AC in {sensor.room_name} turned off due to low temperature.")

        # Rule 3: 当光照过强时，调暗灯光或关闭灯光。
        light_intensity_sensors = get_all_sensors(home, "LightIntensive")
        for sensor in light_intensity_sensors:
            light_intensity = sensor.get_reading()
            if light_intensity is not None and light_intensity > LIGHT_INTENSITY_HIGH:
                room = get_room(home, sensor.room_name)
                if room:
                    lights = get_room_actuators(room, "Light")
                    if lights:
                        for light in lights:
                            light.set_brightness_level("low")
                            print(f"Light in {sensor.room_name} dimmed due to high light intensity.")
                            logger.info(f"Light in {sensor.room_name} dimmed due to high light intensity.")

        # Add a short delay to avoid overwhelming the system
        time.sleep(1)

if __name__ == "__main__":
    main()

# **Explanation:**

# 1. **Import necessary modules:** The code imports relevant modules from `home.home_plan`, `home.sensor`, `home.actuator`, `home.config`, and `home.logger_config`.
# 2. **`main()` function:**
#    - **Get home plan:** `home = home_plan()` retrieves the home layout.
#    - **Continuous loop:** The `while True:` loop runs indefinitely, checking and applying rules.
# 3. **Rule 1: AC ON, close windows:**
#    - **Find ACs and windows:** `get_all_actuators` is used to get all AC and window actuators.
#    - **Check AC status:** For each AC, it checks if it's on.
#    - **Close windows in same room:** If the AC is on, it closes all windows in the same room.
# 4. **Rule 2: Low temperature, turn off AC:**
#    - **Find indoor temperature sensors:** `get_all_sensors` gets all indoor temperature sensors.
#    - **Check temperature:** For each sensor, it gets the temperature reading.
#    - **Turn off AC in the room:** If the temperature is below the threshold (`TEMP_LOW`), it turns off the AC in that room.
# 5. **Rule 3: High light intensity, dim/off lights:**
#    - **Find light intensity sensors:** `get_all_sensors` gets all light intensity sensors.
#    - **Check light intensity:** For each sensor, it gets the light intensity reading.
#    - **Dim/off lights in the room:** If the light intensity is above the threshold (`LIGHT_INTENSITY_HIGH`), it dims or turns off the lights in that room.
# 6. **Delay:** `time.sleep(1)` adds a 1-second delay to avoid rapid rule execution, allowing for other actions and sensor readings.

# **Key Changes:**

# - **Rule implementation:** The code now implements the three rules from your functional description.
# - **Room-specific actions:** It takes into account the room where each actuator or sensor is located and applies rules accordingly.
# - **Error handling:** The code uses `if` statements to handle cases where rooms or actuators might not be found.
# - **Logger:** The code uses the logger from `home.logger_config` to log information and warnings.

# **To run this code:**

# 1. Make sure you have all the files (`sensor.py`, `actuator.py`, `home_plan.py`, `config.py`, `logger_config.py`, and `function.py`) in the correct folders.
# 2. Run `function.py` using `python function.py`.

# This code provides a basic framework for implementing your smart home rules. You can expand it by adding more rules, different types of sensors and actuators, and more complex logic based on your specific needs.
