from home.home_plan import home_plan, get_room, get_room_actuators, get_room_sensors, get_all_actuators, \
    get_all_sensors
from home.config import TEMP_LOW, TEMP_HIGH, HUMIDITY_LOW, HUMIDITY_HIGH, LIGHT_INTENSITY_LOW, LIGHT_INTENSITY_HIGH
from home.logger_config import logger

def main():
    home = home_plan()

    # Rule 1: 空调开启时关闭窗户
    for ac in get_all_actuators(home, "AC"):
        if ac.get_status() == "on":
            for window in get_room_actuators(get_room(home, ac.room_name), "Window"):
                window.turn_off()
                logger.info(f"Close window {window.id} as AC in {ac.room_name} is on")

    # Rule 2: 当温度低于23度时，关闭空调。
    for ac in get_all_actuators(home, "AC"):
        for temp_sensor in get_all_sensors(home, "IndoorTemperature"):
            if temp_sensor.room_name == ac.room_name and temp_sensor.get_reading() < TEMP_LOW:
                ac.turn_off()
                logger.info(f"Turn off AC {ac.id} in {ac.room_name} as temperature is below {TEMP_LOW}°C")

    # Rule 3: 当光照过强时，调暗灯光或关闭灯光。
    for light in get_all_actuators(home, "Light"):
        for light_sensor in get_all_sensors(home, "LightIntensive"):
            if light_sensor.room_name == light.room_name and light_sensor.get_reading() > LIGHT_INTENSITY_HIGH:
                light.set_brightness_level("low")
                logger.info(f"Set {light.id} to low brightness as light intensity is above {LIGHT_INTENSITY_HIGH}lux")

    print("Smart home functions executed.")

if __name__ == "__main__":
    main()

# **Explanation:**

# 1. **Import necessary modules:** Import the required classes and functions from `home_plan.py`, `config.py`, and `logger_config.py`.
# 2. **Define the `main()` function:** This function contains the logic for your smart home rules.
# 3. **Rule 1: Air Conditioner and Windows:**
#    - Get all AC units using `get_all_actuators`.
#    - Iterate through each AC unit.
#    - If an AC is on (`get_status() == "on"`), get all windows in the same room using `get_room_actuators`.
#    - Turn off each window (`window.turn_off()`) and log the action.
# 4. **Rule 2: Air Conditioner and Temperature:**
#    - Get all AC units.
#    - Iterate through each AC unit.
#    - Get all indoor temperature sensors (`get_all_sensors`).
#    - Check if the temperature sensor is in the same room as the AC and if the temperature is below the threshold (e.g., 23°C).
#    - If both conditions are true, turn off the AC (`ac.turn_off()`) and log the action.
# 5. **Rule 3: Light and Light Intensity:**
#    - Get all lights (`get_all_actuators`).
#    - Iterate through each light.
#    - Get all light intensity sensors (`get_all_sensors`).
#    - Check if the sensor is in the same room as the light and if the intensity is above the threshold.
#    - If both conditions are true, set the light's brightness to low (`light.set_brightness_level("low")`) and log the action.
# 6. **Print completion message:** After executing the rules, print a message indicating that the functions have been executed.

# **Remember to save this file as `functions/function.py`.**

# **How to run the code:**

# 1. Make sure you have the other files (`sensor.py`, `actuator.py`, `home_plan.py`, and `config.py`) in the `home` folder.
# 2. Run the `function.py` file from your terminal: `python functions/function.py`

# This will execute the rules and simulate your smart home actions.
