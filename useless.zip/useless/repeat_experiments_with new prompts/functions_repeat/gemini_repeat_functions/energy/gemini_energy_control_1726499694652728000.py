from home.home_plan import home_plan, get_room, get_room_sensors, get_room_actuators, get_all_sensors, \
    get_all_actuators
from home.config import TEMP_LOW, TEMP_HIGH, HUMIDITY_LOW, HUMIDITY_HIGH, LIGHT_INTENSITY_LOW, LIGHT_INTENSITY_HIGH
from home.logger_config import logger


def main():
    home = home_plan()

    # Rule 1: 空调开启时关闭窗户
    for ac in get_all_actuators(home, "AC"):
        if ac.get_status() == "on":
            for window in get_all_actuators(home, "Window"):
                if window.room_name == ac.room_name:
                    window.turn_off()

    # Rule 2: 当温度低于23度时，关闭空调。
    for ac in get_all_actuators(home, "AC"):
        for indoor_temp_sensor in get_all_sensors(home, "IndoorTemperature"):
            if indoor_temp_sensor.room_name == ac.room_name:
                if indoor_temp_sensor.get_reading() < TEMP_HIGH:
                    ac.turn_off()

    # Rule 3: 当光照过强时，调暗灯光或关闭灯光。
    for light_sensor in get_all_sensors(home, "LightIntensive"):
        for light in get_all_actuators(home, "Light"):
            if light_sensor.room_name == light.room_name:
                if light_sensor.get_reading() > LIGHT_INTENSITY_HIGH:
                    light.set_brightness_level("low")  # 调暗灯光
                    # light.turn_off()  # 也可以直接关闭灯光

    # Example: turn on a light in living room
    living_room = get_room(home, "LivingRoom")
    if living_room:
        for light in living_room.actuators:
            if light.actuator_type == "Light":
                light.turn_on()
                light.set_brightness_level("medium")
                print("Light in living room is turned on with medium brightness.")

    print("Smart home functions are executed.")

if __name__ == '__main__':
    main()

# **Explanation:**

# 1. **Import Necessary Modules:**
#    - Imports functions from `home_plan.py` to work with the home layout and components.
#    - Imports constants from `config.py` for temperature, humidity, and light intensity thresholds.
#    - Imports `logger` from `logger_config.py` for logging.

# 2. **`main()` Function:**
#    - Creates the home plan using `home_plan()`.
#    - **Rule 1:**
#      - Iterates through all "AC" actuators.
#      - If an AC is on, iterates through all "Window" actuators in the same room.
#      - If a window is found, it's turned off.
#    - **Rule 2:**
#      - Iterates through all "AC" actuators and "IndoorTemperature" sensors.
#      - If the temperature is below the `TEMP_HIGH` threshold, the corresponding AC is turned off.
#    - **Rule 3:**
#      - Iterates through all "LightIntensive" sensors and "Light" actuators.
#      - If the light intensity is above the `LIGHT_INTENSITY_HIGH` threshold, the corresponding light is dimmed to "low".
#    - **Example:**
#      - Finds the "LivingRoom" and turns on its light with medium brightness.
#    - Prints a message indicating the execution of functions.

# 3. **`if __name__ == '__main__'` Block:**
#    - Calls the `main()` function when the script is run directly.

# **How to Use:**

# 1. **Save:** Save the code as `function.py` in the `functions` folder.
# 2. **Run:** Execute `function.py` from the command line.

# **Important Notes:**

# - This code provides a basic framework for implementing your smart home functions.
# - You can customize the rules, thresholds, and actions according to your needs.
# - The code uses the `logger` for debugging and logging information. You can adjust the logging level and format in `logger_config.py`.
# - Consider using a timer or event-driven architecture for more complex scenarios where you need to trigger actions based on time or specific events.
