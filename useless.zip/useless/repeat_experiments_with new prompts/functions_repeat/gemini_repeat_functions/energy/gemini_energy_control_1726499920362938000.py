from home.home_plan import home_plan, get_room, get_room_sensors, get_room_actuators, get_all_sensors, get_all_actuators
from home.config import TEMP_LOW, TEMP_HIGH, HUMIDITY_LOW, HUMIDITY_HIGH, LIGHT_INTENSITY_LOW, LIGHT_INTENSITY_HIGH

# Example Usage of functions:
def main():
    # Get all lights in the home
    home = home_plan()
    all_lights = get_all_actuators(home, "Light")

    # Get all ACs in the home
    all_acs = get_all_actuators(home, "AC")

    # Get all windows in the home
    all_windows = get_all_actuators(home, "Window")

    # Get the living room
    living_room = get_room(home, "LivingRoom")

    # Get the living room's sensors
    living_room_sensors = get_room_sensors(home, "LivingRoom")

    # Get the living room's actuators
    living_room_actuators = get_room_actuators(home, "LivingRoom")

    # Get all indoor temperature sensors in the home
    indoor_temp_sensors = get_all_sensors(home, "IndoorTemperature")

    # Turn on the lights
    for light in all_lights:
        light.turn_on()

    # Get the temperature in the living room
    for sensor in living_room_sensors:
        if sensor.sensor_type == "IndoorTemperature":
            living_room_temp = sensor.get_reading()

    # If the temperature is below 23 degrees, turn on the AC
    if living_room_temp is not None and living_room_temp < 23:
        for ac in all_acs:
            ac.set_target_temperature(23)
            ac.turn_on()

    # Get the light intensity in the living room
    for sensor in living_room_sensors:
        if sensor.sensor_type == "LightIntensive":
            living_room_light_intensity = sensor.get_reading()

    # If the light intensity is too high, dim the lights
    if living_room_light_intensity is not None and living_room_light_intensity > 900:
        for light in all_lights:
            light.set_brightness_level("low")

    # Get the temperature in each room
    room_temperatures = {}
    for sensor in indoor_temp_sensors:
        room_temperatures[sensor.room_name] = sensor.get_reading()

    # Turn on the heaters in rooms where the temperature is below 18 degrees
    for room_name, temperature in room_temperatures.items():
        if temperature < 18:
            for heater in get_all_actuators(home, "Heater"):
                if heater.room_name == room_name:
                    heater.set_target_temperature(20)
                    heater.turn_on()

    # Print some information
    print("Living Room Temperature:", living_room_temp)
    print("Living Room Light Intensity:", living_room_light_intensity)

    # ... other code ...

# Run the main function if the script is executed directly
if __name__ == "__main__":
    main()

# **Explanation:**

# 1. **Import Necessary Modules:**
#    - `from home.home_plan import ...`: Import functions for managing the home plan (rooms, sensors, actuators).
#    - `from home.config import ...`: Import configuration settings for thresholds and durations.

# 2. **Define the `main()` Function:**
#    - **Home Initialization:**
#      - `home = home_plan()`: Create the home plan with rooms, sensors, and actuators.
#    - **Get Actuators:**
#      - `all_lights = get_all_actuators(home, "Light")`: Retrieve all lights in the home.
#      - `all_acs = get_all_actuators(home, "AC")`: Retrieve all air conditioners in the home.
#      - `all_windows = get_all_actuators(home, "Window")`: Retrieve all windows in the home.
#    - **Get Room Information:**
#      - `living_room = get_room(home, "LivingRoom")`: Find the "LivingRoom".
#      - `living_room_sensors = get_room_sensors(home, "LivingRoom")`: Get sensors in the living room.
#      - `living_room_actuators = get_room_actuators(home, "LivingRoom")`: Get actuators in the living room.
#    - **Get All Sensors:**
#      - `indoor_temp_sensors = get_all_sensors(home, "IndoorTemperature")`: Get all indoor temperature sensors.

# 3. **Implement Logic:**
#    - **Turn On Lights:** 
#      - `for light in all_lights: light.turn_on()`: Turn on all lights.
#    - **Temperature Control:**
#      - Get the temperature in the living room.
#      - `if living_room_temp < 23`: If the living room temperature is below 23 degrees, turn on the AC and set the target temperature.
#    - **Light Intensity Control:**
#      - Get the light intensity in the living room.
#      - `if living_room_light_intensity > 900`: If the light intensity is high, dim the lights.
#    - **Room-Specific Temperature Control:**
#      - `room_temperatures = {}`: Create a dictionary to store temperatures of each room.
#      - `for sensor in indoor_temp_sensors: room_temperatures[sensor.room_name] = sensor.get_reading()`: Get temperatures for each room.
#      - `if temperature < 18`: Turn on the heater in rooms where the temperature is below 18 degrees.

# 4. **Print Information:**
#    - Print the living room temperature and light intensity for debugging.

# 5. **Extend with Additional Functionality:**
#    - This code is a starting point. Add more logic and actions based on your smart home needs:
#      - Control window blinds based on light intensity.
#      - Automate coffee brewing based on time or user preference.
#      - Implement security features like door locking/unlocking.
#      - Integrate with voice assistants or other smart home platforms.

# **Key Points:**

# - **Modularity:** Functions in `home_plan.py` and `config.py` make the code organized.
# - **Extensibility:** The framework is designed to be extended with additional features.
# - **Logical Flow:** The code uses `if` statements and loops to implement smart home logic.
# - **Comments:** Comments explain the purpose of each section of the code.

# Remember to adapt the `main()` function to your specific smart home needs and connect the sensors and actuators appropriately. 
