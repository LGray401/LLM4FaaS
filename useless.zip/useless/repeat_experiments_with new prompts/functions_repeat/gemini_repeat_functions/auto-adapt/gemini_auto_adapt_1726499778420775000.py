from home.home_plan import home_plan, get_room, get_room_sensors, get_room_actuators, get_all_sensors, \
    get_all_actuators, print_home_plan
from home.sensor import IndoorTemperatureSensor, HumiditySensor, LightIntensiveSensor, SmokeSensor, \
    OutdoorTemperatureSensor
from home.actuator import NotificationSender, Light, Window, Curtain, MusicPlayer, Heater, AC, CoffeeMachine, \
    SmartSocket, Door, \
    CleaningRobot, SmartTV
from home.config import TEMP_LOW, TEMP_HIGH, HUMIDITY_LOW, HUMIDITY_HIGH, LIGHT_INTENSITY_LOW, LIGHT_INTENSITY_HIGH, \
    TEMP_CHANGE_DURATION_WINDOW, DAILY_ROUTINE_DURATION
import time

#  # Function to turn on the light in a specific room
# def turn_on_light(home, room_name):
#     room = get_room(home, room_name)
#     if room:
#         for actuator in room.actuators:
#             if isinstance(actuator, Light):
#                 actuator.turn_on()
#                 print(f"Light turned on in {room_name}")
#                 return True
#     return False

# Function to turn on the light in a specific room
def turn_on_light(home, room_name):
    room = get_room(home, room_name)
    if room:
        for actuator in room.actuators:
            if isinstance(actuator, Light):
                actuator.turn_on()
                print(f"Light turned on in {room_name}")
                return True
    return False

# Function to turn off the light in a specific room
def turn_off_light(home, room_name):
    room = get_room(home, room_name)
    if room:
        for actuator in room.actuators:
            if isinstance(actuator, Light):
                actuator.turn_off()
                print(f"Light turned off in {room_name}")
                return True
    return False

# Function to adjust the temperature in a specific room
def adjust_temperature(home, room_name, target_temperature):
    room = get_room(home, room_name)
    if room:
        for actuator in room.actuators:
            if isinstance(actuator, Heater) or isinstance(actuator, AC):
                actuator.set_target_temperature(target_temperature)
                print(f"Temperature set to {target_temperature}°C in {room_name}")
                return True
    return False

# Function to adjust the humidity in a specific room
def adjust_humidity(home, room_name, target_humidity):
    room = get_room(home, room_name)
    if room:
        for actuator in room.actuators:
            if isinstance(actuator, Humidifier):
                if target_humidity > 50:
                    actuator.increase_humidity()
                    print(f"Increasing humidity in {room_name}")
                elif target_humidity < 30:
                    actuator.decrease_humidity()
                    print(f"Decreasing humidity in {room_name}")
                else:
                    print(f"Humidity level is already within target range in {room_name}")
                return True
    return False

# Function to play music in a specific room
def play_music(home, room_name, playlist):
    room = get_room(home, room_name)
    if room:
        for actuator in room.actuators:
            if isinstance(actuator, MusicPlayer):
                actuator.play_music(playlist)
                print(f"Playing music in {room_name}")
                return True
    return False

# Function to turn on the TV in a specific room
def turn_on_tv(home, room_name):
    room = get_room(home, room_name)
    if room:
        for actuator in room.actuators:
            if isinstance(actuator, SmartTV):
                actuator.turn_on()
                print(f"TV turned on in {room_name}")
                return True
    return False

# Function to turn off the TV in a specific room
def turn_off_tv(home, room_name):
    room = get_room(home, room_name)
    if room:
        for actuator in room.actuators:
            if isinstance(actuator, SmartTV):
                actuator.turn_off()
                print(f"TV turned off in {room_name}")
                return True
    return False

# Function to play a channel on the TV in a specific room
def play_channel(home, room_name, channel_name):
    room = get_room(home, room_name)
    if room:
        for actuator in room.actuators:
            if isinstance(actuator, SmartTV):
                actuator.play_channel(channel_name)
                print(f"Playing {channel_name} on TV in {room_name}")
                return True
    return False

# Function to turn on the coffee machine in the kitchen
def make_coffee(home, coffee_type):
    kitchen = get_room(home, "Kitchen")
    if kitchen:
        for actuator in kitchen.actuators:
            if isinstance(actuator, CoffeeMachine):
                actuator.turn_on()
                actuator.make_coffee(coffee_type)
                print(f"Making {coffee_type} in the kitchen")
                return True
    return False

# Function to turn on the cleaning robot in a specific room
def start_cleaning_robot(home, room_name):
    room = get_room(home, room_name)
    if room:
        for actuator in room.actuators:
            if isinstance(actuator, CleaningRobot):
                actuator.turn_on()
                actuator.daily_routine()
                print(f"Cleaning robot started in {room_name}")
                return True
    return False

# Function to send a notification to the user
def send_notification(home, message):
    for room in home:
        for actuator in room.actuators:
            if isinstance(actuator, NotificationSender):
                actuator.notification_sender(message)
                print(f"Notification sent: {message}")
                return True
    return False

# Function to check if the temperature is within the acceptable range
def check_temperature(home, room_name):
    room = get_room(home, room_name)
    if room:
        for sensor in room.sensors:
            if isinstance(sensor, IndoorTemperatureSensor):
                current_temperature = sensor.get_reading()
                if current_temperature < TEMP_LOW:
                    print(f"Temperature in {room_name} is too low ({current_temperature}°C).")
                    return False
                elif current_temperature > TEMP_HIGH:
                    print(f"Temperature in {room_name} is too high ({current_temperature}°C).")
                    return False
                else:
                    print(f"Temperature in {room_name} is comfortable ({current_temperature}°C).")
                    return True
    return False

# Function to check if the humidity is within the acceptable range
def check_humidity(home, room_name):
    room = get_room(home, room_name)
    if room:
        for sensor in room.sensors:
            if isinstance(sensor, HumiditySensor):
                current_humidity = sensor.get_reading()
                if current_humidity < HUMIDITY_LOW:
                    print(f"Humidity in {room_name} is too low ({current_humidity}%).")
                    return False
                elif current_humidity > HUMIDITY_HIGH:
                    print(f"Humidity in {room_name} is too high ({current_humidity}%).")
                    return False
                else:
                    print(f"Humidity in {room_name} is comfortable ({current_humidity}%).")
                    return True
    return False

# Function to check if the light intensity is within the acceptable range
def check_light_intensity(home, room_name):
    room = get_room(home, room_name)
    if room:
        for sensor in room.sensors:
            if isinstance(sensor, LightIntensiveSensor):
                current_light_intensity = sensor.get_reading()
                if current_light_intensity < LIGHT_INTENSITY_LOW:
                    print(f"Light intensity in {room_name} is too low ({current_light_intensity} lux).")
                    return False
                elif current_light_intensity > LIGHT_INTENSITY_HIGH:
                    print(f"Light intensity in {room_name} is too high ({current_light_intensity} lux).")
                    return False
                else:
                    print(f"Light intensity in {room_name} is comfortable ({current_light_intensity} lux).")
                    return True
    return False

# Function to check if the smoke sensor is triggered
def check_smoke_sensor(home):
    for room in home:
        for sensor in room.sensors:
            if isinstance(sensor, SmokeSensor):
                if sensor.get_reading() > 0:
                    print("Smoke detected! Sending notification.")
                    send_notification(home, "Smoke detected! Please check the kitchen.")
                    return True
    return False

# Function to simulate a smart home scenario
def main():
    home = home_plan()
    print_home_plan(home)

    while True:
        # Check for smoke
        if check_smoke_sensor(home):
            continue

        # Check temperature in each room
        if not check_temperature(home, "LivingRoom"):
            adjust_temperature(home, "LivingRoom", 22)
        if not check_temperature(home, "Bedroom"):
            adjust_temperature(home, "Bedroom", 20)
        if not check_temperature(home, "Kitchen"):
            adjust_temperature(home, "Kitchen", 25)
        if not check_temperature(home, "Bathroom"):
            adjust_temperature(home, "Bathroom", 23)

        # Check humidity in each room
        if not check_humidity(home, "LivingRoom"):
            adjust_humidity(home, "LivingRoom", 40)
        if not check_humidity(home, "Bedroom"):
            adjust_humidity(home, "Bedroom", 45)
        if not check_humidity(home, "Kitchen"):
            adjust_humidity(home, "Kitchen", 35)
        if not check_humidity(home, "Bathroom"):
            adjust_humidity(home, "Bathroom", 50)

        # Check light intensity in each room
        if not check_light_intensity(home, "LivingRoom"):
            turn_on_light(home, "LivingRoom")
        if not check_light_intensity(home, "Bedroom"):
            turn_on_light(home, "Bedroom")
        if not check_light_intensity(home, "Kitchen"):
            turn_on_light(home, "Kitchen")
        if not check_light_intensity(home, "Bathroom"):
            turn_on_light(home, "Bathroom")

        # Simulate a user turning on the TV in the living room
        if random.random() < 0.1:
            turn_on_tv(home, "LivingRoom")
            play_channel(home, "LivingRoom", "News Channel")

        # Simulate a user making coffee in the kitchen
        if random.random() < 0.2:
            make_coffee(home, "Espresso")

        # Simulate a user starting the cleaning robot in the living room
        if random.random() < 0.3:
            start_cleaning_robot(home, "LivingRoom")

        # Wait for a short period before checking again
        time.sleep(TEMP_CHANGE_DURATION_WINDOW)

if __name__ == "__main__":
    main()