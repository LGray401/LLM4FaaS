from home.home_plan import home_plan, get_room, get_room_sensors, get_room_actuators, get_all_sensors, get_all_actuators
from home.sensor import IndoorTemperatureSensor, HumiditySensor, LightIntensiveSensor, SmokeSensor, \
    OutdoorTemperatureSensor
from home.actuator import NotificationSender, Light, Window, Curtain, MusicPlayer, Heater, AC, CoffeeMachine, \
    SmartSocket, Door, \
    CleaningRobot, SmartTV, Humidifier
from home.config import TEMP_LOW, TEMP_HIGH, HUMIDITY_LOW, HUMIDITY_HIGH, LIGHT_INTENSITY_LOW, LIGHT_INTENSITY_HIGH, \
    TEMP_CHANGE_DURATION_WINDOW
from home.logger_config import logger

# You can add more functions as needed for your project
def main():
    """
    The main function that executes the smart home functionality.
    """
    # Initialize home plan
    home = home_plan()

    # Example: Get all lights
    lights = get_all_actuators(home, "Light")
    print(f"Found {len(lights)} lights")
    logger.info(f"Found {len(lights)} lights")

    # Example: Turn on all lights in the living room
    living_room = get_room(home, "LivingRoom")
    if living_room is not None:
        living_room_lights = get_room_actuators(home, "LivingRoom")
        for light in living_room_lights:
            if isinstance(light, Light):
                light.turn_on()
                light.set_brightness_level("medium")

    # Example: Adjust temperature
    temperature_sensors = get_all_sensors(home, "IndoorTemperature")
    for sensor in temperature_sensors:
        if isinstance(sensor, IndoorTemperatureSensor):
            temperature = sensor.get_reading()
            if temperature is not None:
                room_name = sensor.room_name
                room = get_room(home, room_name)
                if room is not None:
                    heaters = get_room_actuators(room, "Heater")
                    for heater in heaters:
                        if isinstance(heater, Heater):
                            heater.set_target_temperature(22)
                            heater.adjust_temperature(temperature)
                    acs = get_room_actuators(room, "AC")
                    for ac in acs:
                        if isinstance(ac, AC):
                            ac.set_target_temperature(22)
                            ac.adjust_temperature(temperature)

    # Example: Adjust humidity
    humidity_sensors = get_all_sensors(home, "Humidity")
    for sensor in humidity_sensors:
        if isinstance(sensor, HumiditySensor):
            humidity = sensor.get_reading()
            if humidity is not None:
                room_name = sensor.room_name
                room = get_room(home, room_name)
                if room is not None:
                    humidifiers = get_room_actuators(room, "Humidifier")
                    for humidifier in humidifiers:
                        if isinstance(humidifier, Humidifier):
                            if humidity < HUMIDITY_LOW:
                                humidifier.increase_humidity()
                            elif humidity > HUMIDITY_HIGH:
                                humidifier.decrease_humidity()

    # Example: Adjust light intensity
    light_intensity_sensors = get_all_sensors(home, "LightIntensive")
    for sensor in light_intensity_sensors:
        if isinstance(sensor, LightIntensiveSensor):
            light_intensity = sensor.get_reading()
            if light_intensity is not None:
                room_name = sensor.room_name
                room = get_room(home, room_name)
                if room is not None:
                    lights = get_room_actuators(room, "Light")
                    for light in lights:
                        if isinstance(light, Light):
                            if light_intensity < LIGHT_INTENSITY_LOW:
                                light.turn_on()
                                light.set_brightness_level("high")
                            elif light_intensity > LIGHT_INTENSITY_HIGH:
                                light.set_brightness_level("low")


    # Example: Open/Close windows based on temperature
    # for room in home:
    #     for window in room.actuators:
    #         if isinstance(window, Window):
    #             sensors = get_room_sensors(home, room.name)
    #             for sensor in sensors:
    #                 if isinstance(sensor, IndoorTemperatureSensor):
    #                     temperature = sensor.get_reading()
    #                     if temperature is not None:
    #                         if temperature < TEMP_LOW:
    #                             window.turn_on()
    #                         elif temperature > TEMP_HIGH:
    #                             window.turn_off()
    #                         else:
    #                             if window.status == "on":
    #                                 time.sleep(TEMP_CHANGE_DURATION_WINDOW)
    #                                 window.turn_off()
    #                             elif window.status == "off":
    #                                 time.sleep(TEMP_CHANGE_DURATION_WINDOW)
    #                                 window.turn_on()

    # Example: Send notifications
    notification_senders = get_all_actuators(home, "NotificationSender")
    for sender in notification_senders:
        if isinstance(sender, NotificationSender):
            sender.notification_sender("This is a test notification")

    # Add more functionality here
    # ...

if __name__ == '__main__':
    main()
