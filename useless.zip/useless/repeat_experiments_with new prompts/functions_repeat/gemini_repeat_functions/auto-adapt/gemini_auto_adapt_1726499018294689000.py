from home.home_plan import home_plan, get_room, get_room_sensors, get_room_actuators, get_all_sensors, \
    get_all_actuators
from home.sensor import IndoorTemperatureSensor, HumiditySensor, LightIntensiveSensor, SmokeSensor, \
    OutdoorTemperatureSensor
from home.actuator import NotificationSender, Light, Window, Curtain, MusicPlayer, Heater, AC, CoffeeMachine, \
    SmartSocket, Door, \
    CleaningRobot, SmartTV
from home.config import TEMP_CHANGE_DURATION_WINDOW, TEMP_LOW, TEMP_HIGH, HUMIDITY_LOW, HUMIDITY_HIGH, \
    LIGHT_INTENSITY_LOW, LIGHT_INTENSITY_HIGH


def main():
    home = home_plan()

    # Example function call 1: Get all indoor temperature sensors
    indoor_temp_sensors = get_all_sensors(home, "IndoorTemperature")
    for sensor in indoor_temp_sensors:
        print(f"Indoor Temperature Sensor: {sensor.id}")

    # Example function call 2: Get all lights
    lights = get_all_actuators(home, "Light")
    for light in lights:
        print(f"Light: {light.id}")

    # Example function call 3: Get the living room and turn on the lights
    living_room = get_room(home, "LivingRoom")
    if living_room:
        living_room_lights = get_room_actuators(home, "LivingRoom")
        for light in living_room_lights:
            if isinstance(light, Light):
                light.turn_on()

    # Example function call 4: Get the bedroom and set the AC temperature
    bedroom = get_room(home, "Bedroom")
    if bedroom:
        bedroom_ac = get_room_actuators(home, "Bedroom")
        for actuator in bedroom_ac:
            if isinstance(actuator, AC):
                actuator.set_target_temperature(22)

    # Example function call 5: Get the kitchen and turn on the coffee machine
    kitchen = get_room(home, "Kitchen")
    if kitchen:
        kitchen_coffee_machine = get_room_actuators(home, "Kitchen")
        for actuator in kitchen_coffee_machine:
            if isinstance(actuator, CoffeeMachine):
                actuator.turn_on()
                actuator.make_coffee("Espresso")

    # Example function call 6: Get the bathroom and adjust the heater temperature
    bathroom = get_room(home, "Bathroom")
    if bathroom:
        bathroom_heater = get_room_actuators(home, "Bathroom")
        for actuator in bathroom_heater:
            if isinstance(actuator, Heater):
                bathroom_temp_sensor = get_room_sensors(home, "Bathroom")
                for sensor in bathroom_temp_sensor:
                    if isinstance(sensor, IndoorTemperatureSensor):
                        current_temperature = sensor.get_reading()
                        if current_temperature is not None:
                            actuator.adjust_temperature(current_temperature)
                            break

    # Example function call 7: Get the balcony and check the outdoor temperature
    balcony = get_room(home, "Balcony")
    if balcony:
        balcony_temp_sensor = get_room_sensors(home, "Balcony")
        for sensor in balcony_temp_sensor:
            if isinstance(sensor, OutdoorTemperatureSensor):
                current_temperature = sensor.get_reading()
                print(f"Outdoor Temperature: {current_temperature}")

    # Example function call 8: Get the living room and open the windows if the temperature is too high
    living_room = get_room(home, "LivingRoom")
    if living_room:
        living_room_temp_sensor = get_room_sensors(home, "LivingRoom")
        for sensor in living_room_temp_sensor:
            if isinstance(sensor, IndoorTemperatureSensor):
                current_temperature = sensor.get_reading()
                if current_temperature > TEMP_HIGH:
                    living_room_windows = get_room_actuators(home, "LivingRoom")
                    for actuator in living_room_windows:
                        if isinstance(actuator, Window):
                            actuator.turn_on()
                            break
                    break

    # Example function call 9: Get the bedroom and close the curtains if the light intensity is too low
    bedroom = get_room(home, "Bedroom")
    if bedroom:
        bedroom_light_sensor = get_room_sensors(home, "Bedroom")
        for sensor in bedroom_light_sensor:
            if isinstance(sensor, LightIntensiveSensor):
                current_light_intensity = sensor.get_reading()
                if current_light_intensity < LIGHT_INTENSITY_LOW:
                    bedroom_curtains = get_room_actuators(home, "Bedroom")
                    for actuator in bedroom_curtains:
                        if isinstance(actuator, Curtain):
                            actuator.turn_on()
                            break
                    break

    # Example function call 10: Get the kitchen and send a notification if the smoke sensor detects smoke
    kitchen = get_room(home, "Kitchen")
    if kitchen:
        kitchen_smoke_sensor = get_room_sensors(home, "Kitchen")
        for sensor in kitchen_smoke_sensor:
            if isinstance(sensor, SmokeSensor):
                smoke_level = sensor.get_reading()
                if smoke_level > 0:
                    kitchen_notification_sender = get_room_actuators(home, "Kitchen")
                    for actuator in kitchen_notification_sender:
                        if isinstance(actuator, NotificationSender):
                            actuator.notification_sender("Smoke detected in the kitchen!")
                            break
                    break


if __name__ == "__main__":
    main()