from home.home_plan import home_plan, get_room, get_room_sensors, get_room_actuators, get_all_sensors, \
    get_all_actuators
from home.sensor import IndoorTemperatureSensor, HumiditySensor, LightIntensiveSensor, SmokeSensor, \
    OutdoorTemperatureSensor
from home.actuator import NotificationSender, Light, Window, Curtain, MusicPlayer, Heater, AC, CoffeeMachine, \
    SmartSocket, Door, \
    CleaningRobot, SmartTV
from home.config import TEMP_LOW, TEMP_HIGH, HUMIDITY_LOW, HUMIDITY_HIGH, LIGHT_INTENSITY_LOW, LIGHT_INTENSITY_HIGH
from home.logger_config import logger


def main():
    # Initialize the home plan
    home = home_plan()

    # Example usage:
    # Get the living room
    living_room = get_room(home, "LivingRoom")

    # Get all the sensors in the living room
    living_room_sensors = get_room_sensors(home, "LivingRoom")

    # Get all the actuators in the living room
    living_room_actuators = get_room_actuators(home, "LivingRoom")

    # Get all the indoor temperature sensors in the home
    all_indoor_temp_sensors = get_all_sensors(home, "IndoorTemperature")

    # Get all the lights in the home
    all_lights = get_all_actuators(home, "Light")

    # Example using sensors
    if living_room_sensors:
        for sensor in living_room_sensors:
            if isinstance(sensor, IndoorTemperatureSensor):
                temperature = sensor.get_reading()
                if temperature is not None:
                    # Take actions based on temperature
                    if temperature < TEMP_LOW:
                        print(f"The temperature in the living room is too low! Turning on the heater.")
                        logger.info(format(f"The temperature in the living room is too low! Turning on the heater."))
                        # Find the heater in the living room and turn it on
                        heater = next((actuator for actuator in living_room_actuators
                                       if isinstance(actuator, Heater)), None)
                        if heater:
                            heater.turn_on()
                    elif temperature > TEMP_HIGH:
                        print(f"The temperature in the living room is too high! Turning on the AC.")
                        logger.info(format(f"The temperature in the living room is too high! Turning on the AC."))
                        # Find the AC in the living room and turn it on
                        ac = next((actuator for actuator in living_room_actuators
                                   if isinstance(actuator, AC)), None)
                        if ac:
                            ac.turn_on()

            elif isinstance(sensor, HumiditySensor):
                humidity = sensor.get_reading()
                if humidity is not None:
                    # Take actions based on humidity
                    if humidity < HUMIDITY_LOW:
                        print(f"The humidity in the living room is too low! Turning on the humidifier.")
                        logger.info(format(f"The humidity in the living room is too low! Turning on the humidifier."))
                        # Find the humidifier in the living room and turn it on
                        humidifier = next((actuator for actuator in living_room_actuators
                                          if isinstance(actuator, Humidifier)), None)
                        if humidifier:
                            humidifier.increase_humidity()
                    elif humidity > HUMIDITY_HIGH:
                        print(f"The humidity in the living room is too high! Opening a window.")
                        logger.info(format(f"The humidity in the living room is too high! Opening a window."))
                        # Find a window in the living room and open it
                        window = next((actuator for actuator in living_room_actuators
                                       if isinstance(actuator, Window)), None)
                        if window:
                            window.turn_on()

            elif isinstance(sensor, LightIntensiveSensor):
                light_intensity = sensor.get_reading()
                if light_intensity is not None:
                    # Take actions based on light intensity
                    if light_intensity < LIGHT_INTENSITY_LOW:
                        print(f"The light intensity in the living room is too low! Turning on the light.")
                        logger.info(format(f"The light intensity in the living room is too low! Turning on the light."))
                        # Find a light in the living room and turn it on
                        light = next((actuator for actuator in living_room_actuators
                                      if isinstance(actuator, Light)), None)
                        if light:
                            light.turn_on()
                    elif light_intensity > LIGHT_INTENSITY_HIGH:
                        print(f"The light intensity in the living room is too high! Closing the curtains.")
                        logger.info(format(f"The light intensity in the living room is too high! Closing the curtains."))
                        # Find the curtains in the living room and close them
                        curtain = next((actuator for actuator in living_room_actuators
                                       if isinstance(actuator, Curtain)), None)
                        if curtain:
                            curtain.turn_on()

    # Example using actuators
    if living_room_actuators:
        for actuator in living_room_actuators:
            if isinstance(actuator, Light):
                # Control the brightness of the light
                actuator.set_brightness_level("medium")

            elif isinstance(actuator, MusicPlayer):
                # Play music
                actuator.play_music("Pop playlist")

            elif isinstance(actuator, SmartTV):
                # Play a channel
                actuator.play_channel("News")

            elif isinstance(actuator, CleaningRobot):
                # Start the cleaning routine
                actuator.daily_routine()

            elif isinstance(actuator, NotificationSender):
                # Send a notification
                actuator.notification_sender("Reminder: Don't forget to take out the trash.")

    # Example using sensors and actuators
    if all_indoor_temp_sensors:
        for sensor in all_indoor_temp_sensors:
            temperature = sensor.get_reading()
            if temperature is not None:
                for actuator in all_lights:
                    if temperature < TEMP_LOW:
                        # Turn on the lights if the temperature is too low
                        actuator.turn_on()
                    elif temperature > TEMP_HIGH:
                        # Turn off the lights if the temperature is too high
                        actuator.turn_off()


if __name__ == "__main__":
    main()

# **Explanation of the Code:**

# 1. **Import necessary modules:** Imports modules from 'home' package for home plan, sensors, actuators, and configuration settings.
# 2. **`main` function:** Contains the main logic for interacting with sensors and actuators.
# 3. **Initialize the home plan:** Calls `home_plan()` to create the home structure with rooms and components.
# 4. **Get specific rooms and components:**
#    - `get_room()` to retrieve a room by name.
#    - `get_room_sensors()` to get all sensors in a room.
#    - `get_room_actuators()` to get all actuators in a room.
#    - `get_all_sensors()` to get all sensors of a specific type in the home.
#    - `get_all_actuators()` to get all actuators of a specific type in the home.
# 5. **Example usage:** Demonstrates how to:
#    - Access sensors and their readings.
#    - Access actuators and control their actions.
#    - Combine sensor readings with actuator control based on specific conditions.
# 6. **Example using sensors:** Demonstrates how to:
#    - Get readings from sensors (temperature, humidity, light intensity).
#    - Analyze readings and trigger appropriate actions.
#    - Find relevant actuators in the room based on sensor data.
#    - Turn actuators on/off based on conditions.
# 7. **Example using actuators:** Shows how to:
#    - Control actuator settings (light brightness, music playback, TV channels, cleaning routine, notifications).
# 8. **Example using sensors and actuators:** Combines sensor readings with actuator control for a specific scenario.

# **Key Points:**

# - The `main` function provides a structure for controlling the smart home based on sensor data and actuator actions.
# - You can expand the code with more sensor types, actuator types, and complex logic for different scenarios.
# - The code utilizes conditional statements (`if`, `elif`, `else`) to make decisions based on sensor readings.
# - The code demonstrates how to access components (rooms, sensors, actuators) within the `home` plan.
# - This code serves as a foundation for building a functional smart home system using Python.
