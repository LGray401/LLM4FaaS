from home.home_plan import home_plan, get_room, get_room_sensors, get_room_actuators, get_all_sensors, \
    get_all_actuators
from home.sensor import IndoorTemperatureSensor, HumiditySensor, LightIntensiveSensor
from home.actuator import Light, Heater, AC, CoffeeMachine, NotificationSender, MusicPlayer, CleaningRobot, SmartTV
from home.config import TEMP_LOW, TEMP_HIGH, HUMIDITY_LOW, HUMIDITY_HIGH, LIGHT_INTENSITY_LOW, LIGHT_INTENSITY_HIGH, \
    TEMP_CHANGE_DURATION_WINDOW, DAILY_ROUTINE_DURATION


def main():
    home = home_plan()

    # Example usage:

    # 1. Get the LivingRoom and its sensors
    living_room = get_room(home, "LivingRoom")
    living_room_sensors = get_room_sensors(home, "LivingRoom")

    # 2. Turn on the light in the LivingRoom
    living_room_light = get_all_actuators(home, "Light")[0]
    living_room_light.turn_on()

    # 3. Get the IndoorTemperatureSensor in the LivingRoom and check its reading
    living_room_temp_sensor = get_all_sensors(home, "IndoorTemperature")[0]
    current_temperature = living_room_temp_sensor.get_reading()

    # 4. Adjust the heater in the LivingRoom based on temperature
    living_room_heater = get_all_actuators(home, "Heater")[0]
    if current_temperature < TEMP_LOW:
        living_room_heater.turn_on()
    else:
        living_room_heater.turn_off()

    # 5. Get the HumiditySensor in the LivingRoom and check its reading
    living_room_humidity_sensor = get_all_sensors(home, "Humidity")[0]
    current_humidity = living_room_humidity_sensor.get_reading()

    # 6. Adjust the AC in the LivingRoom based on humidity
    living_room_ac = get_all_actuators(home, "AC")[0]
    if current_humidity > HUMIDITY_HIGH:
        living_room_ac.turn_on()
    else:
        living_room_ac.turn_off()

    # 7. Get the LightIntensiveSensor in the LivingRoom and check its reading
    living_room_light_sensor = get_all_sensors(home, "LightIntensive")[0]
    current_light_intensity = living_room_light_sensor.get_reading()

    # 8. Adjust the light in the LivingRoom based on light intensity
    if current_light_intensity < LIGHT_INTENSITY_LOW:
        living_room_light.set_brightness_level("high")
    elif current_light_intensity > LIGHT_INTENSITY_HIGH:
        living_room_light.set_brightness_level("low")
    else:
        living_room_light.set_brightness_level("medium")

    # 9. Turn on the music player in the LivingRoom and play a playlist
    living_room_music_player = get_all_actuators(home, "MusicPlayer")[0]
    living_room_music_player.turn_on()
    living_room_music_player.play_music("Pop Music")

    # 10. Get the CleaningRobot in the LivingRoom and start daily routine
    living_room_cleaning_robot = get_all_actuators(home, "CleaningRobot")[0]
    living_room_cleaning_robot.daily_routine()

    # 11. Get the SmartTV in the LivingRoom and play a channel
    living_room_smart_tv = get_all_actuators(home, "SmartTV")[0]
    living_room_smart_tv.turn_on()
    living_room_smart_tv.play_channel("News Channel")

    # 12. Get the Kitchen and its actuators
    kitchen = get_room(home, "Kitchen")
    kitchen_actuators = get_room_actuators(home, "Kitchen")

    # 13. Turn on the coffee machine and make coffee
    kitchen_coffee_machine = get_all_actuators(home, "CoffeeMachine")[0]
    kitchen_coffee_machine.turn_on()
    kitchen_coffee_machine.make_coffee("Espresso")

    # 14. Get the NotificationSender and send a notification
    notification_sender = get_all_actuators(home, "NotificationSender")[0]
    notification_sender.turn_on()
    notification_sender.notification_sender("Coffee is ready!")

    # Simulate temperature change for a few seconds
    for i in range(TEMP_CHANGE_DURATION_WINDOW):
        current_temperature = living_room_temp_sensor.get_reading()
        living_room_heater.adjust_temperature(current_temperature)
        time.sleep(1)

    # Simulate daily routine for the cleaning robot
    living_room_cleaning_robot.daily_routine()

    # Simulate playing music for a few seconds
    time.sleep(DAILY_ROUTINE_DURATION)
    living_room_music_player.play_music("Classical Music")
    time.sleep(DAILY_ROUTINE_DURATION)
    living_room_music_player.turn_off()

    # Turn off all the lights in the home
    all_lights = get_all_actuators(home, "Light")
    for light in all_lights:
        light.turn_off()

    # Turn off all the ACs in the home
    all_acs = get_all_actuators(home, "AC")
    for ac in all_acs:
        ac.turn_off()

    # Turn off all the heaters in the home
    all_heaters = get_all_actuators(home, "Heater")
    for heater in all_heaters:
        heater.turn_off()

    # Turn off all the coffee machines in the home
    all_coffee_machines = get_all_actuators(home, "CoffeeMachine")
    for coffee_machine in all_coffee_machines:
        coffee_machine.turn_off()

    # Turn off all the music players in the home
    all_music_players = get_all_actuators(home, "MusicPlayer")
    for music_player in all_music_players:
        music_player.turn_off()

    # Turn off all the smart TVs in the home
    all_smart_tvs = get_all_actuators(home, "SmartTV")
    for smart_tv in all_smart_tvs:
        smart_tv.turn_off()

    # Turn off all the cleaning robots in the home
    all_cleaning_robots = get_all_actuators(home, "CleaningRobot")
    for cleaning_robot in all_cleaning_robots:
        cleaning_robot.turn_off()

    # Turn off all the notification senders in the home
    all_notification_senders = get_all_actuators(home, "NotificationSender")
    for notification_sender in all_notification_senders:
        notification_sender.turn_off()

    print("Home automation system shutting down...")


if __name__ == "__main__":
    main()

# This code defines a `main` function that demonstrates how to interact with the smart home system using the provided classes and functions:

# 1. **Initialize Home Plan:** Creates the home plan using `home_plan()`.
# 2. **Get Living Room and Sensors:** Retrieves the "LivingRoom" object and its sensors.
# 3. **Turn on Light:** Gets the "Light" actuator in the living room and turns it on.
# 4. **Get Temperature Reading:** Gets the "IndoorTemperatureSensor" in the living room and retrieves its reading.
# 5. **Adjust Heater:** Adjusts the heater based on the temperature reading.
# 6. **Get Humidity Reading:** Gets the "HumiditySensor" in the living room and retrieves its reading.
# 7. **Adjust AC:** Adjusts the AC based on the humidity reading.
# 8. **Get Light Intensity Reading:** Gets the "LightIntensiveSensor" in the living room and retrieves its reading.
# 9. **Adjust Light Brightness:** Adjusts the light brightness based on the light intensity reading.
# 10. **Turn on Music Player and Play Playlist:** Turns on the "MusicPlayer" in the living room and plays a playlist.
# 11. **Start Cleaning Robot Daily Routine:** Starts the daily routine of the "CleaningRobot" in the living room.
# 12. **Turn on Smart TV and Play Channel:** Turns on the "SmartTV" in the living room and plays a channel.
# 13. **Get Kitchen and Actuators:** Retrieves the "Kitchen" object and its actuators.
# 14. **Turn on Coffee Machine and Make Coffee:** Turns on the "CoffeeMachine" in the kitchen and makes coffee.
# 15. **Send Notification:** Sends a notification using the "NotificationSender".
# 16. **Simulate Temperature Change:** Simulates a temperature change for a few seconds and adjusts the heater accordingly.
# 17. **Simulate Daily Routine:** Simulates the daily routine of the cleaning robot.
# 18. **Simulate Playing Music:** Simulates playing music for a few seconds.
# 19. **Turn Off All Devices:** Turns off all lights, ACs, heaters, coffee machines, music players, smart TVs, cleaning robots, and notification senders.

# This `main` function provides a basic example of how to use the smart home system. You can further customize and expand this code to create more complex and automated scenarios.
