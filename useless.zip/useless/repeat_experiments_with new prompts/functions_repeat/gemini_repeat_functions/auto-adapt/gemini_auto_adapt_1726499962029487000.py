from home.home_plan import home_plan, get_room, get_room_sensors, get_room_actuators, get_all_sensors, \
    get_all_actuators
from home.sensor import Sensor
from home.actuator import Actuator
from home.config import TEMP_LOW, TEMP_HIGH, HUMIDITY_LOW, HUMIDITY_HIGH, LIGHT_INTENSITY_LOW, LIGHT_INTENSITY_HIGH, \
    TEMP_CHANGE_DURATION_WINDOW, DAILY_ROUTINE_DURATION
from home.logger_config import logger
import time


def main():
    home = home_plan()  # Create the home plan

    # Example use cases:
    # Get the Living Room
    living_room = get_room(home, "LivingRoom")

    # Get all IndoorTemperatureSensors in the home
    indoor_temp_sensors = get_all_sensors(home, "IndoorTemperature")

    # Get all Lights in the Living Room
    living_room_lights = get_room_actuators(home, "LivingRoom")

    # Get a specific sensor
    living_room_temp_sensor = get_room_sensors(home, "LivingRoom")[0]

    # Turn on the lights in the living room
    for light in living_room_lights:
        if isinstance(light, Actuator):
            light.turn_on()

    # Simulate temperature changes in the living room
    for i in range(5):
        # Get a random temperature reading for the living room
        current_temperature = living_room_temp_sensor.get_reading()

        # Adjust the temperature if necessary
        if current_temperature < TEMP_LOW:
            # Turn on the heater in the living room
            for heater in living_room_lights:
                if isinstance(heater, Actuator):
                    heater.turn_on()
                    print(f"Turning on heater in LivingRoom: {heater.id}")
            print(f"LivingRoom temperature is too low: {current_temperature}")
            logger.warning(f"LivingRoom temperature is too low: {current_temperature}")
            time.sleep(TEMP_CHANGE_DURATION_WINDOW)
        elif current_temperature > TEMP_HIGH:
            # Turn on the AC in the living room
            for ac in living_room_lights:
                if isinstance(ac, Actuator):
                    ac.turn_on()
                    print(f"Turning on AC in LivingRoom: {ac.id}")
            print(f"LivingRoom temperature is too high: {current_temperature}")
            logger.warning(f"LivingRoom temperature is too high: {current_temperature}")
            time.sleep(TEMP_CHANGE_DURATION_WINDOW)
        else:
            print(f"LivingRoom temperature is comfortable: {current_temperature}")
            logger.info(f"LivingRoom temperature is comfortable: {current_temperature}")
            time.sleep(TEMP_CHANGE_DURATION_WINDOW)

    # Trigger cleaning robot in LivingRoom
    for cleaning_robot in living_room_lights:
        if isinstance(cleaning_robot, Actuator):
            cleaning_robot.turn_on()
            cleaning_robot.daily_routine()

    # Simulate light intensity changes in the living room
    for i in range(5):
        # Get a random light intensity reading for the living room
        current_light_intensity = living_room_temp_sensor.get_reading()

        # Adjust the light intensity if necessary
        if current_light_intensity < LIGHT_INTENSITY_LOW:
            print(f"LivingRoom light intensity is too low: {current_light_intensity}")
            logger.warning(f"LivingRoom light intensity is too low: {current_light_intensity}")
            # Turn on all lights in the living room
            for light in living_room_lights:
                if isinstance(light, Actuator):
                    light.turn_on()
            time.sleep(TEMP_CHANGE_DURATION_WINDOW)
        elif current_light_intensity > LIGHT_INTENSITY_HIGH:
            print(f"LivingRoom light intensity is too high: {current_light_intensity}")
            logger.warning(f"LivingRoom light intensity is too high: {current_light_intensity}")
            # Turn off all lights in the living room
            for light in living_room_lights:
                if isinstance(light, Actuator):
                    light.turn_off()
            time.sleep(TEMP_CHANGE_DURATION_WINDOW)
        else:
            print(f"LivingRoom light intensity is comfortable: {current_light_intensity}")
            logger.info(f"LivingRoom light intensity is comfortable: {current_light_intensity}")
            time.sleep(TEMP_CHANGE_DURATION_WINDOW)

    # Simulate humidity changes in the living room
    for i in range(5):
        # Get a random humidity reading for the living room
        current_humidity = living_room_temp_sensor.get_reading()

        # Adjust the humidity if necessary
        if current_humidity < HUMIDITY_LOW:
            print(f"LivingRoom humidity is too low: {current_humidity}")
            logger.warning(f"LivingRoom humidity is too low: {current_humidity}")
            # Turn on the humidifier in the living room
            for humidifier in living_room_lights:
                if isinstance(humidifier, Actuator):
                    humidifier.increase_humidity()
            time.sleep(TEMP_CHANGE_DURATION_WINDOW)
        elif current_humidity > HUMIDITY_HIGH:
            print(f"LivingRoom humidity is too high: {current_humidity}")
            logger.warning(f"LivingRoom humidity is too high: {current_humidity}")
            # Turn on the dehumidifier in the living room (not implemented in this example)
            # ...
            time.sleep(TEMP_CHANGE_DURATION_WINDOW)
        else:
            print(f"LivingRoom humidity is comfortable: {current_humidity}")
            logger.info(f"LivingRoom humidity is comfortable: {current_humidity}")
            time.sleep(TEMP_CHANGE_DURATION_WINDOW)

    # Turn off all lights in the living room
    for light in living_room_lights:
        if isinstance(light, Actuator):
            light.turn_off()

    # Print a summary of the home
    for room in home:
        room.print_info()

    print("Exiting the program.")


if __name__ == "__main__":
    main()

# **Explanation:**

# 1. **Import necessary modules:** 
#    - `home.home_plan`: Contains functions for creating the home plan and retrieving room/sensor/actuator information.
#    - `home.sensor`: Contains the `Sensor` class and its subclasses.
#    - `home.actuator`: Contains the `Actuator` class and its subclasses.
#    - `home.config`: Contains configuration settings like temperature thresholds.
#    - `home.logger_config`: Provides logging functionality.
#    - `time`: Used for simulating delays.

# 2. **`main` function:**
#    - **Create the home plan:** Calls `home_plan()` to initialize the home with rooms, sensors, and actuators.
#    - **Retrieve components:**
#       - `get_room`: Retrieves the "LivingRoom" from the `home` plan.
#       - `get_all_sensors`: Retrieves all "IndoorTemperature" sensors in the home.
#       - `get_room_actuators`: Retrieves all actuators in the "LivingRoom".
#    - **Simulate temperature changes:**
#       - **Loop through a set of iterations:**
#           - **Get a random temperature reading:** Calls the `get_reading` method of a temperature sensor in the "LivingRoom".
#           - **Adjust the temperature:**
#               - If the temperature is too low, turn on the heater.
#               - If the temperature is too high, turn on the AC.
#           - **Wait for a specified duration:** This simulates the time it takes for the temperature to change.
#    - **Trigger cleaning robot:**
#       - Find the cleaning robot in the "LivingRoom" and start its daily cleaning routine.
#    - **Simulate light intensity changes:**
#       - **Loop through a set of iterations:**
#           - **Get a random light intensity reading:** Calls the `get_reading` method of a light sensor in the "LivingRoom".
#           - **Adjust light intensity:**
#               - If light intensity is too low, turn on all lights in the "LivingRoom".
#               - If light intensity is too high, turn off all lights in the "LivingRoom".
#           - **Wait for a specified duration:** Simulates the time it takes for the light intensity to change.
#    - **Simulate humidity changes:**
#       - **Loop through a set of iterations:**
#           - **Get a random humidity reading:** Calls the `get_reading` method of a humidity sensor in the "LivingRoom".
#           - **Adjust humidity:**
#               - If humidity is too low, increase the humidity using a humidifier.
#               - If humidity is too high, decrease the humidity using a dehumidifier (not implemented in this example).
#           - **Wait for a specified duration:** Simulates the time it takes for the humidity to change.
#    - **Turn off all lights in the "LivingRoom".**
#    - **Print a summary of the home:** Calls `print_info()` for each room in the `home` plan.
#    - **Exit the program.**

# **Key points:**

# - The code simulates a smart home environment using temperature, light intensity, and humidity changes.
# - It demonstrates how to interact with sensors and actuators using the defined classes.
# - The logic for adjusting temperature, light intensity, and humidity is based on the provided configuration thresholds.
# - The code uses logging to keep track of actions and events.

# **To run this code:**

# 1. Ensure you have the necessary Python modules installed (e.g., `time`, `random`).
# 2. Make sure the `home` folder exists and contains the files `sensor.py`, `actuator.py`, `home_plan.py`, and `config.py`.
# 3. Run the `function.py` file from the `functions` folder.
