from home.home_plan import home_plan, get_room, get_room_sensors, get_room_actuators, get_all_sensors, \
    get_all_actuators
from home.sensor import IndoorTemperatureSensor, HumiditySensor, LightIntensiveSensor, SmokeSensor, OutdoorTemperatureSensor
from home.actuator import Heater, AC, CoffeeMachine, Window, Door, Curtain, CleaningRobot, NotificationSender, MusicPlayer, \
    Light, SmartTV, SmartSocket, Humidifier
from home.config import TEMP_LOW, TEMP_HIGH, HUMIDITY_LOW, HUMIDITY_HIGH, LIGHT_INTENSITY_LOW, LIGHT_INTENSITY_HIGH, \
    TEMP_CHANGE_DURATION_WINDOW, DAILY_ROUTINE_DURATION
import time
from home.logger_config import logger

home = home_plan()


def check_temperature(room_name, target_temperature):
    room = get_room(home, room_name)
    if room is not None:
        sensors = get_room_sensors(home, room_name)
        if sensors is not None:
            for sensor in sensors:
                if sensor.sensor_type == "IndoorTemperature":
                    current_temperature = sensor.get_reading()
                    if current_temperature is not None:
                        print(f"The current temperature in {room_name} is: {current_temperature}")
                        if current_temperature < target_temperature:
                            print(f"The temperature is below the target temperature. Turning on the heater...")
                            heaters = get_room_actuators(home, room_name)
                            if heaters is not None:
                                for heater in heaters:
                                    if heater.actuator_type == "Heater":
                                        heater.turn_on()
                                        heater.set_target_temperature(target_temperature)
                                        time.sleep(TEMP_CHANGE_DURATION_WINDOW)
                                        break
                        elif current_temperature > target_temperature:
                            print(f"The temperature is above the target temperature. Turning on the AC...")
                            acs = get_room_actuators(home, room_name)
                            if acs is not None:
                                for ac in acs:
                                    if ac.actuator_type == "AC":
                                        ac.turn_on()
                                        ac.set_target_temperature(target_temperature)
                                        time.sleep(TEMP_CHANGE_DURATION_WINDOW)
                                        break
                        else:
                            print(f"The temperature is at the target temperature.")
                        break
    else:
        print(f"Error: No room named {room_name} found.")


def adjust_humidity(room_name, target_humidity):
    room = get_room(home, room_name)
    if room is not None:
        sensors = get_room_sensors(home, room_name)
        if sensors is not None:
            for sensor in sensors:
                if sensor.sensor_type == "Humidity":
                    current_humidity = sensor.get_reading()
                    if current_humidity is not None:
                        print(f"The current humidity in {room_name} is: {current_humidity}")
                        if current_humidity < target_humidity:
                            print(f"The humidity is below the target humidity. Turning on the humidifier...")
                            humidifiers = get_room_actuators(home, room_name)
                            if humidifiers is not None:
                                for humidifier in humidifiers:
                                    if humidifier.actuator_type == "Humidifier":
                                        humidifier.increase_humidity()
                                        time.sleep(TEMP_CHANGE_DURATION_WINDOW)
                                        break
                        elif current_humidity > target_humidity:
                            print(f"The humidity is above the target humidity. Opening windows for ventilation...")
                            windows = get_room_actuators(home, room_name)
                            if windows is not None:
                                for window in windows:
                                    if window.actuator_type == "Window":
                                        window.turn_on()
                                        time.sleep(TEMP_CHANGE_DURATION_WINDOW)
                                        break
                        else:
                            print(f"The humidity is at the target humidity.")
                        break
    else:
        print(f"Error: No room named {room_name} found.")


def adjust_light_intensity(room_name, target_intensity):
    room = get_room(home, room_name)
    if room is not None:
        sensors = get_room_sensors(home, room_name)
        if sensors is not None:
            for sensor in sensors:
                if sensor.sensor_type == "LightIntensive":
                    current_intensity = sensor.get_reading()
                    if current_intensity is not None:
                        print(f"The current light intensity in {room_name} is: {current_intensity}")
                        if current_intensity < target_intensity:
                            print(f"The light intensity is below the target intensity. Turning on the lights...")
                            lights = get_room_actuators(home, room_name)
                            if lights is not None:
                                for light in lights:
                                    if light.actuator_type == "Light":
                                        light.turn_on()
                                        light.set_brightness_level("high")
                                        time.sleep(TEMP_CHANGE_DURATION_WINDOW)
                                        break
                        elif current_intensity > target_intensity:
                            print(f"The light intensity is above the target intensity. Opening curtains for natural light...")
                            curtains = get_room_actuators(home, room_name)
                            if curtains is not None:
                                for curtain in curtains:
                                    if curtain.actuator_type == "Curtain":
                                        curtain.turn_on()
                                        time.sleep(TEMP_CHANGE_DURATION_WINDOW)
                                        break
                        else:
                            print(f"The light intensity is at the target intensity.")
                        break
    else:
        print(f"Error: No room named {room_name} found.")


def check_smoke(room_name):
    room = get_room(home, room_name)
    if room is not None:
        sensors = get_room_sensors(home, room_name)
        if sensors is not None:
            for sensor in sensors:
                if sensor.sensor_type == "Smoke":
                    smoke_level = sensor.get_reading()
                    if smoke_level is not None:
                        if smoke_level > 10:
                            print(f"Smoke detected in {room_name}. Sending an alert...")
                            notification_senders = get_room_actuators(home, room_name)
                            if notification_senders is not None:
                                for sender in notification_senders:
                                    if sender.actuator_type == "NotificationSender":
                                        sender.turn_on()
                                        sender.notification_sender("Smoke detected in " + room_name + "!")
                                        break
                        else:
                            print(f"No smoke detected in {room_name}.")
                        break
    else:
        print(f"Error: No room named {room_name} found.")


def run_cleaning_robot(room_name):
    room = get_room(home, room_name)
    if room is not None:
        cleaning_robots = get_room_actuators(home, room_name)
        if cleaning_robots is not None:
            for robot in cleaning_robots:
                if robot.actuator_type == "CleaningRobot":
                    robot.turn_on()
                    robot.daily_routine()
                    break
    else:
        print(f"Error: No room named {room_name} found.")


def play_music(room_name, playlist):
    room = get_room(home, room_name)
    if room is not None:
        music_players = get_room_actuators(home, room_name)
        if music_players is not None:
            for player in music_players:
                if player.actuator_type == "MusicPlayer":
                    player.turn_on()
                    player.play_music(playlist)
                    break
    else:
        print(f"Error: No room named {room_name} found.")


def turn_on_tv(room_name, channel_name):
    room = get_room(home, room_name)
    if room is not None:
        smart_tvs = get_room_actuators(home, room_name)
        if smart_tvs is not None:
            for tv in smart_tvs:
                if tv.actuator_type == "SmartTV":
                    tv.turn_on()
                    tv.play_channel(channel_name)
                    break
    else:
        print(f"Error: No room named {room_name} found.")


def main():
    while True:
        print("\nChoose an action:")
        print("1. Adjust temperature in a room")
        print("2. Adjust humidity in a room")
        print("3. Adjust light intensity in a room")
        print("4. Check for smoke")
        print("5. Run the cleaning robot")
        print("6. Play music")
        print("7. Turn on the TV")
        print("8. Exit")

        choice = input("Enter your choice (1-8): ")

        if choice == '1':
            room_name = input("Enter the room name: ")
            target_temperature = float(input("Enter the target temperature: "))
            check_temperature(room_name, target_temperature)

        elif choice == '2':
            room_name = input("Enter the room name: ")
            target_humidity = float(input("Enter the target humidity: "))
            adjust_humidity(room_name, target_humidity)

        elif choice == '3':
            room_name = input("Enter the room name: ")
            target_intensity = float(input("Enter the target light intensity: "))
            adjust_light_intensity(room_name, target_intensity)

        elif choice == '4':
            room_name = input("Enter the room name: ")
            check_smoke(room_name)

        elif choice == '5':
            room_name = input("Enter the room name: ")
            run_cleaning_robot(room_name)

        elif choice == '6':
            room_name = input("Enter the room name: ")
            playlist = input("Enter the playlist name: ")
            play_music(room_name, playlist)

        elif choice == '7':
            room_name = input("Enter the room name: ")
            channel_name = input("Enter the channel name: ")
            turn_on_tv(room_name, channel_name)

        elif choice == '8':
            print("Exiting...")
            break

        else:
            print("Invalid choice. Please enter a number between 1 and 8.")


if __name__ == "__main__":
    main()
