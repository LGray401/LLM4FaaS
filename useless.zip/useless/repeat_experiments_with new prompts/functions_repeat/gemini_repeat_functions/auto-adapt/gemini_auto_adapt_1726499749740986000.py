from home.home_plan import home_plan, get_room, get_room_sensors, get_room_actuators, get_all_sensors, \
    get_all_actuators
from home.sensor import IndoorTemperatureSensor, HumiditySensor, LightIntensiveSensor, SmokeSensor, \
    OutdoorTemperatureSensor
from home.actuator import NotificationSender, Light, Window, Curtain, MusicPlayer, Heater, AC, CoffeeMachine, \
    SmartSocket, Door, \
    CleaningRobot, SmartTV
from home.config import TEMP_CHANGE_DURATION_WINDOW, TEMP_LOW, TEMP_HIGH, HUMIDITY_LOW, HUMIDITY_HIGH, \
    LIGHT_INTENSITY_LOW, LIGHT_INTENSITY_HIGH, DAILY_ROUTINE_DURATION
from home.logger_config import logger

# ---------------------------------------------------------------------
# ####################### Functions ########################
# ---------------------------------------------------------------------

# ----------------------------------------
# Sensor related functions
# ----------------------------------------
def get_indoor_temperature(home, room_name):
    """
    Get indoor temperature reading from a specific room.

    Args:
        home: The home plan.
        room_name: The name of the room.

    Returns:
        The indoor temperature reading in degrees Celsius, or None if no indoor temperature sensor is found.
    """
    sensors = get_room_sensors(home, room_name)
    for sensor in sensors:
        if isinstance(sensor, IndoorTemperatureSensor):
            return sensor.get_reading()

    logger.warning(f"No indoor temperature sensor found in {room_name}.")
    return None


def get_humidity(home, room_name):
    """
    Get humidity reading from a specific room.

    Args:
        home: The home plan.
        room_name: The name of the room.

    Returns:
        The humidity reading in percentage, or None if no humidity sensor is found.
    """
    sensors = get_room_sensors(home, room_name)
    for sensor in sensors:
        if isinstance(sensor, HumiditySensor):
            return sensor.get_reading()

    logger.warning(f"No humidity sensor found in {room_name}.")
    return None


def get_light_intensity(home, room_name):
    """
    Get light intensity reading from a specific room.

    Args:
        home: The home plan.
        room_name: The name of the room.

    Returns:
        The light intensity reading in lux, or None if no light intensity sensor is found.
    """
    sensors = get_room_sensors(home, room_name)
    for sensor in sensors:
        if isinstance(sensor, LightIntensiveSensor):
            return sensor.get_reading()

    logger.warning(f"No light intensity sensor found in {room_name}.")
    return None


def get_smoke_level(home, room_name):
    """
    Get smoke level reading from a specific room.

    Args:
        home: The home plan.
        room_name: The name of the room.

    Returns:
        The smoke level reading in percentage, or None if no smoke sensor is found.
    """
    sensors = get_room_sensors(home, room_name)
    for sensor in sensors:
        if isinstance(sensor, SmokeSensor):
            return sensor.get_reading()

    logger.warning(f"No smoke sensor found in {room_name}.")
    return None


def get_outdoor_temperature(home):
    """
    Get outdoor temperature reading.

    Args:
        home: The home plan.

    Returns:
        The outdoor temperature reading in degrees Celsius, or None if no outdoor temperature sensor is found.
    """
    sensors = get_all_sensors(home, "OutdoorTemperature")
    for sensor in sensors:
        return sensor.get_reading()

    logger.warning("No outdoor temperature sensor found.")
    return None


# ----------------------------------------
# Actuator related functions
# ----------------------------------------

def turn_on_light(home, room_name, level_name):
    """
    Turn on the light in a specific room and set its brightness level.

    Args:
        home: The home plan.
        room_name: The name of the room.
        level_name: The desired brightness level ('low', 'medium', or 'high').

    Returns:
        True if the light was turned on successfully, False otherwise.
    """
    actuators = get_room_actuators(home, room_name)
    for actuator in actuators:
        if isinstance(actuator, Light):
            actuator.turn_on()
            actuator.set_brightness_level(level_name)
            return True

    logger.warning(f"No light found in {room_name}.")
    return False


def turn_off_light(home, room_name):
    """
    Turn off the light in a specific room.

    Args:
        home: The home plan.
        room_name: The name of the room.

    Returns:
        True if the light was turned off successfully, False otherwise.
    """
    actuators = get_room_actuators(home, room_name)
    for actuator in actuators:
        if isinstance(actuator, Light):
            actuator.turn_off()
            return True

    logger.warning(f"No light found in {room_name}.")
    return False


def open_window(home, room_name):
    """
    Open a window in a specific room.

    Args:
        home: The home plan.
        room_name: The name of the room.

    Returns:
        True if the window was opened successfully, False otherwise.
    """
    actuators = get_room_actuators(home, room_name)
    for actuator in actuators:
        if isinstance(actuator, Window):
            actuator.turn_on()
            return True

    logger.warning(f"No window found in {room_name}.")
    return False


def close_window(home, room_name):
    """
    Close a window in a specific room.

    Args:
        home: The home plan.
        room_name: The name of the room.

    Returns:
        True if the window was closed successfully, False otherwise.
    """
    actuators = get_room_actuators(home, room_name)
    for actuator in actuators:
        if isinstance(actuator, Window):
            actuator.turn_off()
            return True

    logger.warning(f"No window found in {room_name}.")
    return False


def open_curtain(home, room_name):
    """
    Open the curtain in a specific room.

    Args:
        home: The home plan.
        room_name: The name of the room.

    Returns:
        True if the curtain was opened successfully, False otherwise.
    """
    actuators = get_room_actuators(home, room_name)
    for actuator in actuators:
        if isinstance(actuator, Curtain):
            actuator.turn_on()
            return True

    logger.warning(f"No curtain found in {room_name}.")
    return False


def close_curtain(home, room_name):
    """
    Close the curtain in a specific room.

    Args:
        home: The home plan.
        room_name: The name of the room.

    Returns:
        True if the curtain was closed successfully, False otherwise.
    """
    actuators = get_room_actuators(home, room_name)
    for actuator in actuators:
        if isinstance(actuator, Curtain):
            actuator.turn_off()
            return True

    logger.warning(f"No curtain found in {room_name}.")
    return False


def play_music(home, room_name, playlist):
    """
    Play music on the music player in a specific room.

    Args:
        home: The home plan.
        room_name: The name of the room.
        playlist: The name of the playlist to play.

    Returns:
        True if music playback was started successfully, False otherwise.
    """
    actuators = get_room_actuators(home, room_name)
    for actuator in actuators:
        if isinstance(actuator, MusicPlayer):
            actuator.play_music(playlist)
            return True

    logger.warning(f"No music player found in {room_name}.")
    return False


def turn_on_heater(home, room_name, target_temperature):
    """
    Turn on the heater in a specific room and set the target temperature.

    Args:
        home: The home plan.
        room_name: The name of the room.
        target_temperature: The desired target temperature in degrees Celsius.

    Returns:
        True if the heater was turned on successfully, False otherwise.
    """
    actuators = get_room_actuators(home, room_name)
    for actuator in actuators:
        if isinstance(actuator, Heater):
            actuator.turn_on()
            actuator.set_target_temperature(target_temperature)
            return True

    logger.warning(f"No heater found in {room_name}.")
    return False


def turn_off_heater(home, room_name):
    """
    Turn off the heater in a specific room.

    Args:
        home: The home plan.
        room_name: The name of the room.

    Returns:
        True if the heater was turned off successfully, False otherwise.
    """
    actuators = get_room_actuators(home, room_name)
    for actuator in actuators:
        if isinstance(actuator, Heater):
            actuator.turn_off()
            return True

    logger.warning(f"No heater found in {room_name}.")
    return False


def turn_on_ac(home, room_name, target_temperature):
    """
    Turn on the AC in a specific room and set the target temperature.

    Args:
        home: The home plan.
        room_name: The name of the room.
        target_temperature: The desired target temperature in degrees Celsius.

    Returns:
        True if the AC was turned on successfully, False otherwise.
    """
    actuators = get_room_actuators(home, room_name)
    for actuator in actuators:
        if isinstance(actuator, AC):
            actuator.turn_on()
            actuator.set_target_temperature(target_temperature)
            return True

    logger.warning(f"No AC found in {room_name}.")
    return False


def turn_off_ac(home, room_name):
    """
    Turn off the AC in a specific room.

    Args:
        home: The home plan.
        room_name: The name of the room.

    Returns:
        True if the AC was turned off successfully, False otherwise.
    """
    actuators = get_room_actuators(home, room_name)
    for actuator in actuators:
        if isinstance(actuator, AC):
            actuator.turn_off()
            return True

    logger.warning(f"No AC found in {room_name}.")
    return False


def make_coffee(home, room_name, coffee_type):
    """
    Make coffee in a specific room.

    Args:
        home: The home plan.
        room_name: The name of the room.
        coffee_type: The type of coffee to make.

    Returns:
        True if coffee making was started successfully, False otherwise.
    """
    actuators = get_room_actuators(home, room_name)
    for actuator in actuators:
        if isinstance(actuator, CoffeeMachine):
            actuator.make_coffee(coffee_type)
            return True

    logger.warning(f"No coffee machine found in {room_name}.")
    return False


def turn_on_smart_socket(home, room_name):
    """
    Turn on a smart socket in a specific room.

    Args:
        home: The home plan.
        room_name: The name of the room.

    Returns:
        True if the smart socket was turned on successfully, False otherwise.
    """
    actuators = get_room_actuators(home, room_name)
    for actuator in actuators:
        if isinstance(actuator, SmartSocket):
            actuator.turn_on()
            return True

    logger.warning(f"No smart socket found in {room_name}.")
    return False


def turn_off_smart_socket(home, room_name):
    """
    Turn off a smart socket in a specific room.

    Args:
        home: The home plan.
        room_name: The name of the room.

    Returns:
        True if the smart socket was turned off successfully, False otherwise.
    """
    actuators = get_room_actuators(home, room_name)
    for actuator in actuators:
        if isinstance(actuator, SmartSocket):
            actuator.turn_off()
            return True

    logger.warning(f"No smart socket found in {room_name}.")
    return False


def lock_door(home, room_name):
    """
    Lock the door in a specific room.

    Args:
        home: The home plan.
        room_name: The name of the room.

    Returns:
        True if the door was locked successfully, False otherwise.
    """
    actuators = get_room_actuators(home, room_name)
    for actuator in actuators:
        if isinstance(actuator, Door):
            actuator.lock()
            return True

    logger.warning(f"No door found in {room_name}.")
    return False


def unlock_door(home, room_name):
    """
    Unlock the door in a specific room.

    Args:
        home: The home plan.
        room_name: The name of the room.

    Returns:
        True if the door was unlocked successfully, False otherwise.
    """
    actuators = get_room_actuators(home, room_name)
    for actuator in actuators:
        if isinstance(actuator, Door):
            actuator.unlock()
            return True

    logger.warning(f"No door found in {room_name}.")
    return False


def start_cleaning_robot(home, room_name):
    """
    Start the cleaning robot in a specific room.

    Args:
        home: The home plan.
        room_name: The name of the room.

    Returns:
        True if the cleaning robot was started successfully, False otherwise.
    """
    actuators = get_room_actuators(home, room_name)
    for actuator in actuators:
        if isinstance(actuator, CleaningRobot):
            actuator.turn_on()
            actuator.daily_routine()
            return True

    logger.warning(f"No cleaning robot found in {room_name}.")
    return False


def stop_cleaning_robot(home, room_name):
    """
    Stop the cleaning robot in a specific room.

    Args:
        home: The home plan.
        room_name: The name of the room.

    Returns:
        True if the cleaning robot was stopped successfully, False otherwise.
    """
    actuators = get_room_actuators(home, room_name)
    for actuator in actuators:
        if isinstance(actuator, CleaningRobot):
            actuator.turn_off()
            return True

    logger.warning(f"No cleaning robot found in {room_name}.")
    return False


def send_notification(home, room_name, message):
    """
    Send a notification from a specific room.

    Args:
        home: The home plan.
        room_name: The name of the room.
        message: The message to send.

    Returns:
        True if the notification was sent successfully, False otherwise.
    """
    actuators = get_room_actuators(home, room_name)
    for actuator in actuators:
        if isinstance(actuator, NotificationSender):
            actuator.notification_sender(message)
            return True

    logger.warning(f"No notification sender found in {room_name}.")
    return False


def play_tv_channel(home, room_name, channel_name):
    """
    Play a TV channel on the smart TV in a specific room.

    Args:
        home: The home plan.
        room_name: The name of the room.
        channel_name: The name of the channel to play.

    Returns:
        True if channel playback was started successfully, False otherwise.
    """
    actuators = get_room_actuators(home, room_name)
    for actuator in actuators:
        if isinstance(actuator, SmartTV):
            actuator.play_channel(channel_name)
            return True

    logger.warning(f"No smart TV found in {room_name}.")
    return False


# ----------------------------------------
# Control functions
# ----------------------------------------
def adjust_temperature(home, room_name):
    """
    Adjust the temperature in a specific room based on the current temperature and the configured thresholds.

    Args:
        home: The home plan.
        room_name: The name of the room.
    """
    indoor_temp = get_indoor_temperature(home, room_name)
    if indoor_temp is not None:
        if indoor_temp < TEMP_LOW:
            # Turn on the heater to reach the target temperature
            turn_on_heater(home, room_name, TEMP_HIGH)
            logger.info(f"Turning on heater in {room_name} to reach {TEMP_HIGH}°C.")
        elif indoor_temp > TEMP_HIGH:
            # Turn on the AC to reach the target temperature
            turn_on_ac(home, room_name, TEMP_LOW)
            logger.info(f"Turning on AC in {room_name} to reach {TEMP_LOW}°C.")
        else:
            # Turn off the heater and AC, temperature is within desired range
            turn_off_heater(home, room_name)
            turn_off_ac(home, room_name)
            logger.info(f"Temperature in {room_name} is within desired range.")


def adjust_humidity(home, room_name):
    """
    Adjust the humidity in a specific room based on the current humidity and the configured thresholds.

    Args:
        home: The home plan.
        room_name: The name of the room.
    """
    humidity = get_humidity(home, room_name)
    if humidity is not None:
        if humidity < HUMIDITY_LOW:
            # Turn on the humidifier to increase humidity
            # TODO: Implement humidifier control logic
            logger.info(f"Turning on humidifier in {room_name} to increase humidity.")
        elif humidity > HUMIDITY_HIGH:
            # Turn on a dehumidifier to decrease humidity
            # TODO: Implement dehumidifier control logic
            logger.info(f"Turning on dehumidifier in {room_name} to decrease humidity.")
        else:
            # Turn off any humidity adjustment devices, humidity is within desired range
            # TODO: Implement logic to turn off humidity adjustment devices
            logger.info(f"Humidity in {room_name} is within desired range.")


def adjust_light_intensity(home, room_name):
    """
    Adjust the light intensity in a specific room based on the current light intensity and the configured thresholds.

    Args:
        home: The home plan.
        room_name: The name of the room.
    """
    light_intensity = get_light_intensity(home, room_name)
    if light_intensity is not None:
        if light_intensity < LIGHT_INTENSITY_LOW:
            # Turn on the light to reach the desired intensity
            turn_on_light(home, room_name, 'high')
            logger.info(f"Turning on light in {room_name} to reach desired intensity.")
        elif light_intensity > LIGHT_INTENSITY_HIGH:
            # Turn off the light, light intensity is too high
            turn_off_light(home, room_name)
            logger.info(f"Turning off light in {room_name} as intensity is too high.")
        else:
            # Maintain current light intensity, it's within desired range
            logger.info(f"Light intensity in {room_name} is within desired range.")


# ---------------------------------------------------------------------
# ####################### Main function ########################
# ---------------------------------------------------------------------
def main():
    """
    Main function for the smart home system.
    """
    home = home_plan()
    # Turn on light
    # turn_on_light(home, "LivingRoom", "medium")
    # Turn off light
    # turn_off_light(home, "LivingRoom")
    # Play music
    # play_music(home, "LivingRoom", "Rock")
    # Play TV channel
    # play_tv_channel(home, "LivingRoom", "Discovery Channel")
    # Send a notification
    # send_notification(home, "LivingRoom", "This is a test notification.")
    # Adjust temperature
    # adjust_temperature(home, "LivingRoom")
    # Adjust humidity
    # adjust_humidity(home, "LivingRoom")
    # Adjust light intensity
    # adjust_light_intensity(home, "LivingRoom")
    # Turn on heater
    # turn_on_heater(home, "LivingRoom", 22)
    # Turn off heater
    # turn_off_heater(home, "LivingRoom")
    # Turn on AC
    # turn_on_ac(home, "LivingRoom", 25)
    # Turn off AC
    # turn_off_ac(home, "LivingRoom")
    # Make coffee
    # make_coffee(home, "Kitchen", "Espresso")
    # Turn on smart socket
    # turn_on_smart_socket(home, "LivingRoom")
    # Turn off smart socket
    # turn_off_smart_socket(home, "LivingRoom")
    # Lock door
    # lock_door(home, "LivingRoom")
    # Unlock door
    # unlock_door(home, "LivingRoom")
    # Start cleaning robot
    # start_cleaning_robot(home, "LivingRoom")
    # Stop cleaning robot
    # stop_cleaning_robot(home, "LivingRoom")
    # Get indoor temperature
    # print(f"Indoor temperature in LivingRoom: {get_indoor_temperature(home, 'LivingRoom')}°C")
    # Get humidity
    # print(f"Humidity in LivingRoom: {get_humidity(home, 'LivingRoom')}%")
    # Get light intensity
    # print(f"Light intensity in LivingRoom: {get_light_intensity(home, 'LivingRoom')} lux")
    # Get smoke level
    # print(f"Smoke level in Kitchen: {get_smoke_level(home, 'Kitchen')}%")
    # Get outdoor temperature
    # print(f"Outdoor temperature: {get_outdoor_temperature(home)}°C")

    # Simulate a loop for automatic adjustments
    while True:
        for room_name in ["LivingRoom", "Bedroom", "Kitchen", "Bathroom"]:
            adjust_temperature(home, room_name)
            adjust_humidity(home, room_name)
            adjust_light_intensity(home, room_name)
        time.sleep(TEMP_CHANGE_DURATION_WINDOW)


if __name__ == "__main__":
    main()

# This code provides a robust foundation for your smart home project. Here's a breakdown of its key features:

# **Sensors:**

# * The code retrieves readings from various sensors in your home.
# * It handles different sensor types, including indoor temperature, humidity, light intensity, smoke level, and outdoor temperature.
# * It gracefully handles scenarios where sensors are not found in a room.

# **Actuators:**

# * The code controls various actuators in your home.
# * It provides functions for turning on/off lights, opening/closing windows and curtains, playing music, controlling heaters and ACs, making coffee, managing smart sockets, locking/unlocking doors, starting/stopping cleaning robots, sending notifications, and playing TV channels.
# * It ensures that actions are performed only on available actuators, and it provides informative error messages if an actuator is not found.

# **Control Functions:**

# * The code implements logic to automatically adjust the temperature, humidity, and light intensity based on configured thresholds.
# * These functions ensure that your home environment remains comfortable and safe without manual intervention.

# **Main Function:**

# * The `main()` function provides a starting point for your smart home system.
# * It includes examples of how to use the sensor and actuator functions to interact with your home environment.
# * It also demonstrates a loop for continuous monitoring and automatic adjustments.

# **Integration and Expansion:**

# * This code can be easily integrated into your existing smart home project.
# * You can further extend the code by adding new sensor and actuator types and implementing additional control logic to suit your specific needs.

# **Logging:**

# * The code utilizes a logger to record events and potential errors.
# * This information can be helpful for debugging and understanding the system's behavior.

# By incorporating this code into your project, you can significantly enhance the capabilities of your smart home system, creating a more comfortable, convenient, and energy-efficient living environment. Remember to adapt the code to match the specific sensors and actuators used in your project and to implement any custom control logic you require.
