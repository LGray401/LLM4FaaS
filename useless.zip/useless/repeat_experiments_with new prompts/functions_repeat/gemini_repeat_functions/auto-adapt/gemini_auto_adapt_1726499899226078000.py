from home.home_plan import home_plan, get_room, get_room_sensors, get_room_actuators, get_all_sensors, \
    get_all_actuators
from home.sensor import IndoorTemperatureSensor, HumiditySensor, LightIntensiveSensor, SmokeSensor, \
    OutdoorTemperatureSensor
from home.actuator import NotificationSender, Light, Window, Curtain, MusicPlayer, Heater, AC, CoffeeMachine, \
    SmartSocket, Door, \
    CleaningRobot, SmartTV, Humidifier
from home.config import TEMP_LOW, TEMP_HIGH, HUMIDITY_LOW, HUMIDITY_HIGH, LIGHT_INTENSITY_LOW, LIGHT_INTENSITY_HIGH, \
    TEMP_CHANGE_DURATION_WINDOW, DAILY_ROUTINE_DURATION

# import time


def main():
    """
    Main function for the smart home system.
    """

    home = home_plan()

    # Example usage:

    # Turn on the lights in the Living Room
    living_room = get_room(home, "LivingRoom")
    if living_room:
        living_room_lights = get_room_actuators(home, "LivingRoom")
        if living_room_lights:
            for light in living_room_lights:
                if light.actuator_type == "Light":
                    light.turn_on()

    # Set the target temperature of the AC in the Bedroom to 22 degrees
    bedroom = get_room(home, "Bedroom")
    if bedroom:
        bedroom_ac = get_room_actuators(home, "Bedroom")
        if bedroom_ac:
            for ac in bedroom_ac:
                if ac.actuator_type == "AC":
                    ac.set_target_temperature(22)

    # Get the current temperature in the Kitchen
    kitchen = get_room(home, "Kitchen")
    if kitchen:
        kitchen_temp_sensors = get_room_sensors(home, "Kitchen")
        if kitchen_temp_sensors:
            for sensor in kitchen_temp_sensors:
                if sensor.sensor_type == "IndoorTemperature":
                    sensor.turn_on()
                    current_temperature = sensor.get_reading()

    # Play music in the Living Room
    living_room = get_room(home, "LivingRoom")
    if living_room:
        living_room_music_players = get_room_actuators(home, "LivingRoom")
        if living_room_music_players:
            for music_player in living_room_music_players:
                if music_player.actuator_type == "MusicPlayer":
                    music_player.play_music("Pop Music")

    # Turn on the cleaning robot in the Bedroom
    bedroom = get_room(home, "Bedroom")
    if bedroom:
        bedroom_cleaning_robots = get_room_actuators(home, "Bedroom")
        if bedroom_cleaning_robots:
            for cleaning_robot in bedroom_cleaning_robots:
                if cleaning_robot.actuator_type == "CleaningRobot":
                    cleaning_robot.turn_on()
                    cleaning_robot.daily_routine()

    # Get the light intensity in the Living Room
    living_room = get_room(home, "LivingRoom")
    if living_room:
        living_room_light_intensity_sensors = get_room_sensors(home, "LivingRoom")
        if living_room_light_intensity_sensors:
            for sensor in living_room_light_intensity_sensors:
                if sensor.sensor_type == "LightIntensive":
                    sensor.turn_on()
                    current_light_intensity = sensor.get_reading()

    # Check if the temperature in the Living Room is too high
    living_room = get_room(home, "LivingRoom")
    if living_room:
        living_room_temperature_sensors = get_room_sensors(home, "LivingRoom")
        if living_room_temperature_sensors:
            for sensor in living_room_temperature_sensors:
                if sensor.sensor_type == "IndoorTemperature":
                    sensor.turn_on()
                    current_temperature = sensor.get_reading()
                    if current_temperature > TEMP_HIGH:
                        print(f"The temperature in the Living Room is too high: {current_temperature}°C")
                        # Turn on the AC to cool down the room
                        living_room_ac = get_room_actuators(home, "LivingRoom")
                        if living_room_ac:
                            for ac in living_room_ac:
                                if ac.actuator_type == "AC":
                                    ac.turn_on()
                                    ac.set_target_temperature(TEMP_HIGH - 1)

    # Check if the humidity in the Bathroom is too low
    bathroom = get_room(home, "Bathroom")
    if bathroom:
        bathroom_humidity_sensors = get_room_sensors(home, "Bathroom")
        if bathroom_humidity_sensors:
            for sensor in bathroom_humidity_sensors:
                if sensor.sensor_type == "Humidity":
                    sensor.turn_on()
                    current_humidity = sensor.get_reading()
                    if current_humidity < HUMIDITY_LOW:
                        print(f"The humidity in the Bathroom is too low: {current_humidity}%")
                        # Turn on the humidifier to increase the humidity
                        bathroom_humidifier = get_room_actuators(home, "Bathroom")
                        if bathroom_humidifier:
                            for humidifier in bathroom_humidifier:
                                if humidifier.actuator_type == "Humidifier":
                                    humidifier.increase_humidity()

    # Check if the light intensity in the Living Room is too low
    living_room = get_room(home, "LivingRoom")
    if living_room:
        living_room_light_intensity_sensors = get_room_sensors(home, "LivingRoom")
        if living_room_light_intensity_sensors:
            for sensor in living_room_light_intensity_sensors:
                if sensor.sensor_type == "LightIntensive":
                    sensor.turn_on()
                    current_light_intensity = sensor.get_reading()
                    if current_light_intensity < LIGHT_INTENSITY_LOW:
                        print(
                            f"The light intensity in the Living Room is too low: {current_light_intensity} lux")
                        # Turn on the lights in the Living Room
                        living_room_lights = get_room_actuators(home, "LivingRoom")
                        if living_room_lights:
                            for light in living_room_lights:
                                if light.actuator_type == "Light":
                                    light.turn_on()

    # Check if there is smoke in the Kitchen
    kitchen = get_room(home, "Kitchen")
    if kitchen:
        kitchen_smoke_sensors = get_room_sensors(home, "Kitchen")
        if kitchen_smoke_sensors:
            for sensor in kitchen_smoke_sensors:
                if sensor.sensor_type == "Smoke":
                    sensor.turn_on()
                    smoke_level = sensor.get_reading()
                    if smoke_level > 0:
                        print(f"Smoke detected in the Kitchen! Smoke level: {smoke_level}%")
                        # Send a notification to the user
                        kitchen_notification_sender = get_room_actuators(home, "Kitchen")
                        if kitchen_notification_sender:
                            for notification_sender in kitchen_notification_sender:
                                if notification_sender.actuator_type == "NotificationSender":
                                    notification_sender.notification_sender(
                                        "Smoke detected in the Kitchen! Please check it out.")

    # Check if the outdoor temperature is too cold
    balcony = get_room(home, "Balcony")
    if balcony:
        balcony_outdoor_temp_sensors = get_room_sensors(home, "Balcony")
        if balcony_outdoor_temp_sensors:
            for sensor in balcony_outdoor_temp_sensors:
                if sensor.sensor_type == "OutdoorTemperature":
                    sensor.turn_on()
                    current_temperature = sensor.get_reading()
                    if current_temperature < TEMP_LOW:
                        print(f"The outdoor temperature is too cold: {current_temperature}°C")
                        # Send a notification to the user
                        all_notification_senders = get_all_actuators(home, "NotificationSender")
                        if all_notification_senders:
                            for notification_sender in all_notification_senders:
                                notification_sender.notification_sender(
                                    f"The outdoor temperature is too cold: {current_temperature}°C")

    # Check if the outdoor temperature is too hot
    balcony = get_room(home, "Balcony")
    if balcony:
        balcony_outdoor_temp_sensors = get_room_sensors(home, "Balcony")
        if balcony_outdoor_temp_sensors:
            for sensor in balcony_outdoor_temp_sensors:
                if sensor.sensor_type == "OutdoorTemperature":
                    sensor.turn_on()
                    current_temperature = sensor.get_reading()
                    if current_temperature > TEMP_HIGH:
                        print(f"The outdoor temperature is too hot: {current_temperature}°C")
                        # Send a notification to the user
                        all_notification_senders = get_all_actuators(home, "NotificationSender")
                        if all_notification_senders:
                            for notification_sender in all_notification_senders:
                                notification_sender.notification_sender(
                                    f"The outdoor temperature is too hot: {current_temperature}°C")

    # Check if the humidity in the Living Room is too high
    living_room = get_room(home, "LivingRoom")
    if living_room:
        living_room_humidity_sensors = get_room_sensors(home, "LivingRoom")
        if living_room_humidity_sensors:
            for sensor in living_room_humidity_sensors:
                if sensor.sensor_type == "Humidity":
                    sensor.turn_on()
                    current_humidity = sensor.get_reading()
                    if current_humidity > HUMIDITY_HIGH:
                        print(f"The humidity in the Living Room is too high: {current_humidity}%")
                        # Turn on the AC to dry the room
                        living_room_ac = get_room_actuators(home, "LivingRoom")
                        if living_room_ac:
                            for ac in living_room_ac:
                                if ac.actuator_type == "AC":
                                    ac.turn_on()
                                    ac.set_target_temperature(TEMP_HIGH - 1)

    # # Simulate a change in temperature over time
    # for _ in range(10):
    #     # Simulate a 1-degree increase in temperature in the Living Room every 5 seconds
    #     living_room = get_room(home, "LivingRoom")
    #     if living_room:
    #         living_room_temperature_sensors = get_room_sensors(home, "LivingRoom")
    #         if living_room_temperature_sensors:
    #             for sensor in living_room_temperature_sensors:
    #                 if sensor.sensor_type == "IndoorTemperature":
    #                     sensor.turn_on()
    #                     current_temperature = sensor.get_reading()
    #                     sensor._generate_reading = lambda: current_temperature + 1
    #                     print(f"The temperature in the Living Room is now: {current_temperature}°C")
    #                     time.sleep(5)
    #
    #     # Simulate a 1-degree decrease in temperature in the Bedroom every 5 seconds
    #     bedroom = get_room(home, "Bedroom")
    #     if bedroom:
    #         bedroom_temperature_sensors = get_room_sensors(home, "Bedroom")
    #         if bedroom_temperature_sensors:
    #             for sensor in bedroom_temperature_sensors:
    #                 if sensor.sensor_type == "IndoorTemperature":
    #                     sensor.turn_on()
    #                     current_temperature = sensor.get_reading()
    #                     sensor._generate_reading = lambda: current_temperature - 1
    #                     print(f"The temperature in the Bedroom is now: {current_temperature}°C")
    #                     time.sleep(5)

    # You can add more logic here to handle other events and conditions,
    # such as user commands, time-based schedules, and so on.

    # # Check if the time is 7:00 AM
    # current_time = datetime.datetime.now()
    # if current_time.hour == 7 and current_time.minute == 0:
    #     # Turn on the lights in the Living Room
    #     living_room = get_room(home, "LivingRoom")
    #     if living_room:
    #         living_room_lights = get_room_actuators(home, "LivingRoom")
    #         if living_room_lights:
    #             for light in living_room_lights:
    #                 if light.actuator_type == "Light":
    #                     light.turn_on()
    #
    # # Check if the time is 9:00 PM
    # current_time = datetime.datetime.now()
    # if current_time.hour == 21 and current_time.minute == 0:
    #     # Turn off the lights in the Living Room
    #     living_room = get_room(home, "LivingRoom")
    #     if living_room:
    #         living_room_lights = get_room_actuators(home, "LivingRoom")
    #         if living_room_lights:
    #             for light in living_room_lights:
    #                 if light.actuator_type == "Light":
    #                     light.turn_off()

    # Continue monitoring the sensors and actuators and responding to events
    # indefinitely.
    while True:
        # ...
        pass


if __name__ == "__main__":
    main()