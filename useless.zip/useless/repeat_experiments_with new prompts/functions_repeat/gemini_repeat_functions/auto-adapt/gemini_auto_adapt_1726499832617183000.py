from home.home_plan import home_plan, get_room, get_room_sensors, get_room_actuators, get_all_sensors, \
    get_all_actuators, print_home_plan
from home.sensor import IndoorTemperatureSensor, HumiditySensor, LightIntensiveSensor, SmokeSensor, \
    OutdoorTemperatureSensor
from home.actuator import NotificationSender, Light, Window, Curtain, MusicPlayer, Heater, AC, CoffeeMachine, \
    SmartSocket, Door, \
    CleaningRobot, SmartTV
from home.config import TEMP_CHANGE_DURATION_WINDOW, TEMP_LOW, TEMP_HIGH, HUMIDITY_LOW, HUMIDITY_HIGH, \
    LIGHT_INTENSITY_LOW, LIGHT_INTENSITY_HIGH
from home.logger_config import logger

import time


def main():
    home = home_plan()
    print_home_plan(home)

    # Example 1: Control room temperature
    living_room = get_room(home, "LivingRoom")
    living_room_sensors = get_room_sensors(home, "LivingRoom")
    living_room_actuators = get_room_actuators(home, "LivingRoom")

    for sensor in living_room_sensors:
        if isinstance(sensor, IndoorTemperatureSensor):
            living_room_temp_sensor = sensor

    for actuator in living_room_actuators:
        if isinstance(actuator, Heater):
            living_room_heater = actuator
        if isinstance(actuator, AC):
            living_room_ac = actuator

    # Turn on temperature sensor and get reading
    living_room_temp_sensor.turn_on()
    current_temperature = living_room_temp_sensor.get_reading()

    # Set target temperature and adjust heater/AC accordingly
    target_temperature = 22
    living_room_heater.set_target_temperature(target_temperature)
    living_room_ac.set_target_temperature(target_temperature)

    # Simulate temperature change
    for _ in range(TEMP_CHANGE_DURATION_WINDOW):
        current_temperature = living_room_temp_sensor.get_reading()
        living_room_heater.adjust_temperature(current_temperature)
        living_room_ac.adjust_temperature(current_temperature)
        time.sleep(1)

    # Example 2: Control lights
    living_room_lights = get_all_actuators(home, "Light")
    for light in living_room_lights:
        light.turn_on()
        light.set_brightness_level("medium")

    # Example 3: Control cleaning robot
    living_room_cleaning_robot = get_all_actuators(home, "CleaningRobot")[0]
    living_room_cleaning_robot.turn_on()
    living_room_cleaning_robot.daily_routine()

    # Example 4: Control notification sender
    living_room_notification_sender = get_all_actuators(home, "NotificationSender")[0]
    living_room_notification_sender.turn_on()
    living_room_notification_sender.notification_sender("This is a test notification.")

    # Example 5: Control coffee machine
    kitchen = get_room(home, "Kitchen")
    kitchen_actuators = get_room_actuators(home, "Kitchen")
    for actuator in kitchen_actuators:
        if isinstance(actuator, CoffeeMachine):
            kitchen_coffee_machine = actuator

    kitchen_coffee_machine.turn_on()
    kitchen_coffee_machine.make_coffee("Latte")

    # Example 6: Control smart TV
    living_room_smart_tv = get_all_actuators(home, "SmartTV")[0]
    living_room_smart_tv.turn_on()
    living_room_smart_tv.play_channel("CNN")

    # Example 7: Control window and curtain
    living_room_windows = get_all_actuators(home, "Window")
    living_room_curtain = get_all_actuators(home, "Curtain")[0]

    # Simulate light intensity change
    for _ in range(TEMP_CHANGE_DURATION_WINDOW):
        for sensor in living_room_sensors:
            if isinstance(sensor, LightIntensiveSensor):
                current_light_intensity = sensor.get_reading()

        if current_light_intensity < LIGHT_INTENSITY_LOW:
            # Open window and open curtain
            for window in living_room_windows:
                window.turn_on()
            living_room_curtain.turn_on()
        elif current_light_intensity > LIGHT_INTENSITY_HIGH:
            # Close window and close curtain
            for window in living_room_windows:
                window.turn_off()
            living_room_curtain.turn_off()
        time.sleep(1)

    # Example 8: Control music player
    living_room_music_player = get_all_actuators(home, "MusicPlayer")[0]
    living_room_music_player.turn_on()
    living_room_music_player.play_music("Pop playlist")

    # Example 9: Control humidifier
    bathroom = get_room(home, "Bathroom")
    bathroom_actuators = get_room_actuators(home, "Bathroom")
    for actuator in bathroom_actuators:
        if isinstance(actuator, Humidifier):
            bathroom_humidifier = actuator

    # Simulate humidity change
    for _ in range(TEMP_CHANGE_DURATION_WINDOW):
        for sensor in bathroom.sensors:
            if isinstance(sensor, HumiditySensor):
                current_humidity = sensor.get_reading()

        if current_humidity < HUMIDITY_LOW:
            bathroom_humidifier.increase_humidity()
        elif current_humidity > HUMIDITY_HIGH:
            bathroom_humidifier.decrease_humidity()
        time.sleep(1)


if __name__ == "__main__":
    main()

# **Explanation:**

# 1. **Imports:** The code imports necessary classes and functions from the `home` package, including sensors, actuators, home plan management, and configuration settings.
# 2. **`main()` Function:** This is the entry point of the script.
# 3. **Home Plan Initialization:** The `home_plan()` function creates the home structure with rooms and their components (sensors and actuators).
# 4. **Room Access:** The `get_room()` function retrieves a specific room based on its name.
# 5. **Sensor and Actuator Retrieval:** Functions `get_room_sensors()`, `get_room_actuators()`, `get_all_sensors()`, and `get_all_actuators()` are used to access specific sensors and actuators.
# 6. **Example Scenarios:** The code includes several example scenarios to demonstrate how to interact with different devices:
#     - **Temperature Control:** The example demonstrates how to control the temperature in the living room using a heater and AC.
#     - **Light Control:** The example shows how to turn on lights and adjust brightness levels.
#     - **Cleaning Robot Control:** The example demonstrates how to start the daily cleaning routine of the robot.
#     - **Notification Control:** The example shows how to send a notification message.
#     - **Coffee Machine Control:** The example demonstrates how to make a coffee.
#     - **Smart TV Control:** The example shows how to play a channel on the TV.
#     - **Window and Curtain Control:** The example demonstrates how to control the window and curtain based on light intensity.
#     - **Music Player Control:** The example shows how to play a music playlist.
#     - **Humidifier Control:** The example demonstrates how to control humidity levels in the bathroom.

# **Key Points:**

# - **Event-Driven Approach:** The code uses a simulation of events (like temperature changes, light intensity changes) to trigger actions on the devices.
# - **Configuration Settings:** The `config.py` file provides configuration parameters for thresholds, duration, etc.
# - **Object-Oriented Programming:** The code uses classes to model sensors, actuators, and rooms, allowing for modular and reusable code.
# - **Logging:** The code includes logging statements to track events and errors.

# This `function.py` file demonstrates a basic implementation of a smart home system, showcasing how different devices can be controlled and interacted with. You can expand upon this framework by adding more devices, sensors, and functionalities as needed for your project.
