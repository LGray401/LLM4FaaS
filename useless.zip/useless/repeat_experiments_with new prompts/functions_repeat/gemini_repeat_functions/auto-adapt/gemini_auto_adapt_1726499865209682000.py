from home.home_plan import home_plan, get_room, get_room_sensors, get_room_actuators, get_all_sensors, \
    get_all_actuators
from home.sensor import IndoorTemperatureSensor, HumiditySensor, LightIntensiveSensor, SmokeSensor, \
    OutdoorTemperatureSensor
from home.actuator import NotificationSender, Light, Window, Curtain, MusicPlayer, Heater, AC, CoffeeMachine, \
    SmartSocket, Door, \
    CleaningRobot, SmartTV, Humidifier
from home.config import TEMP_LOW, TEMP_HIGH, HUMIDITY_LOW, HUMIDITY_HIGH, LIGHT_INTENSITY_LOW, LIGHT_INTENSITY_HIGH, \
    TEMP_CHANGE_DURATION_WINDOW, DAILY_ROUTINE_DURATION
import time

# This file contains the main function for the smart home project.
# It defines the core logic for managing sensors and actuators, including tasks such as:
# - Checking sensor readings and triggering actuators based on defined thresholds and rules.
# - Executing daily routines for actuators like cleaning robots.
# - Providing functions to interact with the smart home, such as turning on/off devices, setting target temperatures, etc.

def main():
    """
    The main function for the smart home project.
    """

    home = home_plan()  # Create the home plan with rooms and components

    # Example usage of functions
    # Example 1: Check temperature in LivingRoom and adjust AC accordingly
    # living_room = get_room(home, "LivingRoom")
    # if living_room:
    #     temperature_sensors = get_room_sensors(home, "LivingRoom")
    #     if temperature_sensors:
    #         for sensor in temperature_sensors:
    #             if isinstance(sensor, IndoorTemperatureSensor):
    #                 current_temperature = sensor.get_reading()
    #                 if current_temperature:
    #                     print(f"Current temperature in LivingRoom: {current_temperature}")
    #                     ac_units = get_all_actuators(home, "AC")
    #                     for ac in ac_units:
    #                         if ac.room_name == "LivingRoom":
    #                             ac.adjust_temperature(current_temperature)
    #                             print(f"Adjusted AC status in LivingRoom: {ac.status}")
    #                             break

    # Example 2: Turn on the lights in Bedroom
    # bedroom = get_room(home, "Bedroom")
    # if bedroom:
    #     lights = get_room_actuators(home, "Bedroom")
    #     if lights:
    #         for light in lights:
    #             if isinstance(light, Light):
    #                 light.turn_on()
    #                 print(f"Turned on the light in Bedroom: {light.id}")
    #                 break

    # Example 3: Start daily cleaning routine for CleaningRobot in LivingRoom
    # living_room = get_room(home, "LivingRoom")
    # if living_room:
    #     cleaning_robots = get_room_actuators(home, "LivingRoom")
    #     if cleaning_robots:
    #         for robot in cleaning_robots:
    #             if isinstance(robot, CleaningRobot):
    #                 robot.turn_on()
    #                 robot.daily_routine()
    #                 print(f"Started daily cleaning routine for robot: {robot.id}")
    #                 break

    # Example 4: Play music in LivingRoom
    # living_room = get_room(home, "LivingRoom")
    # if living_room:
    #     music_players = get_room_actuators(home, "LivingRoom")
    #     if music_players:
    #         for music_player in music_players:
    #             if isinstance(music_player, MusicPlayer):
    #                 music_player.turn_on()
    #                 music_player.play_music("My Favorite Playlist")
    #                 print(f"Playing music in LivingRoom: {music_player.id}")
    #                 break

    # Example 5: Send a notification
    # living_room = get_room(home, "LivingRoom")
    # if living_room:
    #     notification_senders = get_room_actuators(home, "LivingRoom")
    #     if notification_senders:
    #         for sender in notification_senders:
    #             if isinstance(sender, NotificationSender):
    #                 sender.notification_sender("Reminder: Don't forget to take out the trash!")
    #                 break

    # Example 6: Adjust humidity in LivingRoom
    # living_room = get_room(home, "LivingRoom")
    # if living_room:
    #     humidity_sensors = get_room_sensors(home, "LivingRoom")
    #     if humidity_sensors:
    #         for sensor in humidity_sensors:
    #             if isinstance(sensor, HumiditySensor):
    #                 current_humidity = sensor.get_reading()
    #                 if current_humidity:
    #                     print(f"Current humidity in LivingRoom: {current_humidity}")
    #                     humidifiers = get_all_actuators(home, "Humidifier")
    #                     for humidifier in humidifiers:
    #                         if humidifier.room_name == "LivingRoom":
    #                             if current_humidity < HUMIDITY_LOW:
    #                                 humidifier.increase_humidity()
    #                                 print(f"Increasing humidity in LivingRoom")
    #                             elif current_humidity > HUMIDITY_HIGH:
    #                                 humidifier.decrease_humidity()
    #                                 print(f"Decreasing humidity in LivingRoom")
    #                             break

    while True:
        # Check temperature in each room
        for room_name in ["LivingRoom", "Bedroom", "Kitchen", "Bathroom"]:
            room = get_room(home, room_name)
            if room:
                temperature_sensors = get_room_sensors(home, room_name)
                if temperature_sensors:
                    for sensor in temperature_sensors:
                        if isinstance(sensor, IndoorTemperatureSensor):
                            current_temperature = sensor.get_reading()
                            if current_temperature:
                                print(f"Current temperature in {room_name}: {current_temperature}")
                                # Adjust AC/Heater based on temperature thresholds
                                ac_units = get_all_actuators(home, "AC")
                                heaters = get_all_actuators(home, "Heater")
                                for ac in ac_units:
                                    if ac.room_name == room_name:
                                        ac.adjust_temperature(current_temperature)
                                        print(f"Adjusted AC status in {room_name}: {ac.status}")
                                        break
                                for heater in heaters:
                                    if heater.room_name == room_name:
                                        heater.adjust_temperature(current_temperature)
                                        print(f"Adjusted Heater status in {room_name}: {heater.status}")
                                        break

        # Check light intensity in each room
        for room_name in ["LivingRoom", "Bedroom", "Kitchen", "Bathroom"]:
            room = get_room(home, room_name)
            if room:
                light_intensity_sensors = get_room_sensors(home, room_name)
                if light_intensity_sensors:
                    for sensor in light_intensity_sensors:
                        if isinstance(sensor, LightIntensiveSensor):
                            current_light_intensity = sensor.get_reading()
                            if current_light_intensity:
                                print(f"Current light intensity in {room_name}: {current_light_intensity}")
                                # Adjust lights based on light intensity thresholds
                                lights = get_room_actuators(home, room_name)
                                for light in lights:
                                    if isinstance(light, Light):
                                        if current_light_intensity < LIGHT_INTENSITY_LOW:
                                            light.turn_on()
                                            print(f"Turned on the light in {room_name}: {light.id}")
                                        elif current_light_intensity > LIGHT_INTENSITY_HIGH:
                                            light.turn_off()
                                            print(f"Turned off the light in {room_name}: {light.id}")
                                        break

        # Check humidity in each room
        for room_name in ["LivingRoom", "Bedroom", "Kitchen", "Bathroom"]:
            room = get_room(home, room_name)
            if room:
                humidity_sensors = get_room_sensors(home, room_name)
                if humidity_sensors:
                    for sensor in humidity_sensors:
                        if isinstance(sensor, HumiditySensor):
                            current_humidity = sensor.get_reading()
                            if current_humidity:
                                print(f"Current humidity in {room_name}: {current_humidity}")
                                # Adjust humidifiers based on humidity thresholds
                                humidifiers = get_all_actuators(home, "Humidifier")
                                for humidifier in humidifiers:
                                    if humidifier.room_name == room_name:
                                        if current_humidity < HUMIDITY_LOW:
                                            humidifier.increase_humidity()
                                            print(f"Increasing humidity in {room_name}")
                                        elif current_humidity > HUMIDITY_HIGH:
                                            humidifier.decrease_humidity()
                                            print(f"Decreasing humidity in {room_name}")
                                        break

        # Check smoke sensors in Kitchen
        kitchen = get_room(home, "Kitchen")
        if kitchen:
            smoke_sensors = get_room_sensors(home, "Kitchen")
            if smoke_sensors:
                for sensor in smoke_sensors:
                    if isinstance(sensor, SmokeSensor):
                        smoke_level = sensor.get_reading()
                        if smoke_level:
                            print(f"Smoke level in Kitchen: {smoke_level}")
                            # Trigger notification if smoke level is high
                            notification_senders = get_all_actuators(home, "NotificationSender")
                            for sender in notification_senders:
                                sender.notification_sender("Smoke detected in Kitchen! Evacuate!")
                                break

        # Run daily routines for cleaning robots
        for room_name in ["LivingRoom", "Bedroom"]:
            room = get_room(home, room_name)
            if room:
                cleaning_robots = get_room_actuators(home, room_name)
                if cleaning_robots:
                    for robot in cleaning_robots:
                        if isinstance(robot, CleaningRobot):
                            robot.daily_routine()
                            print(f"Started daily cleaning routine for robot: {robot.id}")
                            break

        # Wait for a specified duration before checking sensors again
        time.sleep(TEMP_CHANGE_DURATION_WINDOW)


if __name__ == "__main__":
    main()