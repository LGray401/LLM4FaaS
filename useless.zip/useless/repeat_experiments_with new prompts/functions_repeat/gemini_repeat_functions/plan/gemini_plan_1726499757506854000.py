from home.home_plan import home_plan, get_room, get_room_actuators, get_room_sensors, get_all_sensors, \
    get_all_actuators
from home.sensor import IndoorTemperatureSensor, HumiditySensor, LightIntensiveSensor, SmokeSensor
from home.actuator import Heater, AC, CoffeeMachine, Light, Curtain, Door, NotificationSender, MusicPlayer, \
    CleaningRobot, SmartTV
from home.config import TEMP_LOW, TEMP_HIGH, HUMIDITY_LOW, HUMIDITY_HIGH, LIGHT_INTENSITY_LOW, LIGHT_INTENSITY_HIGH, \
    TEMP_CHANGE_DURATION_WINDOW, DAILY_ROUTINE_DURATION
from home.logger_config import logger


def morning_plan(home):
    """
    Executes the morning plan: opens curtains, makes coffee.

    Args:
        home (list): A list of Room objects representing the home.
    """

    # Get the living room
    living_room = get_room(home, "LivingRoom")
    if living_room is None:
        return

    # Open the curtains in the living room
    curtains = get_room_actuators(home, "LivingRoom")
    for curtain in curtains:
        if curtain.actuator_type == "Curtain":
            curtain.turn_on()

    # Make coffee in the kitchen
    kitchen = get_room(home, "Kitchen")
    if kitchen is None:
        return
    coffee_machines = get_room_actuators(home, "Kitchen")
    for coffee_machine in coffee_machines:
        if coffee_machine.actuator_type == "CoffeeMachine":
            coffee_machine.make_coffee("Espresso")

    # Turn on music in the living room
    music_players = get_room_actuators(home, "LivingRoom")
    for music_player in music_players:
        if music_player.actuator_type == "MusicPlayer":
            music_player.play_music("Morning playlist")


def leave_home_plan(home):
    """
    Executes the leave home plan: closes the front door, turns off the lights.

    Args:
        home (list): A list of Room objects representing the home.
    """

    # Get the living room
    living_room = get_room(home, "LivingRoom")
    if living_room is None:
        return

    # Close the front door
    doors = get_room_actuators(home, "LivingRoom")
    for door in doors:
        if door.actuator_type == "Door":
            door.lock()

    # Turn off the lights in the living room
    lights = get_room_actuators(home, "LivingRoom")
    for light in lights:
        if light.actuator_type == "Light":
            light.turn_off()


def movie_plan(home):
    """
    Executes the movie plan: closes curtains, dims the lights.

    Args:
        home (list): A list of Room objects representing the home.
    """

    # Get the living room
    living_room = get_room(home, "LivingRoom")
    if living_room is None:
        return

    # Close the curtains in the living room
    curtains = get_room_actuators(home, "LivingRoom")
    for curtain in curtains:
        if curtain.actuator_type == "Curtain":
            curtain.turn_on()

    # Dim the lights in the living room
    lights = get_room_actuators(home, "LivingRoom")
    for light in lights:
        if light.actuator_type == "Light":
            light.set_brightness_level("low")


def temperature_regulation(home):
    """
    Regulates the temperature in the house based on sensors and actuators.

    Args:
        home (list): A list of Room objects representing the home.
    """
    indoor_temp_sensors = get_all_sensors(home, "IndoorTemperature")
    heaters = get_all_actuators(home, "Heater")
    acs = get_all_actuators(home, "AC")

    for sensor in indoor_temp_sensors:
        current_temperature = sensor.get_reading()
        if current_temperature is not None:
            for heater in heaters:
                heater.adjust_temperature(current_temperature)
            for ac in acs:
                ac.adjust_temperature(current_temperature)


def humidity_regulation(home):
    """
    Regulates the humidity in the house based on sensors and actuators.

    Args:
        home (list): A list of Room objects representing the home.
    """
    humidity_sensors = get_all_sensors(home, "Humidity")
    humidifiers = get_all_actuators(home, "Humidifier")

    for sensor in humidity_sensors:
        current_humidity = sensor.get_reading()
        if current_humidity is not None:
            for humidifier in humidifiers:
                if current_humidity < HUMIDITY_LOW:
                    humidifier.increase_humidity()
                elif current_humidity > HUMIDITY_HIGH:
                    humidifier.decrease_humidity()


def light_regulation(home):
    """
    Regulates the light in the house based on sensors and actuators.

    Args:
        home (list): A list of Room objects representing the home.
    """
    light_intensive_sensors = get_all_sensors(home, "LightIntensive")
    lights = get_all_actuators(home, "Light")

    for sensor in light_intensive_sensors:
        current_light_intensity = sensor.get_reading()
        if current_light_intensity is not None:
            for light in lights:
                if current_light_intensity < LIGHT_INTENSITY_LOW:
                    light.turn_on()
                elif current_light_intensity > LIGHT_INTENSITY_HIGH:
                    light.turn_off()


def smoke_detection(home):
    """
    Detects smoke and sends a notification if detected.

    Args:
        home (list): A list of Room objects representing the home.
    """
    smoke_sensors = get_all_sensors(home, "Smoke")
    notification_senders = get_all_actuators(home, "NotificationSender")

    for sensor in smoke_sensors:
        current_smoke_level = sensor.get_reading()
        if current_smoke_level is not None and current_smoke_level > 0:
            for notification_sender in notification_senders:
                notification_sender.notification_sender(
                    f"Smoke detected in {sensor.room_name}, please check!")
                logger.warning("Smoke detected")
                break


def daily_cleaning(home):
    """
    Executes the daily cleaning routine for cleaning robots.

    Args:
        home (list): A list of Room objects representing the home.
    """
    cleaning_robots = get_all_actuators(home, "CleaningRobot")
    for robot in cleaning_robots:
        robot.daily_routine()


def main():
    home = home_plan()

    # Example usage
    morning_plan(home)
    leave_home_plan(home)
    movie_plan(home)
    temperature_regulation(home)
    humidity_regulation(home)
    light_regulation(home)
    smoke_detection(home)
    daily_cleaning(home)


if __name__ == "__main__":
    main()
