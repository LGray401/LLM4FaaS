from home.home_plan import home_plan, get_room, get_room_actuators, get_room_sensors, get_all_sensors, \
    get_all_actuators
from home.sensor import IndoorTemperatureSensor, HumiditySensor, LightIntensiveSensor, SmokeSensor, \
    OutdoorTemperatureSensor
from home.actuator import NotificationSender, Light, Window, Curtain, MusicPlayer, Heater, AC, CoffeeMachine, \
    SmartSocket, Door, \
    CleaningRobot, SmartTV
from home.config import TEMP_LOW, TEMP_HIGH, HUMIDITY_LOW, HUMIDITY_HIGH, LIGHT_INTENSITY_LOW, LIGHT_INTENSITY_HIGH
from home.logger_config import logger

def morning_plan(home):
    print("Starting Morning Plan")
    logger.info("Starting Morning Plan")
    living_room = get_room(home, "LivingRoom")
    # Open the windows
    for window in get_room_actuators(home, "LivingRoom"):
        if window.actuator_type == "Window":
            window.turn_on()
    # Make coffee
    kitchen = get_room(home, "Kitchen")
    for coffee_machine in get_room_actuators(kitchen, "Kitchen"):
        if coffee_machine.actuator_type == "CoffeeMachine":
            coffee_machine.make_coffee("Espresso")


def leave_home_plan(home):
    print("Starting Leave Home Plan")
    logger.info("Starting Leave Home Plan")
    # Turn off the lights
    for light in get_all_actuators(home, "Light"):
        light.turn_off()
    # Close the front door
    front_door = get_room_actuators(home, "LivingRoom")[0]
    if front_door.actuator_type == "Door":
        front_door.lock()


def movie_plan(home):
    print("Starting Movie Plan")
    logger.info("Starting Movie Plan")
    # Close the curtains
    living_room = get_room(home, "LivingRoom")
    for curtain in get_room_actuators(living_room, "LivingRoom"):
        if curtain.actuator_type == "Curtain":
            curtain.turn_on()
    # Dim the lights
    for light in get_room_actuators(living_room, "LivingRoom"):
        if light.actuator_type == "Light":
            light.set_brightness_level("low")


def auto_adjust_temperature(home):
    print("Starting Auto Adjust Temperature Plan")
    logger.info("Starting Auto Adjust Temperature Plan")
    # Adjust AC and heater based on temperature and humidity readings
    for room in home:
        for temp_sensor in get_room_sensors(home, room.name):
            if temp_sensor.sensor_type == "IndoorTemperature":
                current_temperature = temp_sensor.get_reading()
                for heater in get_room_actuators(home, room.name):
                    if heater.actuator_type == "Heater":
                        heater.adjust_temperature(current_temperature)
                for ac in get_room_actuators(home, room.name):
                    if ac.actuator_type == "AC":
                        ac.adjust_temperature(current_temperature)
    
def auto_adjust_light(home):
    print("Starting Auto Adjust Light Plan")
    logger.info("Starting Auto Adjust Light Plan")
    # Adjust lights based on light intensity readings
    for room in home:
        for light_sensor in get_room_sensors(home, room.name):
            if light_sensor.sensor_type == "LightIntensive":
                current_light_intensity = light_sensor.get_reading()
                for light in get_room_actuators(home, room.name):
                    if light.actuator_type == "Light":
                        if current_light_intensity < LIGHT_INTENSITY_LOW:
                            light.turn_on()
                            light.set_brightness_level("high")
                        elif current_light_intensity > LIGHT_INTENSITY_HIGH:
                            light.turn_off()
    
def auto_adjust_humidity(home):
    print("Starting Auto Adjust Humidity Plan")
    logger.info("Starting Auto Adjust Humidity Plan")
    # Adjust humidifier based on humidity readings
    for room in home:
        for humidity_sensor in get_room_sensors(home, room.name):
            if humidity_sensor.sensor_type == "Humidity":
                current_humidity = humidity_sensor.get_reading()
                for humidifier in get_room_actuators(home, room.name):
                    if humidifier.actuator_type == "Humidifier":
                        if current_humidity < HUMIDITY_LOW:
                            humidifier.increase_humidity()
                        elif current_humidity > HUMIDITY_HIGH:
                            humidifier.decrease_humidity()
    
def main():
    home = home_plan()
    # Run morning plan
    morning_plan(home)
    # Run leave home plan
    leave_home_plan(home)
    # Run movie plan
    movie_plan(home)
    # Run auto adjust temperature plan
    auto_adjust_temperature(home)
    # Run auto adjust light plan
    auto_adjust_light(home)
    # Run auto adjust humidity plan
    auto_adjust_humidity(home)
    # Add more plan logic here


if __name__ == "__main__":
    main()

# **Explanation:**

# 1. **Import necessary modules:**
#    - `home.home_plan`: For functions to work with the home plan.
#    - `home.sensor`: For sensor classes.
#    - `home.actuator`: For actuator classes.
#    - `home.config`: For configuration variables.
#    - `home.logger_config`: For logging functionality.

# 2. **Define Plan Functions:**
#    - **`morning_plan(home)`:**
#      - Opens windows in the living room.
#      - Makes coffee in the kitchen.
#    - **`leave_home_plan(home)`:**
#      - Turns off all lights.
#      - Locks the front door.
#    - **`movie_plan(home)`:**
#      - Closes curtains in the living room.
#      - Dims the lights in the living room.
#    - **`auto_adjust_temperature(home)`:**
#      - Retrieves temperature readings from indoor temperature sensors.
#      - Adjusts heaters and AC units based on the temperature and humidity readings.
#    - **`auto_adjust_light(home)`:**
#      - Retrieves light intensity readings from light sensors.
#      - Adjusts lights based on the intensity.
#    - **`auto_adjust_humidity(home)`:**
#      - Retrieves humidity readings from humidity sensors.
#      - Adjusts humidifiers based on the humidity levels.

# 3. **`main()` Function:**
#    - Creates the home plan using `home_plan()`.
#    - Calls the plan functions:
#      - `morning_plan()`.
#      - `leave_home_plan()`.
#      - `movie_plan()`.
#      - `auto_adjust_temperature()`.
#      - `auto_adjust_light()`.
#      - `auto_adjust_humidity()`.

# **Important Notes:**

# - **Sensors and Actuators:** This code assumes you have already defined and instantiated the necessary sensors and actuators in your `sensor.py` and `actuator.py` files.
# - **Configuration:** The code uses configuration values from `config.py`. You can adjust these values to match your specific smart home setup.
# - **Error Handling:** The code includes basic checks and error handling, but you may need to add more robust error handling for production use.
# - **Timing:** This code provides a basic framework for your plans. You can implement more complex timing and scheduling mechanisms based on your needs.
# - **Logic:** You can modify the logic within the plan functions to customize your smart home's behavior based on specific conditions and events.

# **To Use:**

# 1. **Make sure you have the `sensor.py`, `actuator.py`, `home_plan.py`, and `config.py` files in your project.**
# 2. **Place `function.py` in your `functions` folder.**
# 3. **Run the `function.py` file:**
#    ```bash
#    python functions/function.py
#    ```

# This will execute the defined plans and provide output in the console, along with logging information.
