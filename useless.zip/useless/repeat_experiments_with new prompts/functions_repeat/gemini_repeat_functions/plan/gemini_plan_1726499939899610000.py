from home.home_plan import home_plan, get_room, get_room_sensors, get_room_actuators, get_all_sensors, \
    get_all_actuators
from home.sensor import IndoorTemperatureSensor
from home.actuator import Light, Curtain, CoffeeMachine, Door, AC, Heater, SmartTV, MusicPlayer, CleaningRobot
from home.config import TEMP_LOW, TEMP_HIGH, HUMIDITY_LOW, HUMIDITY_HIGH, LIGHT_INTENSITY_LOW, LIGHT_INTENSITY_HIGH
from home.logger_config import logger


def morning_plan(home):
    """
    Morning plan:
    Open the curtains, make coffee
    """
    # Get living room
    living_room = get_room(home, "LivingRoom")

    # Open curtains
    curtains = get_room_actuators(home, "LivingRoom")
    for curtain in curtains:
        if curtain.actuator_type == "Curtain":
            curtain.turn_on()

    # Make coffee
    coffee_machine = get_room_actuators(home, "Kitchen")
    for machine in coffee_machine:
        if machine.actuator_type == "CoffeeMachine":
            machine.make_coffee("Espresso")


def leave_home_plan(home):
    """
    Leave home plan:
    Close the front door, turn off the lights
    """

    # Close the front door
    front_door = get_room_actuators(home, "LivingRoom")
    for door in front_door:
        if door.actuator_type == "Door":
            door.lock()

    # Turn off the lights in all rooms
    for room in home:
        lights = get_room_actuators(home, room.name)
        for light in lights:
            if light.actuator_type == "Light":
                light.turn_off()


def movie_plan(home):
    """
    Movie plan:
    Close the curtains, dim the lights
    """

    # Close the curtains
    curtains = get_room_actuators(home, "LivingRoom")
    for curtain in curtains:
        if curtain.actuator_type == "Curtain":
            curtain.turn_on()

    # Dim the lights
    lights = get_room_actuators(home, "LivingRoom")
    for light in lights:
        if light.actuator_type == "Light":
            light.set_brightness_level("low")

    # Turn on the TV
    tv = get_room_actuators(home, "LivingRoom")
    for t in tv:
        if t.actuator_type == "SmartTV":
            t.turn_on()
            t.play_channel("Netflix")


def temperature_control(home):
    """
    Temperature control:
    Adjust the heater or AC based on temperature readings
    """

    # Get all indoor temperature sensors
    indoor_temp_sensors = get_all_sensors(home, "IndoorTemperature")

    # Iterate through sensors and adjust temperature
    for sensor in indoor_temp_sensors:
        # Get the room of the sensor
        room = get_room(home, sensor.room_name)

        # Get the heater and AC in the room
        heater = None
        ac = None
        for actuator in room.actuators:
            if actuator.actuator_type == "Heater":
                heater = actuator
            elif actuator.actuator_type == "AC":
                ac = actuator

        # Check if both heater and AC are present
        if heater is None or ac is None:
            logger.error(f"Missing heater or AC in {room.name}. Temperature control cannot be performed.")
            print(f"Missing heater or AC in {room.name}. Temperature control cannot be performed.")
            continue

        # Get the temperature reading
        temp = sensor.get_reading()

        # Adjust temperature
        if temp < TEMP_LOW:
            heater.turn_on()
            ac.turn_off()
        elif temp > TEMP_HIGH:
            heater.turn_off()
            ac.turn_on()
        else:
            heater.turn_off()
            ac.turn_off()


def humidity_control(home):
    """
    Humidity control:
    Adjust the humidifier or dehumidifier based on humidity readings
    """

    # Get all humidity sensors
    humidity_sensors = get_all_sensors(home, "Humidity")

    # Iterate through sensors and adjust humidity
    for sensor in humidity_sensors:
        # Get the room of the sensor
        room = get_room(home, sensor.room_name)

        # Get the humidifier and dehumidifier in the room (Placeholder -  Assuming we have actuator for this function)
        humidifier = None
        dehumidifier = None
        for actuator in room.actuators:
            if actuator.actuator_type == "Humidifier":
                humidifier = actuator
            elif actuator.actuator_type == "Dehumidifier":
                dehumidifier = actuator

        # Check if both humidifier and dehumidifier are present
        if humidifier is None or dehumidifier is None:
            logger.error(
                f"Missing humidifier or dehumidifier in {room.name}. Humidity control cannot be performed.")
            print(f"Missing humidifier or dehumidifier in {room.name}. Humidity control cannot be performed.")
            continue

        # Get the humidity reading
        humidity = sensor.get_reading()

        # Adjust humidity
        if humidity < HUMIDITY_LOW:
            humidifier.increase_humidity()
            dehumidifier.turn_off()
        elif humidity > HUMIDITY_HIGH:
            humidifier.turn_off()
            dehumidifier.decrease_humidity()
        else:
            humidifier.turn_off()
            dehumidifier.turn_off()


def light_intensity_control(home):
    """
    Light intensity control:
    Adjust the lights based on light intensity readings
    """

    # Get all light intensity sensors
    light_intensity_sensors = get_all_sensors(home, "LightIntensive")

    # Iterate through sensors and adjust light intensity
    for sensor in light_intensity_sensors:
        # Get the room of the sensor
        room = get_room(home, sensor.room_name)

        # Get the lights in the room
        lights = get_room_actuators(home, room.name)

        # Get the light intensity reading
        light_intensity = sensor.get_reading()

        # Adjust light intensity
        if light_intensity < LIGHT_INTENSITY_LOW:
            for light in lights:
                if light.actuator_type == "Light":
                    light.turn_on()
                    light.set_brightness_level("high")
        elif light_intensity > LIGHT_INTENSITY_HIGH:
            for light in lights:
                if light.actuator_type == "Light":
                    light.set_brightness_level("low")
        else:
            for light in lights:
                if light.actuator_type == "Light":
                    light.set_brightness_level("medium")


def main():
    """
    Main function to execute smart home functions.
    """

    # Create home plan
    home = home_plan()

    # Execute plans
    morning_plan(home)
    leave_home_plan(home)
    movie_plan(home)

    # Control environmental conditions
    temperature_control(home)
    humidity_control(home)
    light_intensity_control(home)


if __name__ == "__main__":
    main()

# **Explanation:**

# 1. **Imports:**
#    - Import necessary classes and functions from `home.home_plan`, `home.sensor`, `home.actuator`, and `home.config`.
#    - Import `logger` from `home.logger_config` for logging.

# 2. **Functions:**
#    - **`morning_plan(home)`:**
#      - Retrieves the living room and kitchen from the home plan.
#      - Opens curtains and makes coffee in the kitchen.
#    - **`leave_home_plan(home)`:**
#      - Locks the front door in the living room.
#      - Turns off the lights in all rooms.
#    - **`movie_plan(home)`:**
#      - Closes curtains in the living room.
#      - Dims the lights in the living room.
#      - Turns on the TV in the living room and plays Netflix.
#    - **`temperature_control(home)`:**
#      - Gets all indoor temperature sensors.
#      - For each sensor:
#        - Gets the room of the sensor.
#        - Gets the heater and AC in the room.
#        - Gets the temperature reading.
#        - Adjusts the heater and AC based on the temperature reading.
#    - **`humidity_control(home)`:**
#      - Gets all humidity sensors.
#      - For each sensor:
#        - Gets the room of the sensor.
#        - Gets the humidifier and dehumidifier in the room.
#        - Gets the humidity reading.
#        - Adjusts the humidifier and dehumidifier based on the humidity reading.
#    - **`light_intensity_control(home)`:**
#      - Gets all light intensity sensors.
#      - For each sensor:
#        - Gets the room of the sensor.
#        - Gets the lights in the room.
#        - Gets the light intensity reading.
#        - Adjusts the light intensity based on the light intensity reading.
#    - **`main()`:**
#      - Creates the home plan.
#      - Executes the plans: `morning_plan`, `leave_home_plan`, `movie_plan`.
#      - Controls environmental conditions: `temperature_control`, `humidity_control`, `light_intensity_control`.

# **Key Improvements:**

# - **Clearer function names:** Function names are descriptive and reflect their purpose.
# - **Modular code:** Functions are separated for better organization and maintainability.
# - **Error handling:** Basic error handling is included for missing actuators and sensors.
# - **Documentation:** Functions have docstrings explaining their purpose.

# **To use this code:**

# 1. Make sure you have the `home` folder with the other code files (`sensor.py`, `actuator.py`, `home_plan.py`, `config.py`) in the same directory as `function.py`.
# 2. Run `function.py` to execute the smart home functions.

# **Remember:**

# - This code is a basic example and can be expanded to include more complex functions and interactions with sensors and actuators.
# - You might need to adjust the `config.py` file to suit your specific home setup and preferences.
# - This code uses simulated sensor readings. You'll need to connect real sensors and actuators to use this in a real-world smart home.