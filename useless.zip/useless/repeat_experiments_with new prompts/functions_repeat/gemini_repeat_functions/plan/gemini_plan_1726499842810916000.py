from home.home_plan import home_plan, get_room, get_room_actuators, get_room_sensors, get_all_actuators, \
    get_all_sensors, print_home_plan
from home.config import TEMP_LOW, TEMP_HIGH, HUMIDITY_LOW, HUMIDITY_HIGH, LIGHT_INTENSITY_LOW, LIGHT_INTENSITY_HIGH
from home.actuator import Heater, AC, CoffeeMachine, Curtain, Light, MusicPlayer, CleaningRobot, Door, NotificationSender, \
    SmartTV
from home.sensor import LightIntensiveSensor, IndoorTemperatureSensor, HumiditySensor
from home.logger_config import logger


def morning_plan(home):
    print("\n---Morning Plan---")
    logger.info("\n---Morning Plan---")

    living_room = get_room(home, "LivingRoom")
    bedroom = get_room(home, "Bedroom")
    kitchen = get_room(home, "Kitchen")

    if living_room is not None and bedroom is not None and kitchen is not None:
        # Living room
        living_room_curtains = get_room_actuators(living_room, "Curtain")
        if living_room_curtains is not None:
            for curtain in living_room_curtains:
                curtain.turn_on()

        # Kitchen
        kitchen_coffee_machine = get_room_actuators(kitchen, "CoffeeMachine")
        if kitchen_coffee_machine is not None:
            for coffee_machine in kitchen_coffee_machine:
                coffee_machine.turn_on()
                coffee_machine.make_coffee("Americano")
    else:
        print(f"Some room not found, Cannot execute morning plan")
        logger.warning(format("Some room not found, Cannot execute morning plan"))


def leave_home_plan(home):
    print("\n---Leave Home Plan---")
    logger.info("\n---Leave Home Plan---")

    living_room = get_room(home, "LivingRoom")
    bedroom = get_room(home, "Bedroom")
    kitchen = get_room(home, "Kitchen")
    bathroom = get_room(home, "Bathroom")

    if living_room is not None and bedroom is not None and kitchen is not None and bathroom is not None:
        # Living room
        living_room_lights = get_room_actuators(living_room, "Light")
        if living_room_lights is not None:
            for light in living_room_lights:
                light.turn_off()
        living_room_door = get_room_actuators(living_room, "Door")
        if living_room_door is not None:
            for door in living_room_door:
                door.lock()

        # Bedroom
        bedroom_lights = get_room_actuators(bedroom, "Light")
        if bedroom_lights is not None:
            for light in bedroom_lights:
                light.turn_off()

        # Kitchen
        kitchen_lights = get_room_actuators(kitchen, "Light")
        if kitchen_lights is not None:
            for light in kitchen_lights:
                light.turn_off()

        # Bathroom
        bathroom_lights = get_room_actuators(bathroom, "Light")
        if bathroom_lights is not None:
            for light in bathroom_lights:
                light.turn_off()

        # Turn off all music players
        music_players = get_all_actuators(home, "MusicPlayer")
        if music_players is not None:
            for music_player in music_players:
                music_player.turn_off()

    else:
        print(f"Some room not found, Cannot execute leave home plan")
        logger.warning(format("Some room not found, Cannot execute leave home plan"))


def movie_plan(home):
    print("\n---Movie Plan---")
    logger.info("\n---Movie Plan---")

    living_room = get_room(home, "LivingRoom")

    if living_room is not None:
        # Living room
        living_room_curtains = get_room_actuators(living_room, "Curtain")
        if living_room_curtains is not None:
            for curtain in living_room_curtains:
                curtain.turn_off()
        living_room_lights = get_room_actuators(living_room, "Light")
        if living_room_lights is not None:
            for light in living_room_lights:
                light.set_brightness_level("low")
        living_room_smart_tv = get_room_actuators(living_room, "SmartTV")
        if living_room_smart_tv is not None:
            for smart_tv in living_room_smart_tv:
                smart_tv.turn_on()
                smart_tv.play_channel("Netflix")
    else:
        print(f"Living Room not found, Cannot execute movie plan")
        logger.warning(format("Living Room not found, Cannot execute movie plan"))


def daily_routine(home):
    print("\n---Daily Routine---")
    logger.info("\n---Daily Routine---")

    living_room = get_room(home, "LivingRoom")
    bedroom = get_room(home, "Bedroom")
    kitchen = get_room(home, "Kitchen")
    bathroom = get_room(home, "Bathroom")

    if living_room is not None and bedroom is not None and kitchen is not None and bathroom is not None:
        # Cleaning
        living_room_cleaning_robots = get_room_actuators(living_room, "CleaningRobot")
        if living_room_cleaning_robots is not None:
            for cleaning_robot in living_room_cleaning_robots:
                cleaning_robot.turn_on()
                cleaning_robot.daily_routine()
        bedroom_cleaning_robots = get_room_actuators(bedroom, "CleaningRobot")
        if bedroom_cleaning_robots is not None:
            for cleaning_robot in bedroom_cleaning_robots:
                cleaning_robot.turn_on()
                cleaning_robot.daily_routine()
        kitchen_cleaning_robots = get_room_actuators(kitchen, "CleaningRobot")
        if kitchen_cleaning_robots is not None:
            for cleaning_robot in kitchen_cleaning_robots:
                cleaning_robot.turn_on()
                cleaning_robot.daily_routine()
        bathroom_cleaning_robots = get_room_actuators(bathroom, "CleaningRobot")
        if bathroom_cleaning_robots is not None:
            for cleaning_robot in bathroom_cleaning_robots:
                cleaning_robot.turn_on()
                cleaning_robot.daily_routine()
    else:
        print(f"Some room not found, Cannot execute daily routine")
        logger.warning(format("Some room not found, Cannot execute daily routine"))


def temperature_control(home):
    print("\n---Temperature Control---")
    logger.info("\n---Temperature Control---")

    indoor_temp_sensors = get_all_sensors(home, "IndoorTemperature")
    outdoor_temp_sensors = get_all_sensors(home, "OutdoorTemperature")
    heaters = get_all_actuators(home, "Heater")
    acs = get_all_actuators(home, "AC")

    if indoor_temp_sensors is not None and heaters is not None and acs is not None:
        for indoor_temp_sensor in indoor_temp_sensors:
            current_temp = indoor_temp_sensor.get_reading()
            for heater in heaters:
                heater.adjust_temperature(current_temp)
            for ac in acs:
                ac.adjust_temperature(current_temp)

        if outdoor_temp_sensors is not None:
            for outdoor_temp_sensor in outdoor_temp_sensors:
                current_temp = outdoor_temp_sensor.get_reading()
                if current_temp < TEMP_LOW:
                    for heater in heaters:
                        heater.set_target_temperature(TEMP_HIGH)
                elif current_temp > TEMP_HIGH:
                    for ac in acs:
                        ac.set_target_temperature(TEMP_LOW)
    else:
        print(f"Cannot find some sensors and actuators, Cannot execute temperature control.")
        logger.warning(format("Cannot find some sensors and actuators, Cannot execute temperature control."))


def humidity_control(home):
    print("\n---Humidity Control---")
    logger.info("\n---Humidity Control---")

    humidity_sensors = get_all_sensors(home, "Humidity")
    humidifiers = get_all_actuators(home, "Humidifier")

    if humidity_sensors is not None and humidifiers is not None:
        for humidity_sensor in humidity_sensors:
            current_humidity = humidity_sensor.get_reading()
            for humidifier in humidifiers:
                if current_humidity < HUMIDITY_LOW:
                    humidifier.increase_humidity()
                elif current_humidity > HUMIDITY_HIGH:
                    humidifier.decrease_humidity()
    else:
        print(f"Cannot find some sensors and actuators, Cannot execute humidity control.")
        logger.warning(format("Cannot find some sensors and actuators, Cannot execute humidity control."))


def light_control(home):
    print("\n---Light Control---")
    logger.info("\n---Light Control---")

    light_intensive_sensors = get_all_sensors(home, "LightIntensive")
    lights = get_all_actuators(home, "Light")

    if light_intensive_sensors is not None and lights is not None:
        for light_intensive_sensor in light_intensive_sensors:
            current_light_intensity = light_intensive_sensor.get_reading()
            for light in lights:
                if current_light_intensity < LIGHT_INTENSITY_LOW:
                    light.turn_on()
                elif current_light_intensity > LIGHT_INTENSITY_HIGH:
                    light.turn_off()
    else:
        print(f"Cannot find some sensors and actuators, Cannot execute light control.")
        logger.warning(format("Cannot find some sensors and actuators, Cannot execute light control."))


def main():
    home = home_plan()
    # print_home_plan(home)

    # Example execution of plans
    morning_plan(home)
    leave_home_plan(home)
    movie_plan(home)
    daily_routine(home)

    # Example execution of control functions
    temperature_control(home)
    humidity_control(home)
    light_control(home)


if __name__ == "__main__":
    main()