from home.home_plan import home_plan, get_room, get_room_actuators, get_all_actuators, get_all_sensors
from home.sensor import IndoorTemperatureSensor
from home.actuator import Light, Curtain, CoffeeMachine
from home.logger_config import logger

def morning_plan(home):
    """
    Executes the morning plan for the smart home.

    Args:
        home: A list of Room objects representing the home plan.

    Returns:
        None
    """

    # Get the living room
    living_room = get_room(home, "LivingRoom")

    # Open curtains in the living room
    curtains = get_room_actuators(living_room, "Curtain")
    for curtain in curtains:
        curtain.turn_on()

    # Make coffee in the kitchen
    kitchen = get_room(home, "Kitchen")
    coffee_machines = get_room_actuators(kitchen, "CoffeeMachine")
    for coffee_machine in coffee_machines:
        coffee_machine.make_coffee("Espresso")

    logger.info("Morning plan executed successfully.")
    print("Morning plan executed successfully.")

def leave_home_plan(home):
    """
    Executes the leave home plan for the smart home.

    Args:
        home: A list of Room objects representing the home plan.

    Returns:
        None
    """

    # Get the living room and bedroom
    living_room = get_room(home, "LivingRoom")
    bedroom = get_room(home, "Bedroom")

    # Turn off lights in both rooms
    lights = get_all_actuators(home, "Light")
    for light in lights:
        light.turn_off()

    # Close the door in the living room
    doors = get_room_actuators(living_room, "Door")
    for door in doors:
        door.lock()

    logger.info("Leave home plan executed successfully.")
    print("Leave home plan executed successfully.")

def movie_plan(home):
    """
    Executes the movie plan for the smart home.

    Args:
        home: A list of Room objects representing the home plan.

    Returns:
        None
    """

    # Get the living room
    living_room = get_room(home, "LivingRoom")

    # Close curtains in the living room
    curtains = get_room_actuators(living_room, "Curtain")
    for curtain in curtains:
        curtain.turn_off()

    # Dim lights in the living room
    lights = get_room_actuators(living_room, "Light")
    for light in lights:
        light.set_brightness_level("low")

    logger.info("Movie plan executed successfully.")
    print("Movie plan executed successfully.")

if __name__ == "__main__":
    # Create the home plan
    home = home_plan()

    # Execute different plans
    morning_plan(home)
    leave_home_plan(home)
    movie_plan(home)

# **Explanation:**

# 1. **Import necessary modules:**
#    - `home.home_plan`: Contains functions for accessing and manipulating the home plan.
#    - `home.sensor`: Contains classes for different types of sensors (e.g., IndoorTemperatureSensor).
#    - `home.actuator`: Contains classes for different types of actuators (e.g., Light, Curtain, CoffeeMachine).
#    - `home.logger_config`: Provides logging functionalities.

# 2. **Define functions for each plan:**
#    - `morning_plan(home)`: Opens curtains in the living room and makes coffee in the kitchen.
#    - `leave_home_plan(home)`: Turns off lights in the living room and bedroom, closes and locks the door in the living room.
#    - `movie_plan(home)`: Closes curtains and dims lights in the living room.

# 3. **Plan execution:**
#    - The `if __name__ == "__main__":` block creates the `home` plan using `home_plan()` and then calls the `morning_plan()`, `leave_home_plan()`, and `movie_plan()` functions in sequence.

# 4. **Plan logic:**
#    - Each plan function uses functions from `home.home_plan` to:
#      - Get specific rooms using `get_room(home, room_name)`.
#      - Get actuators of specific types from a room using `get_room_actuators(room, actuator_type)`.
#      - Get all actuators of a specific type from the entire home using `get_all_actuators(home, actuator_type)`.
#    - Then, the functions manipulate the actuators by turning them on/off, setting properties (like brightness level for lights), and performing actions specific to the actuator type (like making coffee for CoffeeMachine).

# 5. **Logging and feedback:**
#    - The functions use the `logger` from `home.logger_config` to log actions performed during plan execution.
#    - They also print messages to the console for user feedback.

# **To integrate this `function.py` file into your project:**

# 1. Make sure you have the `functions` folder in your project directory.
# 2. Create the `function.py` file in this folder and paste the provided code into it.
# 3. Import this file in your main application file (e.g., `main.py`) and call the appropriate plan functions when needed.

# **For example:**

from functions.function import morning_plan, leave_home_plan, movie_plan

# ... rest of your code ...

# Example usage
home = home_plan()

# Call the plans
morning_plan(home)
# ... other actions in your application ...
leave_home_plan(home)
# ... more actions ...
movie_plan(home)
