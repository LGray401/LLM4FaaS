from home.home_plan import home_plan, get_room, get_room_sensors, get_room_actuators, get_all_sensors, \
    get_all_actuators
from home.sensor import IndoorTemperatureSensor, HumiditySensor, LightIntensiveSensor, SmokeSensor
from home.actuator import Light, Curtain, CoffeeMachine, Door, Heater, AC, Window, CleaningRobot, NotificationSender, \
    MusicPlayer, SmartTV
from home.config import TEMP_LOW, TEMP_HIGH, HUMIDITY_LOW, HUMIDITY_HIGH, LIGHT_INTENSITY_LOW, LIGHT_INTENSITY_HIGH
from home.logger_config import logger


def morning_plan(home):
    living_room = get_room(home, "LivingRoom")
    if living_room is None:
        return

    # Open curtains
    for curtain in get_room_actuators(home, "LivingRoom"):
        if curtain.actuator_type == "Curtain":
            curtain.turn_on()

    # Make coffee
    for coffee_machine in get_room_actuators(home, "Kitchen"):
        if coffee_machine.actuator_type == "CoffeeMachine":
            coffee_machine.turn_on()
            coffee_machine.make_coffee("Cappuccino")


def leave_home_plan(home):
    living_room = get_room(home, "LivingRoom")
    if living_room is None:
        return

    # Close entry door
    for door in get_room_actuators(home, "LivingRoom"):
        if door.actuator_type == "Door":
            door.lock()

    # Turn off lights
    for light in get_room_actuators(home, "LivingRoom"):
        if light.actuator_type == "Light":
            light.turn_off()


def movie_plan(home):
    living_room = get_room(home, "LivingRoom")
    if living_room is None:
        return

    # Close curtains
    for curtain in get_room_actuators(home, "LivingRoom"):
        if curtain.actuator_type == "Curtain":
            curtain.turn_on()

    # Dim the lights
    for light in get_room_actuators(home, "LivingRoom"):
        if light.actuator_type == "Light":
            light.turn_on()
            light.set_brightness_level("low")


def adjust_temperature(home):
    # Adjust temperature based on sensor readings
    for room in home:
        for sensor in room.sensors:
            if sensor.sensor_type == "IndoorTemperature":
                current_temperature = sensor.get_reading()
                if current_temperature is not None:
                    for heater in room.actuators:
                        if heater.actuator_type == "Heater":
                            heater.adjust_temperature(current_temperature)
                    for ac in room.actuators:
                        if ac.actuator_type == "AC":
                            ac.adjust_temperature(current_temperature)

    # TODO: implement temperature adjustment based on sensor readings
    # You can access sensor readings using sensor.get_reading()
    # You can control actuators based on their methods, e.g., heater.turn_on(), ac.turn_off()
    # Make sure to handle edge cases and potential errors


def adjust_humidity(home):
    for room in home:
        for sensor in room.sensors:
            if sensor.sensor_type == "Humidity":
                current_humidity = sensor.get_reading()
                if current_humidity is not None:
                    for humidifier in room.actuators:
                        if humidifier.actuator_type == "Humidifier":
                            if current_humidity < HUMIDITY_LOW:
                                humidifier.increase_humidity()
                            elif current_humidity > HUMIDITY_HIGH:
                                humidifier.decrease_humidity()


def adjust_light(home):
    for room in home:
        for sensor in room.sensors:
            if sensor.sensor_type == "LightIntensive":
                current_light_intensity = sensor.get_reading()
                if current_light_intensity is not None:
                    for light in room.actuators:
                        if light.actuator_type == "Light":
                            if current_light_intensity < LIGHT_INTENSITY_LOW:
                                light.turn_on()
                            elif current_light_intensity > LIGHT_INTENSITY_HIGH:
                                light.turn_off()


def run_cleaning_robot(home):
    for cleaning_robot in get_all_actuators(home, "CleaningRobot"):
        cleaning_robot.daily_routine()


def main():
    home = home_plan()
    # Example usage of functions
    morning_plan(home)
    leave_home_plan(home)
    movie_plan(home)
    adjust_temperature(home)
    adjust_humidity(home)
    adjust_light(home)
    run_cleaning_robot(home)


if __name__ == "__main__":
    main()

# **Explanation of the `function.py` file:**

# 1. **Imports:** Imports necessary classes and functions from other files in the project.
# 2. **Functions:**
#    - `morning_plan(home)`: Executes the morning plan by opening curtains and making coffee.
#    - `leave_home_plan(home)`: Executes the leave home plan by locking the door and turning off lights.
#    - `movie_plan(home)`: Executes the movie plan by closing curtains and dimming lights.
#    - `adjust_temperature(home)`: Adjusts the temperature in each room based on sensor readings.
#    - `adjust_humidity(home)`: Adjusts humidity in each room based on sensor readings.
#    - `adjust_light(home)`: Adjusts light intensity in each room based on sensor readings.
#    - `run_cleaning_robot(home)`: Starts the daily cleaning routine for the cleaning robot.
# 3. **`main()` Function:** 
#    - Calls the `home_plan()` function to create the home structure.
#    - Calls the various plan functions to demonstrate their usage.

# **Key Points:**

# - **Plan Functions:** Each plan function uses the `get_room()`, `get_room_actuators()`, and `get_all_actuators()` functions to locate and access the relevant actuators for each plan.
# - **Actuator Control:** The functions interact with actuators using methods like `turn_on()`, `turn_off()`, `lock()`, `make_coffee()`, etc. 
# - **Sensor Readings:** The `adjust_temperature()`, `adjust_humidity()`, and `adjust_light()` functions utilize sensor readings obtained using `sensor.get_reading()` to adjust actuator settings.
# - **Logic:** Each function implements the necessary logic for its specific plan or task.

# **How to Use:**

# 1. **Save** the code as `function.py` in the `functions` folder of your project.
# 2. **Call** the desired functions from your main script or other parts of your code. For example, to run the morning plan:
#    ```python
#    from functions.function import morning_plan
#    home = home_plan()  # Get the home structure
#    morning_plan(home)
#    ```

# **Remember to customize the code further to incorporate your specific smart home requirements and functionalities.** 
