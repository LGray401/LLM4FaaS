from home.home_plan import home_plan, get_room, get_room_sensors, get_room_actuators, get_all_sensors, \
    get_all_actuators
from home.sensor import IndoorTemperatureSensor, HumiditySensor, LightIntensiveSensor, SmokeSensor, \
    OutdoorTemperatureSensor
from home.actuator import NotificationSender, Light, Window, Curtain, MusicPlayer, Heater, AC, CoffeeMachine, \
    SmartSocket, Door, \
    CleaningRobot, SmartTV
from home.config import TEMP_LOW, TEMP_HIGH, HUMIDITY_LOW, HUMIDITY_HIGH, LIGHT_INTENSITY_LOW, LIGHT_INTENSITY_HIGH, \
    TEMP_CHANGE_DURATION_WINDOW, DAILY_ROUTINE_DURATION

import time
from home.logger_config import logger

def morning_plan(home):
    """
    Executes the morning plan for the smart home.

    Args:
        home: The smart home object containing rooms and components.
    """
    # Get the living room
    living_room = get_room(home, "LivingRoom")
    if living_room is None:
        return

    # Open the curtains
    curtains = get_room_actuators(home, "LivingRoom")
    if curtains is None:
        return
    for curtain in curtains:
        if curtain.actuator_type == "Curtain":
            curtain.turn_on()
            print(f"Open the curtain in {living_room.name}.")
            logger.info(f"Open the curtain in {living_room.name}.")

    # Make coffee
    kitchen = get_room(home, "Kitchen")
    if kitchen is None:
        return
    coffee_machine = get_room_actuators(home, "Kitchen")
    if coffee_machine is None:
        return
    for machine in coffee_machine:
        if machine.actuator_type == "CoffeeMachine":
            machine.turn_on()
            machine.make_coffee("Latte")
            print(f"Making a Latte in the {kitchen.name}.")
            logger.info(f"Making a Latte in the {kitchen.name}.")


def leave_home_plan(home):
    """
    Executes the leave home plan for the smart home.

    Args:
        home: The smart home object containing rooms and components.
    """
    # Get the living room
    living_room = get_room(home, "LivingRoom")
    if living_room is None:
        return

    # Close the front door
    door = get_room_actuators(home, "LivingRoom")
    if door is None:
        return
    for d in door:
        if d.actuator_type == "Door":
            d.lock()
            print(f"Locking the front door in {living_room.name}.")
            logger.info(f"Locking the front door in {living_room.name}.")

    # Turn off the lights
    lights = get_room_actuators(home, "LivingRoom")
    if lights is None:
        return
    for light in lights:
        if light.actuator_type == "Light":
            light.turn_off()
            print(f"Turning off the light in {living_room.name}.")
            logger.info(f"Turning off the light in {living_room.name}.")


def movie_plan(home):
    """
    Executes the movie plan for the smart home.

    Args:
        home: The smart home object containing rooms and components.
    """
    # Get the living room
    living_room = get_room(home, "LivingRoom")
    if living_room is None:
        return

    # Close the curtains
    curtains = get_room_actuators(home, "LivingRoom")
    if curtains is None:
        return
    for curtain in curtains:
        if curtain.actuator_type == "Curtain":
            curtain.turn_on()
            print(f"Closing the curtain in {living_room.name}.")
            logger.info(f"Closing the curtain in {living_room.name}.")

    # Dim the lights
    lights = get_room_actuators(home, "LivingRoom")
    if lights is None:
        return
    for light in lights:
        if light.actuator_type == "Light":
            light.set_brightness_level("low")
            print(f"Dimming the lights in {living_room.name}.")
            logger.info(f"Dimming the lights in {living_room.name}.")

def check_temperature(home, room_name, target_temperature):
    """
    Checks the temperature in a room and adjusts the AC/Heater accordingly.

    Args:
        home: The smart home object containing rooms and components.
        room_name: The name of the room to check the temperature in.
        target_temperature: The desired temperature for the room.
    """
    room = get_room(home, room_name)
    if room is None:
        return

    # Get the temperature sensors in the room
    sensors = get_room_sensors(home, room_name)
    if sensors is None:
        return
    for sensor in sensors:
        if sensor.sensor_type == "IndoorTemperature":
            current_temperature = sensor.get_reading()
            if current_temperature is None:
                return

            # Adjust AC/Heater
            actuators = get_room_actuators(home, room_name)
            if actuators is None:
                return
            for actuator in actuators:
                if actuator.actuator_type == "AC":
                    actuator.adjust_temperature(current_temperature, target_temperature)
                    print(f"Adjusting the AC in {room_name}.")
                    logger.info(f"Adjusting the AC in {room_name}.")
                elif actuator.actuator_type == "Heater":
                    actuator.adjust_temperature(current_temperature, target_temperature)
                    print(f"Adjusting the Heater in {room_name}.")
                    logger.info(f"Adjusting the Heater in {room_name}.")

def check_humidity(home, room_name, target_humidity):
    """
    Checks the humidity in a room and adjusts the humidifier/dehumidifier accordingly.

    Args:
        home: The smart home object containing rooms and components.
        room_name: The name of the room to check the humidity in.
        target_humidity: The desired humidity for the room.
    """
    room = get_room(home, room_name)
    if room is None:
        return

    # Get the humidity sensors in the room
    sensors = get_room_sensors(home, room_name)
    if sensors is None:
        return
    for sensor in sensors:
        if sensor.sensor_type == "Humidity":
            current_humidity = sensor.get_reading()
            if current_humidity is None:
                return

            # Adjust humidifier/dehumidifier
            actuators = get_room_actuators(home, room_name)
            if actuators is None:
                return
            for actuator in actuators:
                if actuator.actuator_type == "Humidifier":
                    if current_humidity < target_humidity:
                        actuator.increase_humidity()
                        print(f"Increasing humidity in {room_name}.")
                        logger.info(f"Increasing humidity in {room_name}.")
                elif actuator.actuator_type == "Dehumidifier":
                    if current_humidity > target_humidity:
                        actuator.decrease_humidity()
                        print(f"Decreasing humidity in {room_name}.")
                        logger.info(f"Decreasing humidity in {room_name}.")

def check_light_intensity(home, room_name, target_light_intensity):
    """
    Checks the light intensity in a room and adjusts the lights accordingly.

    Args:
        home: The smart home object containing rooms and components.
        room_name: The name of the room to check the light intensity in.
        target_light_intensity: The desired light intensity for the room.
    """
    room = get_room(home, room_name)
    if room is None:
        return

    # Get the light intensity sensors in the room
    sensors = get_room_sensors(home, room_name)
    if sensors is None:
        return
    for sensor in sensors:
        if sensor.sensor_type == "LightIntensive":
            current_light_intensity = sensor.get_reading()
            if current_light_intensity is None:
                return

            # Adjust lights
            actuators = get_room_actuators(home, room_name)
            if actuators is None:
                return
            for actuator in actuators:
                if actuator.actuator_type == "Light":
                    if current_light_intensity < target_light_intensity:
                        actuator.turn_on()
                        print(f"Turning on the light in {room_name}.")
                        logger.info(f"Turning on the light in {room_name}.")
                    else:
                        actuator.turn_off()
                        print(f"Turning off the light in {room_name}.")
                        logger.info(f"Turning off the light in {room_name}.")

def main():
    """
    Main function for the smart home system.
    """
    # Create the home plan
    home = home_plan()

    # Run the morning plan
    morning_plan(home)

    # Simulate some sensor readings and adjust actuators
    # Example: Check temperature in living room and adjust AC
    check_temperature(home, "LivingRoom", 22)
    time.sleep(TEMP_CHANGE_DURATION_WINDOW)  # Simulate time for temperature change
    check_temperature(home, "LivingRoom", 22)

    # Example: Check humidity in kitchen and adjust humidifier
    check_humidity(home, "Kitchen", 40)
    time.sleep(TEMP_CHANGE_DURATION_WINDOW)  # Simulate time for humidity change
    check_humidity(home, "Kitchen", 40)

    # Example: Check light intensity in bedroom and adjust lights
    check_light_intensity(home, "Bedroom", 500)
    time.sleep(TEMP_CHANGE_DURATION_WINDOW)  # Simulate time for light intensity change
    check_light_intensity(home, "Bedroom", 500)

    # Run the leave home plan
    leave_home_plan(home)

    # Run the movie plan
    movie_plan(home)

    # Example: Start daily cleaning routine for cleaning robot in living room
    living_room = get_room(home, "LivingRoom")
    if living_room is not None:
        cleaning_robots = get_room_actuators(home, "LivingRoom")
        if cleaning_robots is not None:
            for robot in cleaning_robots:
                if robot.actuator_type == "CleaningRobot":
                    robot.turn_on()
                    robot.daily_routine()

if __name__ == "__main__":
    main()