from home.home_plan import get_room, get_room_sensors, get_room_actuators, get_all_sensors, get_all_actuators
from home.sensor import IndoorTemperatureSensor
from home.actuator import Light, Window, Curtain, CoffeeMachine, Door, CleaningRobot
from home.config import TEMP_HIGH, TEMP_LOW, HUMIDITY_LOW, HUMIDITY_HIGH, LIGHT_INTENSITY_HIGH, LIGHT_INTENSITY_LOW
from home.logger_config import logger

def morning_plan(home):
    # Open curtains in the Living Room
    living_room = get_room(home, "LivingRoom")
    if living_room:
        curtains = get_room_actuators(home, "LivingRoom")
        for curtain in curtains:
            if curtain.actuator_type == "Curtain":
                curtain.turn_on()

    # Make coffee in the Kitchen
    kitchen = get_room(home, "Kitchen")
    if kitchen:
        coffee_machines = get_room_actuators(home, "Kitchen")
        for coffee_machine in coffee_machines:
            if coffee_machine.actuator_type == "CoffeeMachine":
                coffee_machine.make_coffee("Espresso")

def leave_home_plan(home):
    # Close the door in the Living Room
    living_room = get_room(home, "LivingRoom")
    if living_room:
        doors = get_room_actuators(home, "LivingRoom")
        for door in doors:
            if door.actuator_type == "Door":
                door.lock()

    # Turn off lights in the Living Room
    living_room = get_room(home, "LivingRoom")
    if living_room:
        lights = get_room_actuators(home, "LivingRoom")
        for light in lights:
            if light.actuator_type == "Light":
                light.turn_off()

def movie_plan(home):
    # Close curtains in the Living Room
    living_room = get_room(home, "LivingRoom")
    if living_room:
        curtains = get_room_actuators(home, "LivingRoom")
        for curtain in curtains:
            if curtain.actuator_type == "Curtain":
                curtain.turn_off()

    # Dim lights in the Living Room
    living_room = get_room(home, "LivingRoom")
    if living_room:
        lights = get_room_actuators(home, "LivingRoom")
        for light in lights:
            if light.actuator_type == "Light":
                light.set_brightness_level("low")

def temperature_control(home):
    # Check temperature sensors in each room
    for room in home:
        # Get temperature sensors in the room
        temp_sensors = get_room_sensors(home, room.name)
        for temp_sensor in temp_sensors:
            if temp_sensor.sensor_type == "IndoorTemperature":
                current_temp = temp_sensor.get_reading()
                # Get the corresponding heater and AC in the room
                heaters = get_room_actuators(home, room.name)
                acs = get_room_actuators(home, room.name)
                for heater in heaters:
                    if heater.actuator_type == "Heater":
                        heater.adjust_temperature(current_temp)
                for ac in acs:
                    if ac.actuator_type == "AC":
                        ac.adjust_temperature(current_temp)

def humidity_control(home):
    # Check humidity sensors in each room
    for room in home:
        # Get humidity sensors in the room
        humidity_sensors = get_room_sensors(home, room.name)
        for humidity_sensor in humidity_sensors:
            if humidity_sensor.sensor_type == "Humidity":
                current_humidity = humidity_sensor.get_reading()
                # Get the corresponding humidifier and AC in the room
                humidifiers = get_room_actuators(home, room.name)
                acs = get_room_actuators(home, room.name)
                for humidifier in humidifiers:
                    if humidifier.actuator_type == "Humidifier":
                        if current_humidity < HUMIDITY_LOW:
                            humidifier.increase_humidity()
                        elif current_humidity > HUMIDITY_HIGH:
                            humidifier.decrease_humidity()
                for ac in acs:
                    if ac.actuator_type == "AC":
                        if current_humidity > HUMIDITY_HIGH:
                            ac.turn_on()
                        elif current_humidity < HUMIDITY_LOW:
                            ac.turn_off()

def light_control(home):
    # Check light intensity sensors in each room
    for room in home:
        # Get light intensity sensors in the room
        light_sensors = get_room_sensors(home, room.name)
        for light_sensor in light_sensors:
            if light_sensor.sensor_type == "LightIntensive":
                current_light_intensity = light_sensor.get_reading()
                # Get the corresponding lights in the room
                lights = get_room_actuators(home, room.name)
                for light in lights:
                    if light.actuator_type == "Light":
                        if current_light_intensity < LIGHT_INTENSITY_LOW:
                            light.turn_on()
                        elif current_light_intensity > LIGHT_INTENSITY_HIGH:
                            light.turn_off()

def main():
    home = home_plan()

    # Execute morning plan
    morning_plan(home)

    # Execute leave home plan
    leave_home_plan(home)

    # Execute movie plan
    movie_plan(home)

    # Continuous temperature, humidity, and light control
    while True:
        temperature_control(home)
        humidity_control(home)
        light_control(home)

if __name__ == "__main__":
    main()
