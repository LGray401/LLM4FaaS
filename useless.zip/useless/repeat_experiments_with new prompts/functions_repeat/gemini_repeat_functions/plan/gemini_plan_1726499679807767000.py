from home.home_plan import home_plan, get_room, get_room_sensors, get_room_actuators, get_all_sensors, \
    get_all_actuators
from home.sensor import Sensor
from home.actuator import Actuator
from home.logger_config import logger
from home.config import TEMP_LOW, TEMP_HIGH, HUMIDITY_LOW, HUMIDITY_HIGH, LIGHT_INTENSITY_LOW, LIGHT_INTENSITY_HIGH


def morning_plan(home):
    """Executes the morning plan, including opening curtains and making coffee.

    Args:
        home: The home plan object containing rooms and devices.
    """
    living_room = get_room(home, "LivingRoom")
    if living_room:
        curtains = get_room_actuators(home, "LivingRoom")
        if curtains:
            for curtain in curtains:
                if curtain.actuator_type == "Curtain":
                    print(f"Opening curtain in {living_room.name}")
                    logger.info(f"Opening curtain in {living_room.name}")
                    curtain.turn_on()  # Assuming turn_on() opens the curtain

        kitchen = get_room(home, "Kitchen")
        if kitchen:
            coffee_machine = get_room_actuators(home, "Kitchen")
            if coffee_machine:
                for machine in coffee_machine:
                    if machine.actuator_type == "CoffeeMachine":
                        print(f"Making coffee in {kitchen.name}")
                        logger.info(f"Making coffee in {kitchen.name}")
                        machine.turn_on()
                        machine.make_coffee("Espresso")  # Assuming make_coffee() makes an espresso


def leave_home_plan(home):
    """Executes the leave home plan, including closing the entrance door and turning off lights.

    Args:
        home: The home plan object containing rooms and devices.
    """
    living_room = get_room(home, "LivingRoom")
    if living_room:
        door = get_room_actuators(home, "LivingRoom")
        if door:
            for d in door:
                if d.actuator_type == "Door":
                    print(f"Closing the door in {living_room.name}")
                    logger.info(f"Closing the door in {living_room.name}")
                    d.turn_off()  # Assuming turn_off() closes the door

        lights = get_room_actuators(home, "LivingRoom")
        if lights:
            for light in lights:
                if light.actuator_type == "Light":
                    print(f"Turning off lights in {living_room.name}")
                    logger.info(f"Turning off lights in {living_room.name}")
                    light.turn_off()

    bedroom = get_room(home, "Bedroom")
    if bedroom:
        lights = get_room_actuators(home, "Bedroom")
        if lights:
            for light in lights:
                if light.actuator_type == "Light":
                    print(f"Turning off lights in {bedroom.name}")
                    logger.info(f"Turning off lights in {bedroom.name}")
                    light.turn_off()


def movie_plan(home):
    """Executes the movie plan, including closing curtains and dimming the lights.

    Args:
        home: The home plan object containing rooms and devices.
    """
    living_room = get_room(home, "LivingRoom")
    if living_room:
        curtains = get_room_actuators(home, "LivingRoom")
        if curtains:
            for curtain in curtains:
                if curtain.actuator_type == "Curtain":
                    print(f"Closing curtain in {living_room.name}")
                    logger.info(f"Closing curtain in {living_room.name}")
                    curtain.turn_off()

        lights = get_room_actuators(home, "LivingRoom")
        if lights:
            for light in lights:
                if light.actuator_type == "Light":
                    print(f"Dimming the lights in {living_room.name}")
                    logger.info(f"Dimming the lights in {living_room.name}")
                    light.set_brightness_level("low")


def manage_temperature(home):
    """Manages temperature based on sensors and actuators.

    Args:
        home: The home plan object containing rooms and devices.
    """
    all_temperature_sensors = get_all_sensors(home, "IndoorTemperature")
    if all_temperature_sensors:
        for sensor in all_temperature_sensors:
            if isinstance(sensor, Sensor):
                current_temperature = sensor.get_reading()
                if current_temperature:
                    room_name = sensor.room_name
                    room = get_room(home, room_name)
                    if room:
                        heaters = get_room_actuators(home, room_name)
                        if heaters:
                            for heater in heaters:
                                if heater.actuator_type == "Heater":
                                    print(f"Adjusting heater in {room_name}")
                                    logger.info(f"Adjusting heater in {room_name}")
                                    heater.adjust_temperature(current_temperature)

                        acs = get_room_actuators(home, room_name)
                        if acs:
                            for ac in acs:
                                if ac.actuator_type == "AC":
                                    print(f"Adjusting AC in {room_name}")
                                    logger.info(f"Adjusting AC in {room_name}")
                                    ac.adjust_temperature(current_temperature)

def manage_humidity(home):
    """Manages humidity based on sensors and actuators.

    Args:
        home: The home plan object containing rooms and devices.
    """
    all_humidity_sensors = get_all_sensors(home, "Humidity")
    if all_humidity_sensors:
        for sensor in all_humidity_sensors:
            if isinstance(sensor, Sensor):
                current_humidity = sensor.get_reading()
                if current_humidity:
                    room_name = sensor.room_name
                    room = get_room(home, room_name)
                    if room:
                        humidifiers = get_room_actuators(home, room_name)
                        if humidifiers:
                            for humidifier in humidifiers:
                                if humidifier.actuator_type == "Humidifier":
                                    if current_humidity < HUMIDITY_LOW:
                                        print(f"Increasing humidity in {room_name}")
                                        logger.info(f"Increasing humidity in {room_name}")
                                        humidifier.increase_humidity()
                                    elif current_humidity > HUMIDITY_HIGH:
                                        print(f"Decreasing humidity in {room_name}")
                                        logger.info(f"Decreasing humidity in {room_name}")
                                        humidifier.decrease_humidity()

def manage_light(home):
    """Manages light intensity based on sensors and actuators.

    Args:
        home: The home plan object containing rooms and devices.
    """
    all_light_sensors = get_all_sensors(home, "LightIntensive")
    if all_light_sensors:
        for sensor in all_light_sensors:
            if isinstance(sensor, Sensor):
                current_light_intensity = sensor.get_reading()
                if current_light_intensity:
                    room_name = sensor.room_name
                    room = get_room(home, room_name)
                    if room:
                        lights = get_room_actuators(home, room_name)
                        if lights:
                            for light in lights:
                                if light.actuator_type == "Light":
                                    if current_light_intensity < LIGHT_INTENSITY_LOW:
                                        print(f"Turning on light in {room_name}")
                                        logger.info(f"Turning on light in {room_name}")
                                        light.turn_on()
                                    elif current_light_intensity > LIGHT_INTENSITY_HIGH:
                                        print(f"Turning off light in {room_name}")
                                        logger.info(f"Turning off light in {room_name}")
                                        light.turn_off()

def main():
    """Main function for the smart home system."""
    home = home_plan()

    # Example usage:
    morning_plan(home)
    leave_home_plan(home)
    movie_plan(home)
    manage_temperature(home)
    manage_humidity(home)
    manage_light(home)


if __name__ == "__main__":
    main()

# **Explanation:**

# 1. **Import necessary modules:** Import the required modules from the `home` folder, including `home_plan`, `sensor`, `actuator`, and `logger_config`.
# 2. **`morning_plan()`:**
#    - Gets the living room and kitchen objects from the `home` plan.
#    - Finds curtains in the living room and opens them.
#    - Finds the coffee machine in the kitchen and makes coffee.
# 3. **`leave_home_plan()`:**
#    - Gets the living room and bedroom objects.
#    - Closes the door in the living room.
#    - Turns off lights in both the living room and bedroom.
# 4. **`movie_plan()`:**
#    - Gets the living room object.
#    - Closes the curtains in the living room.
#    - Dim the lights in the living room.
# 5. **`manage_temperature()`:**
#    - Gets all indoor temperature sensors.
#    - Reads the temperature from each sensor.
#    - Adjusts the heaters and ACs in the corresponding rooms based on the temperature readings.
# 6. **`manage_humidity()`:**
#    - Gets all humidity sensors.
#    - Reads the humidity from each sensor.
#    - Adjusts humidifiers in the corresponding rooms based on the humidity readings.
# 7. **`manage_light()`:**
#    - Gets all light intensity sensors.
#    - Reads the light intensity from each sensor.
#    - Turns on or off lights in the corresponding rooms based on the light intensity readings.
# 8. **`main()`:**
#    - Creates the `home` plan object.
#    - Calls the plan functions (`morning_plan`, `leave_home_plan`, `movie_plan`, `manage_temperature`, `manage_humidity`, `manage_light`) to demonstrate their functionality.

# **Key points:**

# - The code uses the classes and functions defined in the `home` folder to interact with the smart home system.
# - The plan functions are responsible for executing specific tasks based on user scenarios.
# - The `manage_temperature`, `manage_humidity`, and `manage_light` functions demonstrate automatic control based on sensor readings.
# - The `logger.info()` function is used to log events for debugging purposes.
# - You need to customize the actions within each plan function based on your specific smart home setup and desired behaviors.

# **To run this code:**

# 1. Make sure the `home` folder containing the `sensor.py`, `actuator.py`, `home_plan.py`, and `config.py` files is in the same directory as `function.py`.
# 2. Execute `function.py` using `python function.py`.

# This code will demonstrate the basic functionality of the smart home system, including executing plans and automatically adjusting devices based on sensor readings. You can extend this code further by adding more plan functions and device management logic.
