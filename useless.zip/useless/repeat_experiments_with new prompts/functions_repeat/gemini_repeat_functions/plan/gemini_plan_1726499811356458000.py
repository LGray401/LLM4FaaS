from home.home_plan import home_plan, get_room, get_room_actuators, get_room_sensors, get_all_sensors, \
    get_all_actuators
from home.sensor import LightIntensiveSensor
from home.actuator import Light, Curtain, CoffeeMachine


def morning_plan(home):
    # Get the Living Room
    living_room = get_room(home, "LivingRoom")
    if living_room is None:
        return

    # Get the actuators
    living_room_actuators = get_room_actuators(home, "LivingRoom")
    if living_room_actuators is None:
        return

    # Open the Curtains
    curtains = get_all_actuators(home, "Curtain")
    for curtain in curtains:
        curtain.turn_on()

    # Make Coffee
    coffee_machine = get_all_actuators(home, "CoffeeMachine")[0]
    if coffee_machine is not None:
        coffee_machine.turn_on()
        coffee_machine.make_coffee("Cappuccino")


def leave_home_plan(home):
    # Get the Living Room
    living_room = get_room(home, "LivingRoom")
    if living_room is None:
        return

    # Get the actuators
    living_room_actuators = get_room_actuators(home, "LivingRoom")
    if living_room_actuators is None:
        return

    # Close the Door
    doors = get_all_actuators(home, "Door")
    for door in doors:
        door.lock()

    # Turn off Lights
    lights = get_all_actuators(home, "Light")
    for light in lights:
        light.turn_off()


def movie_plan(home):
    # Get the Living Room
    living_room = get_room(home, "LivingRoom")
    if living_room is None:
        return

    # Get the actuators
    living_room_actuators = get_room_actuators(home, "LivingRoom")
    if living_room_actuators is None:
        return

    # Close the Curtains
    curtains = get_all_actuators(home, "Curtain")
    for curtain in curtains:
        curtain.turn_on()

    # Dim the Lights
    lights = get_all_actuators(home, "Light")
    for light in lights:
        light.set_brightness_level("low")


if __name__ == '__main__':
    home = home_plan()
    # morning_plan(home)
    # leave_home_plan(home)
    movie_plan(home)