import time
from home.home_plan import home_plan, get_room, get_room_actuators, get_all_actuators
from home.logger_config import logger
from home.config import TEMP_LOW, TEMP_HIGH, HUMIDITY_LOW, HUMIDITY_HIGH, LIGHT_INTENSITY_LOW, LIGHT_INTENSITY_HIGH, \
    DAILY_ROUTINE_DURATION


def morning_plan(home):
    # Get the living room
    living_room = get_room(home, "LivingRoom")
    if living_room is None:
        return

    # Open curtains in the living room
    curtains = get_room_actuators(home, "LivingRoom")
    for curtain in curtains:
        if curtain.actuator_type == "Curtain":
            curtain.turn_on()

    # Make coffee in the kitchen
    kitchen = get_room(home, "Kitchen")
    if kitchen is None:
        return
    coffee_machine = get_room_actuators(home, "Kitchen")
    for coffee_machine in coffee_machine:
        if coffee_machine.actuator_type == "CoffeeMachine":
            coffee_machine.make_coffee("Cappuccino")


def leave_home_plan(home):
    # Get the living room
    living_room = get_room(home, "LivingRoom")
    if living_room is None:
        return

    # Close the front door
    doors = get_room_actuators(home, "LivingRoom")
    for door in doors:
        if door.actuator_type == "Door":
            door.lock()

    # Turn off lights in the living room
    lights = get_room_actuators(home, "LivingRoom")
    for light in lights:
        if light.actuator_type == "Light":
            light.turn_off()


def movie_plan(home):
    # Get the living room
    living_room = get_room(home, "LivingRoom")
    if living_room is None:
        return

    # Close the curtains in the living room
    curtains = get_room_actuators(home, "LivingRoom")
    for curtain in curtains:
        if curtain.actuator_type == "Curtain":
            curtain.turn_off()

    # Dim the lights in the living room
    lights = get_room_actuators(home, "LivingRoom")
    for light in lights:
        if light.actuator_type == "Light":
            light.set_brightness_level("low")

    # Turn on the TV and play a movie
    tv = get_room_actuators(home, "LivingRoom")
    for tv in tv:
        if tv.actuator_type == "SmartTV":
            tv.turn_on()
            tv.play_channel("Netflix")

    # Play some music
    music_players = get_room_actuators(home, "LivingRoom")
    for music_player in music_players:
        if music_player.actuator_type == "MusicPlayer":
            music_player.turn_on()
            music_player.play_music("Relaxing Music")


def daily_cleaning_routine(home):
    # Get all cleaning robots
    cleaning_robots = get_all_actuators(home, "CleaningRobot")

    # Turn on all cleaning robots
    for robot in cleaning_robots:
        robot.turn_on()

    # Start daily cleaning routine for each cleaning robot
    for robot in cleaning_robots:
        robot.daily_routine()


def run_main(home):
    # Print the home plan
    # home = home_plan()
    # print(f"\n---Home Plan---")
    # for room in home:
    #     room.print_info()

    # Start morning plan
    morning_plan(home)

    # Sleep for a few seconds to simulate time passing
    time.sleep(5)

    # Start leave home plan
    leave_home_plan(home)

    # Sleep for a few seconds to simulate time passing
    time.sleep(5)

    # Start movie plan
    movie_plan(home)

    # Sleep for a few seconds to simulate time passing
    time.sleep(5)

    # Start daily cleaning routine
    daily_cleaning_routine(home)

    # Sleep for a few seconds to simulate time passing
    time.sleep(5)

    # End of simulation
    print("Simulation Complete!")
    logger.info("Simulation Complete!")


if __name__ == '__main__':
    # Create the home plan
    home = home_plan()

    # Run the simulation
    run_main(home)