from home.home_plan import get_room, get_room_actuators, get_all_actuators
from home.logger_config import logger
import time

def main():
    home = get_room(home_plan(), "LivingRoom")
    if home is not None:
        actuators = get_room_actuators(home, "LivingRoom")
        if actuators is not None:
            for actuator in actuators:
                if actuator.actuator_type == "Light":
                    actuator.turn_off()
                elif actuator.actuator_type == "AC":
                    actuator.set_target_temperature(26)
                elif actuator.actuator_type == "Window":
                    actuator.turn_on()
    else:
        logger.error("Error: Cannot find living room.")

    home = get_room(home_plan(), "Bedroom")
    if home is not None:
        actuators = get_room_actuators(home, "Bedroom")
        if actuators is not None:
            for actuator in actuators:
                if actuator.actuator_type == "Light":
                    actuator.set_brightness_level("low")
        else:
            logger.error("Error: Cannot find actuators in bedroom.")
    else:
        logger.error("Error: Cannot find bedroom.")

    print("Finished executing commands.")
    time.sleep(5)

if __name__ == "__main__":
    main()

# **Explanation:**

# 1. **Import necessary modules:**
#    - `home.home_plan`: To access functions for retrieving rooms, actuators, and sensors.
#    - `home.logger_config`: For logging purposes.
#    - `time`: To add delays for simulating actions.

# 2. **`main()` function:**
#    - **Retrieve the "LivingRoom":**
#      - Call `get_room` to obtain the "LivingRoom" object.
#      - Check if the room is found (not `None`).
#    - **Control actuators in "LivingRoom":**
#      - If the room is found, get all actuators in the room using `get_room_actuators`.
#      - Iterate through actuators and perform actions based on their type:
#        - **Light:** Turn off the light.
#        - **AC:** Set the target temperature to 26 degrees.
#        - **Window:** Open the window.
#    - **Retrieve the "Bedroom":**
#      - Similar to the LivingRoom retrieval process.
#    - **Control actuators in "Bedroom":**
#      - If the room is found, get all actuators in the room.
#      - Iterate through actuators and perform actions based on their type:
#        - **Light:** Set the brightness level to "low".
#    - **Print completion message:** Inform the user that the commands have been executed.
#    - **Delay execution:** Pause for 5 seconds to allow the user to observe the simulated actions.

# 3. **`if __name__ == "__main__":` block:**
#    - This ensures that the `main()` function is only called when the script is run directly (not imported as a module).

# **To use this `function.py` file:**

# 1. **Place it in the `functions` folder:** Make sure the folder exists in your project directory.
# 2. **Ensure other files are correctly placed:** The `home` folder containing `sensor.py`, `actuator.py`, `home_plan.py`, and `config.py` should be in the same directory as the `functions` folder.
# 3. **Run the script:** From the project's root directory, execute `python functions/function.py`.

# **Important Note:** The provided code assumes you have a `home_plan` function defined in `home_plan.py` that returns a list of rooms. You'll need to create this function based on your specific home structure and components.
