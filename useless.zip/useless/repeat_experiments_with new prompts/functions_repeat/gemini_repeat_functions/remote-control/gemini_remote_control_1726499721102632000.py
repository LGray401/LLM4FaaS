from home.home_plan import home_plan, get_room, get_room_actuators, get_all_actuators
from home.logger_config import logger

def main():
    home = home_plan()

    # Close living room light, dim bedroom lights
    living_room = get_room(home, "LivingRoom")
    if living_room:
        living_room_lights = get_room_actuators(home, "LivingRoom", "Light")
        if living_room_lights:
            for light in living_room_lights:
                light.turn_off()

    bedroom = get_room(home, "Bedroom")
    if bedroom:
        bedroom_lights = get_room_actuators(home, "Bedroom", "Light")
        if bedroom_lights:
            for light in bedroom_lights:
                light.set_brightness_level("low")

    # Set AC to 26 degrees
    all_acs = get_all_actuators(home, "AC")
    if all_acs:
        for ac in all_acs:
            ac.set_target_temperature(26)

    # Open window
    all_windows = get_all_actuators(home, "Window")
    if all_windows:
        for window in all_windows:
            window.turn_on()

    logger.info("All commands executed successfully.")
    print("All commands executed successfully.")

if __name__ == "__main__":
    main()

# **Explanation:**

# 1. **Imports:** Import necessary modules:
#    - `home.home_plan`: Contains functions to access home structure, rooms, and devices.
#    - `home.logger_config`: Used for logging events.

# 2. **`main()` function:** Contains the logic to execute the commands:
#    - **Get home plan:** Calls `home_plan()` to get the home structure.
#    - **Living room light:**
#      - Gets the "LivingRoom" using `get_room()`.
#      - Finds all "Light" actuators in the living room using `get_room_actuators()`.
#      - Turns off each light in the living room.
#    - **Bedroom lights:**
#      - Gets the "Bedroom" using `get_room()`.
#      - Finds all "Light" actuators in the bedroom using `get_room_actuators()`.
#      - Sets the brightness level of each bedroom light to "low" using `set_brightness_level()`.
#    - **AC:**
#      - Gets all "AC" actuators in the house using `get_all_actuators()`.
#      - Sets the target temperature of each AC to 26 degrees Celsius using `set_target_temperature()`.
#    - **Window:**
#      - Gets all "Window" actuators in the house using `get_all_actuators()`.
#      - Turns on each window using `turn_on()`.
#    - **Log success:** Logs a message indicating successful command execution.

# 3. **`if __name__ == "__main__":` block:**
#    - Runs the `main()` function if the script is executed directly.

# **How to Use:**

# 1. Place the `function.py` file in the `functions` folder within your smart home project.
# 2. Ensure the other required files (`sensor.py`, `actuator.py`, `home_plan.py`, `config.py`) are also in their respective folders.
# 3. Run `function.py` to execute the commands.

# This structure assumes that your `home_plan` module has functions to access rooms, devices, and device actions. You can adapt the code to match the specific implementation in your `home_plan` module.
