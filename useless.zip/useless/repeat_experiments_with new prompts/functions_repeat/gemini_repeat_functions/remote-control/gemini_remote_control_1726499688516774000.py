from home.home_plan import home_plan, get_room, get_room_actuators, get_room_sensors, get_all_actuators
from home.config import TEMP_HIGH, TEMP_LOW, HUMIDITY_LOW, HUMIDITY_HIGH, LIGHT_INTENSITY_HIGH, LIGHT_INTENSITY_LOW
from home.logger_config import logger

def main():
    home = home_plan()

    # Close the living room light
    living_room = get_room(home, "LivingRoom")
    if living_room:
        living_room_lights = get_room_actuators(home, "LivingRoom")
        for light in living_room_lights:
            if light.actuator_type == "Light":
                light.turn_off()

    # Dim the bedroom lights
    bedroom = get_room(home, "Bedroom")
    if bedroom:
        bedroom_lights = get_room_actuators(home, "Bedroom")
        for light in bedroom_lights:
            if light.actuator_type == "Light":
                light.set_brightness_level("low")

    # Set the AC to 26 degrees
    living_room = get_room(home, "LivingRoom")
    if living_room:
        living_room_ac = get_room_actuators(home, "LivingRoom")
        for ac in living_room_ac:
            if ac.actuator_type == "AC":
                ac.set_target_temperature(26)

    # Open the window
    living_room = get_room(home, "LivingRoom")
    if living_room:
        living_room_windows = get_room_actuators(home, "LivingRoom")
        for window in living_room_windows:
            if window.actuator_type == "Window":
                window.turn_on()

    # Check and adjust temperature and humidity in all rooms
    for room in home:
        # Get the sensors in the room
        sensors = get_room_sensors(home, room.name)
        # Find the temperature sensor in the room
        temperature_sensor = None
        for sensor in sensors:
            if sensor.sensor_type == "IndoorTemperature":
                temperature_sensor = sensor
                break

        # Find the humidity sensor in the room
        humidity_sensor = None
        for sensor in sensors:
            if sensor.sensor_type == "Humidity":
                humidity_sensor = sensor
                break

        # Adjust the temperature if needed
        if temperature_sensor:
            temperature_reading = temperature_sensor.get_reading()
            if temperature_reading:
                # Find the AC in the room
                ac = None
                for actuator in room.actuators:
                    if actuator.actuator_type == "AC":
                        ac = actuator
                        break

                # Find the heater in the room
                heater = None
                for actuator in room.actuators:
                    if actuator.actuator_type == "Heater":
                        heater = actuator
                        break

                if ac:
                    if temperature_reading > TEMP_HIGH:
                        ac.turn_on()
                    else:
                        ac.turn_off()

                if heater:
                    if temperature_reading < TEMP_LOW:
                        heater.turn_on()
                    else:
                        heater.turn_off()

        # Adjust the humidity if needed
        if humidity_sensor:
            humidity_reading = humidity_sensor.get_reading()
            if humidity_reading:
                # Find the humidifier in the room
                humidifier = None
                for actuator in room.actuators:
                    if actuator.actuator_type == "Humidifier":
                        humidifier = actuator
                        break

                if humidifier:
                    if humidity_reading < HUMIDITY_LOW:
                        humidifier.increase_humidity()
                    elif humidity_reading > HUMIDITY_HIGH:
                        humidifier.decrease_humidity()

        # Check the light intensity and turn on/off the lights automatically
        # Find the light intensive sensor in the room
        light_intensive_sensor = None
        for sensor in sensors:
            if sensor.sensor_type == "LightIntensive":
                light_intensive_sensor = sensor
                break

        # Adjust the light if needed
        if light_intensive_sensor:
            light_intensity_reading = light_intensive_sensor.get_reading()
            if light_intensity_reading:
                # Find the light in the room
                light = None
                for actuator in room.actuators:
                    if actuator.actuator_type == "Light":
                        light = actuator
                        break

                if light:
                    if light_intensity_reading < LIGHT_INTENSITY_LOW:
                        light.turn_on()
                    elif light_intensity_reading > LIGHT_INTENSITY_HIGH:
                        light.turn_off()

        # Check and turn on/off the cleaning robot if needed
        for actuator in room.actuators:
            if actuator.actuator_type == "CleaningRobot":
                if actuator.get_status() == "off":
                    actuator.turn_on()
                break

if __name__ == "__main__":
    main()

# **Explanation:**

# 1. **Import necessary modules:**
#     - `home.home_plan`: Contains functions to create the home plan and access rooms, sensors, and actuators.
#     - `home.config`: Contains configuration values for temperature, humidity, and light intensity thresholds.
#     - `home.logger_config`: Contains the logger configuration for logging information and errors.

# 2. **Define the `main()` function:**
#     - Creates the `home` object using `home_plan()`.
#     - Implements the commands from the functional description:
#         - **Close living room light:** Gets the living room and its lights, then turns them off.
#         - **Dim bedroom lights:** Gets the bedroom and its lights, then sets the brightness level to "low."
#         - **Set AC to 26 degrees:** Gets the living room AC and sets its target temperature.
#         - **Open the window:** Gets the living room window and opens it.
#     - Iterates through each room in the home:
#         - Gets the sensors in the room.
#         - Finds the temperature sensor and humidity sensor in the room.
#         - Adjusts temperature using the AC or heater based on the temperature reading and thresholds.
#         - Adjusts humidity using the humidifier based on the humidity reading and thresholds.
#         - Checks the light intensity and turns on/off the lights automatically.
#         - Checks and turns on the cleaning robot in each room.

# 3. **Run the `main()` function:**
#     - The `if __name__ == "__main__":` block ensures that the `main()` function is executed only when the script is run directly, not when imported as a module.

# **Key points:**

# - The code uses the `home_plan()` function from `home.home_plan` to create the home structure with rooms, sensors, and actuators.
# - The code uses the configuration values from `home.config` to define the thresholds for temperature, humidity, and light intensity.
# - The code uses the logger from `home.logger_config` to log information and errors.
# - The code handles cases where a sensor or actuator might not be found in a room.

# This `function.py` file implements the functional description and provides a basic framework for managing sensors, actuators, and automatic adjustments based on sensor readings and thresholds. You can further expand this code to add more functionality, customize the logic, and integrate with your smart home system.
