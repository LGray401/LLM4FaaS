from home.home_plan import home_plan, get_room, get_room_actuators, get_all_actuators
from home.logger_config import logger


def main():
    """
    Main function for the smart home system.
    """

    # Get the home plan and rooms
    home = home_plan()
    # print(home)
    # Get the living room
    living_room = get_room(home, "LivingRoom")
    # print(living_room)
    # Get the bedroom
    bedroom = get_room(home, "Bedroom")
    # print(bedroom)

    # # Get actuators in the living room
    # living_room_actuators = get_room_actuators(home, "LivingRoom")
    # # print(living_room_actuators)
    # # Get all lights
    # lights = get_all_actuators(home, "Light")
    # # print(lights)

    # Turn off the living room lights
    living_room_lights = get_room_actuators(home, "LivingRoom")
    for actuator in living_room_lights:
        if actuator.actuator_type == "Light":
            actuator.turn_off()

    # Dim the bedroom lights
    bedroom_lights = get_room_actuators(home, "Bedroom")
    for actuator in bedroom_lights:
        if actuator.actuator_type == "Light":
            actuator.set_brightness_level("low")

    # Set the AC to 26 degrees
    living_room_ac = get_room_actuators(home, "LivingRoom")
    for actuator in living_room_ac:
        if actuator.actuator_type == "AC":
            actuator.set_target_temperature(26)

    # Open the windows
    living_room_windows = get_room_actuators(home, "LivingRoom")
    for actuator in living_room_windows:
        if actuator.actuator_type == "Window":
            actuator.turn_on()

    logger.info("All commands executed successfully.")
    print("All commands executed successfully.")


if __name__ == "__main__":
    main()

# **Explanation:**

# 1. **Import necessary modules:**
#    - `from home.home_plan import home_plan, get_room, get_room_actuators, get_all_actuators`: Imports functions for accessing the home plan, rooms, actuators, and sensors.
#    - `from home.logger_config import logger`: Imports the logger for logging events.

# 2. **`main()` function:**
#    - **Get the home plan:**
#      - `home = home_plan()`: Creates the home plan and stores it in the `home` variable.
#    - **Get rooms:**
#      - `living_room = get_room(home, "LivingRoom")`: Gets the living room object.
#      - `bedroom = get_room(home, "Bedroom")`: Gets the bedroom object.
#    - **Turn off living room lights:**
#      - `living_room_lights = get_room_actuators(home, "LivingRoom")`: Gets all actuators in the living room.
#      - Iterates through the actuators, and for each `Light`, calls `turn_off()`.
#    - **Dim bedroom lights:**
#      - `bedroom_lights = get_room_actuators(home, "Bedroom")`: Gets all actuators in the bedroom.
#      - Iterates through the actuators, and for each `Light`, calls `set_brightness_level("low")`.
#    - **Set AC to 26 degrees:**
#      - `living_room_ac = get_room_actuators(home, "LivingRoom")`: Gets all actuators in the living room.
#      - Iterates through the actuators, and for each `AC`, calls `set_target_temperature(26)`.
#    - **Open windows:**
#      - `living_room_windows = get_room_actuators(home, "LivingRoom")`: Gets all actuators in the living room.
#      - Iterates through the actuators, and for each `Window`, calls `turn_on()`.
#    - **Log success:**
#      - `logger.info("All commands executed successfully.")`: Logs that all commands were executed successfully.
#      - `print("All commands executed successfully.")`: Prints the success message to the console.

# 3. **`if __name__ == "__main__":` block:**
#    - Calls the `main()` function when the script is run directly.

# **How to use:**

# 1. **Create `functions/function.py`:** Save this code as `functions/function.py`.
# 2. **Run the script:** Run the script from the root of your project directory. For example, use: `python functions/function.py`.

# This will execute the commands and print the success message to the console. The commands will also be logged to the specified log file in the `home/logger_config.py` file.
