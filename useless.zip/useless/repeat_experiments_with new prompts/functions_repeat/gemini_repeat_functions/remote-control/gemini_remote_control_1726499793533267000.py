from home.home_plan import home_plan, get_room, get_room_actuators, get_room_sensors, get_all_actuators, \
    get_all_sensors
from home.config import TEMP_LOW, TEMP_HIGH, HUMIDITY_LOW, HUMIDITY_HIGH, LIGHT_INTENSITY_LOW, LIGHT_INTENSITY_HIGH
from home.logger_config import logger


def main():
    home = home_plan()
    # print(home)
    # print(get_room(home, "LivingRoom"))
    # print(get_room_sensors(home, "LivingRoom"))
    # print(get_room_actuators(home, "LivingRoom"))

    # turn off living room light, dim bedroom light, set ac to 26 degree, open window
    living_room = get_room(home, "LivingRoom")
    bedroom = get_room(home, "Bedroom")
    if living_room is not None:
        living_room_lights = get_room_actuators(living_room, "Light")
        if living_room_lights is not None:
            for light in living_room_lights:
                light.turn_off()
    else:
        logger.warning(format("Fail to find Living Room."))

    if bedroom is not None:
        bedroom_lights = get_room_actuators(bedroom, "Light")
        if bedroom_lights is not None:
            for light in bedroom_lights:
                light.set_brightness_level("low")
    else:
        logger.warning(format("Fail to find Bed Room."))

    all_ac = get_all_actuators(home, "AC")
    if all_ac is not None:
        for ac in all_ac:
            ac.set_target_temperature(26)
    else:
        logger.warning(format("Fail to find AC."))

    all_windows = get_all_actuators(home, "Window")
    if all_windows is not None:
        for window in all_windows:
            window.turn_on()
    else:
        logger.warning(format("Fail to find Window."))

    # --------------------------------------
    # Auto-Adjust based on sensor reading
    # --------------------------------------
    # --------------------------------------
    # Temperature Adjustment:
    # --------------------------------------
    print(f"------------------------ Temperature Adjustment ------------------------")
    indoor_temp_sensors = get_all_sensors(home, "IndoorTemperature")
    if indoor_temp_sensors is not None:
        for sensor in indoor_temp_sensors:
            sensor.turn_on()
            current_temp = sensor.get_reading()
            # print(current_temp)
            room_name = sensor.room_name
            room = get_room(home, room_name)
            # print(room)
            if room is not None:
                heaters = get_room_actuators(room, "Heater")
                # print(heaters)
                if heaters is not None:
                    for heater in heaters:
                        heater.set_target_temperature(TEMP_HIGH)
                        heater.adjust_temperature(current_temp)
                else:
                    logger.warning(f"There is no Heater in {room_name}.")

                acs = get_room_actuators(room, "AC")
                if acs is not None:
                    for ac in acs:
                        ac.set_target_temperature(TEMP_LOW)
                        ac.adjust_temperature(current_temp)
                else:
                    logger.warning(f"There is no AC in {room_name}.")

    else:
        logger.warning(format("Fail to find Temperature Sensor."))

    # --------------------------------------
    # Humidity Adjustment:
    # --------------------------------------
    print(f"------------------------ Humidity Adjustment ------------------------")
    humidity_sensors = get_all_sensors(home, "Humidity")
    if humidity_sensors is not None:
        for sensor in humidity_sensors:
            sensor.turn_on()
            current_humidity = sensor.get_reading()
            room_name = sensor.room_name
            room = get_room(home, room_name)
            if room is not None:
                humidifiers = get_room_actuators(room, "Humidifier")
                if humidifiers is not None:
                    for humidifier in humidifiers:
                        if current_humidity < HUMIDITY_LOW:
                            humidifier.increase_humidity()
                        elif current_humidity > HUMIDITY_HIGH:
                            humidifier.decrease_humidity()
                else:
                    logger.warning(f"There is no Humidifier in {room_name}.")

    else:
        logger.warning(format("Fail to find Humidity Sensor."))

    # --------------------------------------
    # Light Intensity Adjustment:
    # --------------------------------------
    print(f"------------------------ Light Intensity Adjustment ------------------------")
    light_intensive_sensors = get_all_sensors(home, "LightIntensive")
    if light_intensive_sensors is not None:
        for sensor in light_intensive_sensors:
            sensor.turn_on()
            current_light_intensive = sensor.get_reading()
            room_name = sensor.room_name
            room = get_room(home, room_name)
            if room is not None:
                lights = get_room_actuators(room, "Light")
                if lights is not None:
                    for light in lights:
                        if current_light_intensive < LIGHT_INTENSITY_LOW:
                            light.turn_on()
                        elif current_light_intensive > LIGHT_INTENSITY_HIGH:
                            light.turn_off()
                else:
                    logger.warning(f"There is no Light in {room_name}.")

    else:
        logger.warning(format("Fail to find Light Intensive Sensor."))


if __name__ == '__main__':
    main()