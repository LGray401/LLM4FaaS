from home.home_plan import home_plan, get_room, get_room_sensors, get_room_actuators, get_all_actuators, \
    get_all_sensors
from home.logger_config import logger


def main():
    home = home_plan()

    # 1. 关闭客厅灯，请调暗卧室的灯
    living_room = get_room(home, "LivingRoom")
    if living_room:
        living_room_lights = get_room_actuators(home, "LivingRoom")
        if living_room_lights:
            for light in living_room_lights:
                if light.actuator_type == "Light":
                    light.turn_off()

    bedroom = get_room(home, "Bedroom")
    if bedroom:
        bedroom_lights = get_room_actuators(home, "Bedroom")
        if bedroom_lights:
            for light in bedroom_lights:
                if light.actuator_type == "Light":
                    light.set_brightness_level("low")

    # 2. 空调调制26度
    living_room = get_room(home, "LivingRoom")
    if living_room:
        living_room_ac = get_room_actuators(home, "LivingRoom")
        if living_room_ac:
            for ac in living_room_ac:
                if ac.actuator_type == "AC":
                    ac.set_target_temperature(26)

    # 3. 打开窗户
    living_room = get_room(home, "LivingRoom")
    if living_room:
        living_room_windows = get_room_actuators(home, "LivingRoom")
        if living_room_windows:
            for window in living_room_windows:
                if window.actuator_type == "Window":
                    window.turn_on()


if __name__ == "__main__":
    main()

# **Explanation:**

# 1. **Import necessary modules:**
#    - `home.home_plan` for functions to access home plan data.
#    - `home.logger_config` for logging.

# 2. **`main` function:**
#    - Creates a `home` object using `home_plan()`.
#    - Executes the commands:
#      - **"关闭客厅灯，请调暗卧室的灯"**:
#        - Gets the "LivingRoom" and "Bedroom" rooms using `get_room`.
#        - Finds all "Light" actuators in each room using `get_room_actuators`.
#        - Turns off the lights in the "LivingRoom" and sets the brightness level to "low" in the "Bedroom".
#      - **"空调调制26度"**:
#        - Gets the "LivingRoom" room.
#        - Finds all "AC" actuators in the "LivingRoom".
#        - Sets the target temperature to 26 degrees Celsius for the AC.
#      - **"打开窗户"**:
#        - Gets the "LivingRoom" room.
#        - Finds all "Window" actuators in the "LivingRoom".
#        - Turns on the windows in the "LivingRoom".

# 3. **Error handling:**
#    - The code checks if the rooms and actuators are found before attempting to control them. If not found, it logs a warning message.

# **To use this code:**

# 1. Make sure you have the other files (`sensor.py`, `actuator.py`, `home_plan.py`, and `config.py`) in the correct folders.
# 2. Run the `function.py` file: `python functions/function.py`.

# This will execute the commands in your smart home project.