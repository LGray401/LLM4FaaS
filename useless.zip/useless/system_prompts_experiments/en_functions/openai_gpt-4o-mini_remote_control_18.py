# Based on your functional description and the provided source code, I will create a `function.py` file that will include a main function to turn on the lights in your smart home project. The function will utilize the `Light` actuator defined in your `actuator.py` file and will be integrated with the home plan defined in `home_plan.py`.
# 
# Here is the `function.py` file that meets your requirements:

# function.py
from home.home_plan import home_plan
from home.actuator import Light

def turn_on_lights(room_name):
    # Create the home plan to get access to the rooms and their actuators
    home = home_plan()
    room = next((room for room in home if room.name == room_name), None)

    if room:
        # Get all Light actuators in the specified room
        lights = [actuator for actuator in room.actuators if isinstance(actuator, Light)]

        if lights:
            for light in lights:
                light.turn_on()  # Turn on each light found in the room
        else:
            print(f"No lights found in {room_name}.")
    else:
        print(f"The room '{room_name}' does not exist.")

def main():
    # Example: Turn on lights in the Living Room
    room_name = "LivingRoom"
    print(f"Turning on lights in {room_name}...")
    turn_on_lights(room_name)

if __name__ == "__main__":
    main()