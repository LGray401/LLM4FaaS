# Based on your functional description and the provided source code files, here is a `function.py` file that establishes the network control system for your smart home project. The main function initializes the home system, creates the rooms with their respective sensors and actuators, and demonstrates how to retrieve and interact with these components.

# functions/function.py

from home.home_plan import home_plan, print_home_plan, get_room
from home.logger_config import logger

def main():
    # Initialize the home system
    home = home_plan()

    # Print the home plan
    print_home_plan(home)

    # Example: Interact with a specific room
    room_name = "LivingRoom"  # Change as needed
    room = get_room(home, room_name)

    if room:
        # Turn on all lights in the LivingRoom
        for actuator in room.actuators:
            if actuator.actuator_type == "Light":
                actuator.turn_on()

        # Get readings from all sensors in the LivingRoom
        for sensor in room.sensors:
            sensor.turn_on()  # Ensure the sensor is on before getting readings
            sensor.get_reading()

        # Example: Adjust temperature with the heater
        heater = next((a for a in room.actuators if isinstance(a, Heater)), None)
        if heater:
            heater.set_target_temperature(22)  # Set desired temperature
            # Simulate current temperature readings
            current_temp = next((s.get_reading() for s in room.sensors if isinstance(s, IndoorTemperatureSensor)), None)
            if current_temp is not None:
                heater.adjust_temperature(current_temp)

if __name__ == "__main__":
    main()