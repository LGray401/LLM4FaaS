# Based on the functional description provided and the existing code files, here is the `function.py` file that will implement the functionality to dim the bedroom lights.
# 
# This script will locate in the `functions` folder and contain a main function that interacts with the classes defined in your existing code to dim the lights in the bedroom.
# 
# ### function.py

from home.home_plan import home_plan
from home.actuator import Light


def dim_bedroom_lights():
    # Get the home structure
    home = home_plan()
    
    # Find the bedroom
    bedroom = next((room for room in home if room.name == "Bedroom"), None)
    
    if bedroom is None:
        print("Bedroom not found in the home plan.")
        return
    
    # Get all the lights in the bedroom
    bedroom_lights = [actuator for actuator in bedroom.actuators if isinstance(actuator, Light)]
    
    if not bedroom_lights:
        print("No lights found in the bedroom.")
        return
    
    # Dim each light in the bedroom
    for light in bedroom_lights:
        light.turn_on()  # Ensure the light is on before dimming
        light.set_brightness_level("low")  # Dimming to low level
        print(f"Dimming {light.id} to low brightness.")


def main():
    dim_bedroom_lights()


if __name__ == "__main__":
    main()