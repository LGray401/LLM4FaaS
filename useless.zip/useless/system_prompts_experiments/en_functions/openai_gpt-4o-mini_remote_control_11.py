# Based on your functional description and the provided source code, I will create a `function.py` file for your smart home project. This file will include the main function to handle the sleep mode, wake-up mode, lights off mode, and window closing mode.
# 
# Here's the `function.py` code:

# function.py
from home.home_plan import home_plan, get_all_actuators
from home.logger_config import logger

def sleep_mode(home):
    """Activate sleep mode: Turn off all lights and close all windows."""
    print("Activating Sleep Mode...")
    lights = get_all_actuators(home, "Light")
    windows = get_all_actuators(home, "Window")

    for light in lights:
        light.turn_off()

    for window in windows:
        window.turn_off()  # Assuming turning off the window means closing it

    print("Sleep Mode activated: All lights off and windows closed.")
    logger.info("Sleep Mode activated: All lights off and windows closed.")


def wake_up_mode(home):
    """Activate wake up mode: Open all windows and turn on lights."""
    print("Activating Wake Up Mode...")
    lights = get_all_actuators(home, "Light")
    windows = get_all_actuators(home, "Window")

    for light in lights:
        light.turn_on()

    for window in windows:
        window.turn_on()  # Assuming turning on the window means opening it

    print("Wake Up Mode activated: All lights on and windows opened.")
    logger.info("Wake Up Mode activated: All lights on and windows opened.")


def lights_off_mode(home):
    """Turn off all lights in the house."""
    print("Turning off all lights...")
    lights = get_all_actuators(home, "Light")

    for light in lights:
        light.turn_off()

    print("All lights turned off.")
    logger.info("All lights turned off.")


def window_closing_mode(home):
    """Close all windows in the house."""
    print("Closing all windows...")
    windows = get_all_actuators(home, "Window")

    for window in windows:
        window.turn_off()  # Assuming turning off the window means closing it

    print("All windows closed.")
    logger.info("All windows closed.")


def main():
    home = home_plan()  # Initialize the home plan

    # Example usage:
    sleep_mode(home)
    wake_up_mode(home)
    lights_off_mode(home)
    window_closing_mode(home)


if __name__ == "__main__":
    main()