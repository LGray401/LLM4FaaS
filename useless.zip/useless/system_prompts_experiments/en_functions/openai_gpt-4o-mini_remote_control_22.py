# Based on your functional description and the provided source code, here is the `function.py` file that implements the required functionality. This file will turn on the lights in the living room, bedroom, and bathroom, turn on the air conditioners in the living room and bedroom, turn on the heater in the bathroom, and turn on the TV in the living room.

# functions/function.py
from home.home_plan import home_plan
from home.actuator import Light, AC, Heater, SmartTV

def main():
    # Create home and get rooms
    home = home_plan()
    
    # Define room names
    living_room = "LivingRoom"
    bedroom = "Bedroom"
    bathroom = "Bathroom"
    
    # Turn on lights in the living room, bedroom, and bathroom
    lights = {
        living_room: [],
        bedroom: [],
        bathroom: []
    }
    
    for room in home:
        if room.name in lights:
            for actuator in room.actuators:
                if isinstance(actuator, Light):
                    actuator.turn_on()
                    lights[room.name].append(actuator.id)

    # Turn on air conditioners in the living room and bedroom
    for room_name in [living_room, bedroom]:
        room = next((r for r in home if r.name == room_name), None)
        if room:
            for actuator in room.actuators:
                if isinstance(actuator, AC):
                    actuator.turn_on()

    # Turn on heater in the bathroom
    bathroom_room = next((r for r in home if r.name == bathroom), None)
    if bathroom_room:
        for actuator in bathroom_room.actuators:
            if isinstance(actuator, Heater):
                actuator.turn_on()

    # Turn on TV in the living room
    for actuator in next((r for r in home if r.name == living_room), None).actuators:
        if isinstance(actuator, SmartTV):
            actuator.turn_on()

if __name__ == "__main__":
    main()