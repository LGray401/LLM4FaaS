# Based on the provided functional description and the source code for your smart home project, I will create a `function.py` file that serves as the main entry point for controlling the smart home system. This file will include a simple command-line interface to interact with the various sensors and actuators in the home.
# 
# Here is the `function.py` file:

# function.py
from home.home_plan import home_plan, print_home_plan, get_room_sensors, get_room_actuators
from home.sensor import IndoorTemperatureSensor, HumiditySensor, LightIntensiveSensor
from home.actuator import Light, Heater, AC, NotificationSender

def main():
    # Initialize home
    home = home_plan()

    # Print Home Plan
    print_home_plan(home)

    # Example interaction
    while True:
        print("\nSmart Home Control")
        print("1. Check sensors in a room")
        print("2. Check actuators in a room")
        print("3. Get sensor reading")
        print("4. Control actuator")
        print("5. Exit")

        choice = input("Select an option: ")

        if choice == "1":
            room_name = input("Enter room name: ")
            sensors = get_room_sensors(home, room_name)
            if sensors:
                for sensor in sensors:
                    sensor.get_status()
            else:
                print("No sensors found in that room.")

        elif choice == "2":
            room_name = input("Enter room name: ")
            actuators = get_room_actuators(home, room_name)
            if actuators:
                for actuator in actuators:
                    actuator.get_status()
            else:
                print("No actuators found in that room.")

        elif choice == "3":
            room_name = input("Enter room name: ")
            sensors = get_room_sensors(home, room_name)
            if sensors:
                for sensor in sensors:
                    sensor.turn_on()  # Ensure sensor is on before reading
                    sensor.get_reading()
                    sensor.turn_off()  # Turn off sensor after reading
            else:
                print("No sensors found in that room.")

        elif choice == "4":
            room_name = input("Enter room name: ")
            actuator_name = input("Enter actuator type (e.g., Light, Heater, AC): ")
            actuators = get_room_actuators(home, room_name)
            if actuators:
                actuator = next((act for act in actuators if act.actuator_type.lower() == actuator_name.lower()), None)
                if actuator:
                    action = input("Enter action (on/off): ")
                    if action.lower() == "on":
                        actuator.turn_on()
                    elif action.lower() == "off":
                        actuator.turn_off()
                    else:
                        print("Invalid action.")
                else:
                    print("Actuator not found.")
            else:
                print("No actuators found in that room.")

        elif choice == "5":
            print("Exiting...")
            break

        else:
            print("Invalid option. Please try again.")

if __name__ == "__main__":
    main()