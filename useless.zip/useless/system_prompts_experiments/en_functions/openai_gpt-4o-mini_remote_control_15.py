# Based on your functional description and the provided source code, I'll create a `function.py` file for your smart home project. This file will include a `main` function that demonstrates how to utilize the classes and functionality from the other modules.
# 
# Here's the `function.py` file:

# function.py

from home.home_plan import home_plan, print_home_plan, get_room, get_room_sensors, get_room_actuators
from home.sensor import IndoorTemperatureSensor, HumiditySensor, LightIntensiveSensor
from home.actuator import Light, Heater, AC, CoffeeMachine, NotificationSender, MusicPlayer

def main():
    # Step 1: Initialize the home plan
    home = home_plan()
    
    # Step 2: Print home plan information
    print_home_plan(home)

    # Step 3: Select a room and demonstrate sensor and actuator functionalities
    room_name = "LivingRoom"
    living_room = get_room(home, room_name)
    
    if living_room:
        # Step 4: Get sensors in the living room
        sensors = get_room_sensors(home, room_name)
        print(f"Sensors in {room_name}: {[sensor.id for sensor in sensors]}")

        # Step 5: Get actuators in the living room
        actuators = get_room_actuators(home, room_name)
        print(f"Actuators in {room_name}: {[actuator.id for actuator in actuators]}")

        # Step 6: Turn on a light and get its status
        light = next((a for a in actuators if isinstance(a, Light)), None)
        if light:
            light.turn_on()
            light.set_brightness_level("high")
            print(f"Light status: {light.get_status()}")

        # Step 7: Turn on a heater and set a target temperature
        heater = next((a for a in actuators if isinstance(a, Heater)), None)
        if heater:
            heater.turn_on()
            heater.set_target_temperature(22)
            current_temp_sensor = next((s for s in sensors if isinstance(s, IndoorTemperatureSensor)), None)
            if current_temp_sensor:
                current_temp = current_temp_sensor.get_reading()
                heater.adjust_temperature(current_temp)

        # Step 8: Use notification sender to send a message
        notification_sender = next((a for a in actuators if isinstance(a, NotificationSender)), None)
        if notification_sender:
            notification_sender.turn_on()
            notification_sender.notification_sender("Welcome to the Living Room!")

        # Step 9: Use MusicPlayer to play music
        music_player = next((a for a in actuators if isinstance(a, MusicPlayer)), None)
        if music_player:
            music_player.turn_on()
            music_player.play_music("Chill Vibes Playlist")

        # Step 10: Simulate CoffeeMachine usage
        coffee_machine = next((a for a in actuators if isinstance(a, CoffeeMachine)), None)
        if coffee_machine:
            coffee_machine.turn_on()
            coffee_machine.make_coffee("Espresso")

if __name__ == "__main__":
    main()