# Based on your functional description and the provided source code, here is the implementation of the `function.py` file. This file will contain a main function that allows you to adjust the state of a specified device (turn on, turn off, brighten, or dim).
# 
# ### function.py

from home.home_plan import home_plan, get_room_actuators
from home.actuator import Light

def adjust_device(device_name, action, room_name=None, brightness_level=None):
    home = home_plan()
    
    # If room_name is provided, get devices in that room
    if room_name:
        room_actuators = get_room_actuators(home, room_name)
    else:
        room_actuators = []
        for room in home:
            room_actuators.extend(room.actuators)

    # Find the specified device in the room actuators
    device = next((actuator for actuator in room_actuators if actuator.actuator_type.lower() == device_name.lower()), None)

    if device is None:
        print(f"No device found with name '{device_name}' in the specified room.")
        return

    # Perform the action based on the input
    if action == "turn on":
        device.turn_on()
    elif action == "turn off":
        device.turn_off()
    elif action == "brighten":
        if isinstance(device, Light) and brightness_level:
            device.set_brightness_level(brightness_level)
        else:
            print(f"Cannot brighten. Device '{device.id}' is not a light or brightness level is missing.")
    elif action == "dim":
        if isinstance(device, Light) and brightness_level:
            # Assuming dimming means setting to a lower brightness level
            levels = device.brightness_levels.keys()
            if brightness_level in levels:
                dim_level = levels[levels.index(brightness_level) - 1] if levels.index(brightness_level) > 0 else brightness_level
                device.set_brightness_level(dim_level)
            else:
                print(f"Invalid brightness level '{brightness_level}'. Available levels are {list(levels)}.")
        else:
            print(f"Cannot dim. Device '{device.id}' is not a light or brightness level is missing.")
    else:
        print(f"Invalid action '{action}'. Valid actions are: turn on, turn off, brighten, dim.")

def main():
    # Example usage
    adjust_device("Light", "turn on", "LivingRoom")
    adjust_device("Light", "brighten", "LivingRoom", "high")
    adjust_device("Light", "dim", "LivingRoom", "high")
    adjust_device("Light", "turn off", "LivingRoom")

if __name__ == "__main__":
    main()