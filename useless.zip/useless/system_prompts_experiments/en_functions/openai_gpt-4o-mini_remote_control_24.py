# Based on your functional description of turning off the bedroom light and the provided source code, here is the `function.py` file that will implement the main function to perform this action. The code will utilize the classes in your project to find the bedroom and turn off the light actuator.

# functions/function.py

from home.home_plan import home_plan, get_room, get_room_actuators

def main():
    # Get the home plan
    home = home_plan()

    # Specify the room name
    room_name = "Bedroom"

    # Get the bedroom
    bedroom = get_room(home, room_name)

    if bedroom:
        # Get all light actuators in the bedroom
        light_actuators = get_room_actuators(home, room_name)

        # Turn off all light actuators in the bedroom
        for actuator in light_actuators:
            if actuator.actuator_type == "Light":
                actuator.turn_off()

if __name__ == "__main__":
    main()