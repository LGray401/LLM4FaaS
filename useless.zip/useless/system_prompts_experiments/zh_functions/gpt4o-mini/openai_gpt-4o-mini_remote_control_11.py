# Based on the provided functional description and existing source code, I will create the `function.py` file that incorporates the different modes you specified: sleep mode, wake up mode, turn off lights mode, and close windows mode.
# 
# Here is the `function.py` file:

# functions/function.py

from home.home_plan import home_plan
from home.config import TEMP_HIGH, TEMP_LOW, HUMIDITY_HIGH, HUMIDITY_LOW, LIGHT_INTENSITY_HIGH, LIGHT_INTENSITY_LOW
from home.actuator import Light, Window, Curtain, SmartSocket
from home.sensor import IndoorTemperatureSensor, HumiditySensor, LightIntensiveSensor

def sleep_mode(home):
    print("Activating Sleep Mode...")
    for room in home:
        for actuator in room.actuators:
            if isinstance(actuator, Light):
                actuator.turn_off()
            if isinstance(actuator, Window) or isinstance(actuator, Curtain):
                actuator.turn_off()  # Assuming turning off closes them
        
        for sensor in room.sensors:
            if isinstance(sensor, IndoorTemperatureSensor):
                reading = sensor.get_reading()
                if reading and reading > TEMP_HIGH:
                    print("It's too warm! Activating AC or Heater...")
                    # Assuming we have an AC or Heater in the room
                    ac = next((a for a in room.actuators if isinstance(a, AC)), None)
                    heater = next((a for a in room.actuators if isinstance(a, Heater)), None)
                    if ac:
                        ac.turn_on()
                    elif heater:
                        heater.turn_on()
            elif isinstance(sensor, HumiditySensor):
                reading = sensor.get_reading()
                if reading and reading > HUMIDITY_HIGH:
                    print("Humidity is high! Activating Dehumidifier...")
                    # Assuming we have a dehumidifier actuator
            elif isinstance(sensor, LightIntensiveSensor):
                reading = sensor.get_reading()
                if reading and reading > LIGHT_INTENSITY_HIGH:
                    print("It's too bright! Activating curtain...")
                    curtain = next((a for a in room.actuators if isinstance(a, Curtain)), None)
                    if curtain:
                        curtain.turn_on()

def wake_up_mode(home):
    print("Activating Wake Up Mode...")
    for room in home:
        for actuator in room.actuators:
            if isinstance(actuator, Light):
                actuator.turn_on()
            if isinstance(actuator, Window) or isinstance(actuator, Curtain):
                actuator.turn_on()  # Assuming turning on opens them

def turn_off_lights_mode(home):
    print("Turning off all lights...")
    for room in home:
        for actuator in room.actuators:
            if isinstance(actuator, Light):
                actuator.turn_off()

def close_windows_mode(home):
    print("Closing all windows...")
    for room in home:
        for actuator in room.actuators:
            if isinstance(actuator, Window):
                actuator.turn_off()  # Assuming turning off closes them

def main():
    home = home_plan()
    # Here you can call any of the modes as needed
    sleep_mode(home)
    wake_up_mode(home)
    turn_off_lights_mode(home)
    close_windows_mode(home)

if __name__ == "__main__":
    main()