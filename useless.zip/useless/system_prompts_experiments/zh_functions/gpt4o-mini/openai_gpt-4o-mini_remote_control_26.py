# Based on the functional description you provided, I will create a `function.py` file that allows you to control the devices (turn on, turn off, brighten, and dim) in your smart home project. This file will extract the necessary components from the existing files you provided, particularly focusing on actuators like lights.
# 
# Here's the content of `function.py`:

# functions/function.py

from home.home_plan import home_plan, get_room, get_room_actuators
from home.actuator import Light

def control_device(room_name, device_type, action, brightness_level=None):
    # Get the home plan
    home = home_plan()
    
    # Get the specified room
    room = get_room(home, room_name)
    if not room:
        print(f"Room '{room_name}' not found.")
        return
    
    # Get the actuators in the specified room
    actuators = get_room_actuators(home, room_name)
    if not actuators:
        print(f"No actuators found in '{room_name}'.")
        return

    # Control the specified device
    for actuator in actuators:
        if actuator.actuator_type.lower() == device_type.lower():
            if action == "turn_on":
                actuator.turn_on()
            elif action == "turn_off":
                actuator.turn_off()
            elif action == "brighten":
                if isinstance(actuator, Light):
                    if brightness_level:
                        actuator.set_brightness_level(brightness_level)
                    else:
                        print("Brightness level must be specified for brightening.")
                else:
                    print(f"{actuator.id} is not a Light actuator.")
            elif action == "dim":
                if isinstance(actuator, Light):
                    if brightness_level:
                        actuator.set_brightness_level(brightness_level)
                    else:
                        print("Brightness level must be specified for dimming.")
                else:
                    print(f"{actuator.id} is not a Light actuator.")
            else:
                print(f"Action '{action}' is not valid.")
            return

    print(f"No actuator of type '{device_type}' found in '{room_name}'.")

def main():
    # Example usage
    control_device("LivingRoom", "Light", "turn_on")
    control_device("LivingRoom", "Light", "brighten", "high")
    control_device("LivingRoom", "Light", "dim", "low")
    control_device("LivingRoom", "Light", "turn_off")

if __name__ == "__main__":
    main()