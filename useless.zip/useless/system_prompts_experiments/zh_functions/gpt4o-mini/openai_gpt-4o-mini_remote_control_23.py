# Based on your functional description and the provided source code for your smart home project, I will create a `function.py` file in the `functions` folder. This file will contain a main function to initialize the smart home system, set up the rooms, sensors, and actuators, and demonstrate how they interact.
# 
# Here's the `function.py` code:

# function.py

from home.home_plan import home_plan, print_home_plan, get_room, get_room_sensors, get_room_actuators
from home.sensor import IndoorTemperatureSensor, HumiditySensor, LightIntensiveSensor
from home.actuator import Light, Heater, AC, CleaningRobot, NotificationSender

def main():
    # Initialize the home plan
    home = home_plan()
    
    # Print the home plan
    print_home_plan(home)

    # Example interactions with the home system
    living_room = get_room(home, "LivingRoom")
    if living_room:
        # Get sensors in the living room
        sensors = get_room_sensors(home, "LivingRoom")
        for sensor in sensors:
            sensor.turn_on()
            sensor.get_reading()
            sensor.turn_off()
        
        # Get actuators in the living room
        actuators = get_room_actuators(home, "LivingRoom")
        for actuator in actuators:
            actuator.turn_on()
            actuator.get_status()
            if isinstance(actuator, Light):
                actuator.set_brightness_level("medium")
            elif isinstance(actuator, Heater):
                actuator.set_target_temperature(22)
            elif isinstance(actuator, CleaningRobot):
                actuator.daily_routine()
            elif isinstance(actuator, NotificationSender):
                actuator.notification_sender("Welcome to the Living Room!")

if __name__ == "__main__":
    main()