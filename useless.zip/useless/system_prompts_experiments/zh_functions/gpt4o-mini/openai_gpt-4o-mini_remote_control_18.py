# Based on your functional description and the provided source code, I will create a `function.py` file that contains a main function to turn on the lights in the smart home system. This function will utilize the existing classes from the `actuator.py` and `home_plan.py` files to accomplish this task.
# 
# Here’s the code for `function.py`:

# function.py

from home.home_plan import home_plan, get_all_actuators
from home.actuator import Light

def turn_on_lights():
    # Create the home plan
    home = home_plan()
    
    # Get all lights in the home
    lights = get_all_actuators(home, "Light")
    
    if not lights:
        print("No lights found in the home.")
        return
    
    # Turn on all lights
    for light in lights:
        light.turn_on()
        print(f"Light {light.id} has been turned ON.")

if __name__ == "__main__":
    turn_on_lights()