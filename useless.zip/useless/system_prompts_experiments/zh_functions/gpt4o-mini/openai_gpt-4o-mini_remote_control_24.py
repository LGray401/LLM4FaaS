# Based on the functional description "请把卧室的灯关了" (Please turn off the lights in the bedroom), I will create the `function.py` file that contains the main function to turn off the lights in the bedroom. 
# 
# Here's how the `function.py` file will look:

# functions/function.py

from home.home_plan import home_plan, get_room, get_room_actuators

def main():
    # Retrieve the home plan
    home = home_plan()
    
    # Get the bedroom room object
    bedroom = get_room(home, "Bedroom")
    
    if bedroom is not None:
        # Get all actuators of type Light in the bedroom
        lights = get_room_actuators(home, "Bedroom")
        
        # Turn off all lights in the bedroom
        for light in lights:
            if light.actuator_type == "Light":
                light.turn_off()
    else:
        print("Bedroom not found!")

if __name__ == "__main__":
    main()