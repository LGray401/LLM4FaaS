# Based on your provided functional description and the source code files, here's a `function.py` file that includes a main function to tie everything together. This function will instantiate the home components and demonstrate how they interact with each other.
# 
# Here's how the `function.py` file looks:

# functions/function.py

from home.home_plan import home_plan, print_home_plan, get_room, get_all_sensors, get_all_actuators
from home.logger_config import logger

def main():
    # Step 1: Create and print the home plan
    home = home_plan()
    print_home_plan(home)

    # Step 2: Example of interacting with the home components
    living_room = get_room(home, "LivingRoom")
    if living_room:
        # Turn on all lights in the living room
        lights = get_all_actuators(home, "Light")
        for light in lights:
            light.turn_on()

        # Get readings from sensors in the living room
        sensors = get_all_sensors(home, "LivingRoom")
        for sensor in sensors:
            sensor.turn_on()  # Ensure sensor is ON before getting reading
            sensor.get_reading()

        # Example of a specific actuator
        heater = next((act for act in living_room.actuators if isinstance(act, Heater)), None)
        if heater:
            heater.set_target_temperature(22)  # Set target temperature to 22°C
            # Simulate getting temperature reading from IndoorTemperatureSensor
            temp_sensor = next((sensor for sensor in living_room.sensors if isinstance(sensor, IndoorTemperatureSensor)), None)
            if temp_sensor:
                current_temp = temp_sensor.get_reading()
                heater.adjust_temperature(current_temp)

if __name__ == "__main__":
    main()