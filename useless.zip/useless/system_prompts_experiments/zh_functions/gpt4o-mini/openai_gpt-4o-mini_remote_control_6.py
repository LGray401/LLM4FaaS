# Based on your functional description and the provided source code, I'll create a `function.py` file that will bring together the functionalities of the sensors and actuators. The main function will activate the temperature sensor, control the window actuator, and manage the light actuator as per your requirement.
# 
# Here's the `function.py` file:

# functions/function.py

from home.home_plan import home_plan, get_room_sensors, get_room_actuators
from home.logger_config import logger

def main():
    # Initialize home
    home = home_plan()

    # Specify the room we want to control
    room_name = "LivingRoom"  # you can change the room name as needed

    # Get sensors and actuators in the specified room
    sensors = get_room_sensors(home, room_name)
    actuators = get_room_actuators(home, room_name)

    if sensors is None or actuators is None:
        return

    # Turn on the temperature sensor
    temp_sensor = next((s for s in sensors if s.sensor_type == "IndoorTemperature"), None)
    if temp_sensor:
        temp_sensor.turn_on()
        temperature_reading = temp_sensor.get_reading()
    else:
        logger.warning("No Indoor Temperature Sensor found in the room.")

    # Control the window actuator
    window_actuator = next((a for a in actuators if a.actuator_type == "Window"), None)
    if window_actuator:
        window_actuator.turn_on()  # Open the window
        logger.info(f"{window_actuator.id} is opened.")
    else:
        logger.warning("No Window actuator found in the room.")

    # Control the light actuator
    light_actuator = next((a for a in actuators if a.actuator_type == "Light"), None)
    if light_actuator:
        light_actuator.turn_on()  # Turn on the light
        logger.info(f"{light_actuator.id} is turned on.")
    else:
        logger.warning("No Light actuator found in the room.")

    # Example of setting brightness for the light
    if light_actuator:
        light_actuator.set_brightness_level("medium")

    # Optionally, turn off the devices after a delay or condition
    # temp_sensor.turn_off()
    # window_actuator.turn_off()
    # light_actuator.turn_off()

if __name__ == "__main__":
    main()