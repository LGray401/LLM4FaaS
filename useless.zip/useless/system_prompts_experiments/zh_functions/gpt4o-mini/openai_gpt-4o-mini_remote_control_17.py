# Based on your functional description of turning off the living room light, I will create a `function.py` file that includes a main function to accomplish this task. The function will interact with the existing classes in your project to locate the appropriate light actuator in the living room and turn it off.
# 
# Here’s how the `function.py` file will look:

# function.py
from home.home_plan import home_plan
from home.config import logger


def turn_off_living_room_light():
    # Get the home layout
    home = home_plan()
    
    # Find the living room
    living_room = None
    for room in home:
        if room.name == "LivingRoom":
            living_room = room
            break
            
    if living_room is None:
        print("Living room not found!")
        logger.warning("Living room not found!")
        return

    # Find the light actuator in the living room
    light_actuators = [actuator for actuator in living_room.actuators if actuator.actuator_type == "Light"]
    
    if not light_actuators:
        print("No light actuator found in the living room!")
        logger.warning("No light actuator found in the living room!")
        return

    # Turn off the first light actuator found
    light_actuator = light_actuators[0]
    light_actuator.turn_off()
    print(f"The light in the {living_room.name} has been turned off.")
    logger.info(f"The light in the {living_room.name} has been turned off.")


def main():
    turn_off_living_room_light()


if __name__ == "__main__":
    main()