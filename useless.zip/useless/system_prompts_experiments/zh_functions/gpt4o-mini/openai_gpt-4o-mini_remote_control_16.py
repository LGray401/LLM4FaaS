# Based on your functional description and the provided source code, I will create a `function.py` file that will serve as the main module for your smart home project. This file will initialize the home environment, create rooms with their respective sensors and actuators, and demonstrate some functionality by interacting with the sensors and actuators.
# 
# Here is the `function.py` file:

# functions/function.py

from home.home_plan import home_plan, print_home_plan, get_room, get_room_sensors, get_room_actuators
from home.config import TEMP_LOW, TEMP_HIGH, HUMIDITY_LOW, HUMIDITY_HIGH
import time

def main():
    # Initialize the home with rooms and components
    home = home_plan()

    # Print the home plan
    print_home_plan(home)

    # Example usage: Interact with a specific room
    room_name = "LivingRoom"
    room = get_room(home, room_name)

    if room:
        # Get sensors in the room
        sensors = get_room_sensors(home, room_name)
        for sensor in sensors:
            sensor.turn_on()
            reading = sensor.get_reading()
            time.sleep(1)  # Simulate a delay for realism
            sensor.turn_off()
        
        # Get actuators in the room
        actuators = get_room_actuators(home, room_name)
        for actuator in actuators:
            actuator.turn_on()
            actuator.get_status()
            time.sleep(1)  # Simulate a delay for realism
            actuator.turn_off()

    # Example: Check conditions and control actuators based on sensor readings
    temperature_sensors = get_all_sensors(home, "IndoorTemperature")
    for sensor in temperature_sensors:
        sensor.turn_on()
        current_temp = sensor.get_reading()
        if current_temp is not None:
            if current_temp < TEMP_LOW:
                # Find heater in the same room
                heater = get_all_actuators(home, "Heater")
                if heater:
                    heater[0].set_target_temperature(22)  # Set desired temperature
                    heater[0].turn_on()
            elif current_temp > TEMP_HIGH:
                # Find AC in the same room
                ac = get_all_actuators(home, "AC")
                if ac:
                    ac[0].set_target_temperature(20)  # Set desired temperature
                    ac[0].turn_on()
        time.sleep(1)
        sensor.turn_off()

if __name__ == "__main__":
    main()