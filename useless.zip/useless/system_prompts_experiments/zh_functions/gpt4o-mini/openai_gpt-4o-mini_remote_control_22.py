# Based on the provided functional description and the source code, here is the `function.py` file that will implement the actions to turn on the lights in the living room, bedroom, and bathroom, turn on the air conditioning in the living room and bedroom, turn on the heater in the bathroom, and turn on the TV in the living room.

# functions/function.py

from home.home_plan import home_plan, get_room_actuators

def activate_home_features(home):
    # Define the rooms and the actions to be taken
    actions = {
        "LivingRoom": {
            "lights": "Light",
            "ac": "AC",
            "tv": "SmartTV"
        },
        "Bedroom": {
            "lights": "Light",
            "ac": "AC"
        },
        "Bathroom": {
            "lights": "Light",
            "heater": "Heater"
        }
    }
    
    for room_name, devices in actions.items():
        room = next((r for r in home if r.name == room_name), None)
        if room:
            for device, actuator_type in devices.items():
                actuators = get_room_actuators(home, room_name)
                for actuator in actuators:
                    if actuator.actuator_type == actuator_type:
                        actuator.turn_on()
                        if device == "tv":
                            actuator.play_channel("default_channel")  # Play a default channel for TV
                        break  # Break after the actuator is found and turned on

def main():
    home = home_plan()  # Create the home plan
    activate_home_features(home)  # Activate the defined features

if __name__ == "__main__":
    main()