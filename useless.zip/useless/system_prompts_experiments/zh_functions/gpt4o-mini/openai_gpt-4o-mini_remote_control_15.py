# Based on the provided functional description and source code files, I will create the `function.py` file that contains a main function to demonstrate the functionality of your smart home project by integrating sensors and actuators.
# 
# Here's the code for `function.py`:

# functions/function.py

from home.home_plan import home_plan, print_home_plan, get_room, get_all_sensors, get_all_actuators
from home.config import TEMP_LOW, TEMP_HIGH, HUMIDITY_LOW, HUMIDITY_HIGH

def main():
    # Create the home plan
    home = home_plan()
    
    # Print the home plan
    print_home_plan(home)

    # Example usage of the home plan
    living_room = get_room(home, "LivingRoom")
    if living_room:
        print("Living Room Sensors:")
        for sensor in living_room.sensors:
            sensor.turn_on()
            sensor.get_reading()

        print("Living Room Actuators:")
        for actuator in living_room.actuators:
            actuator.turn_on()
            if isinstance(actuator, AC):
                actuator.set_target_temperature(22)  # Set target temperature for AC
            elif isinstance(actuator, Heater):
                actuator.set_target_temperature(24)  # Set target temperature for Heater
            
            actuator.get_status()

    # Example of getting all sensors of a specific type
    indoor_temp_sensors = get_all_sensors(home, "IndoorTemperature")
    for sensor in indoor_temp_sensors:
        sensor.turn_on()
        sensor.get_reading()

    # Example of getting all actuators of a specific type
    lights = get_all_actuators(home, "Light")
    for light in lights:
        light.turn_on()
        light.set_brightness_level("high")
        light.get_status()

if __name__ == "__main__":
    main()