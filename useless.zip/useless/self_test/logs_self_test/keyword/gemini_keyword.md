### Link
https://g.co/gemini/share/f86794d271ab

### preparation
1. Hi~ I would like to get a function code from you based on my current project setup. I will first provide you the necessary python files and then describe the function I need you to provide.
2. I will send you four code snippets to you in 3 messages and one message for one file. They are: sensor.py, actuator.py, and home-plan.py.
3. send 3 python files in three messages and send the description in the forth message.
4. => doesn't give the code but instruction for write function code.
5. ask for a python file=> doesn't finish...


### keyword prompt

I would like to have morning routine at 7 am and evening routine at 11 pm every day.
Additionally, I also want to set plans for Home, Away and Movie times.
Here are what I want for each of the plan or routine.
1)	For the morning routine:
	  I want to get up at 7am and have a cup of coffee. I also want to listen to the daily news.
	  So, at 7am, please open the curtain, turn on the light if it is too dark, play daily news and make a cup of coffee for me.
2)	For the evening routine:
	  I want to go to bed at 11pm. So, at 11 pm, please close the curtain, play bedtime music for me. Turn the light to medium level, then turn it off after half an hour.
3)	For the Home plan:
	  Please turn on the Livingroom light for me, close Living room curtain, and turn on all sockets.
4)	For the Away plan:
	  Please turn off all lights at home, close all windows, lock the home door, and start the cleaning robot. Also, turn off all sockets except for the kitchen ones.
5)	For the Movie plan:
	  Please turn off all lights except for the one or ones in the living room.
	  And set the light in living room to medium level.
	  Close the curtain and turn on the TV.

	  
### Results: ❎
1. cannot give the complete code, stops half-way of away plan
2. does not import all necessary classes and functions (get room sensors())
3. import several wrong functions(need to additionally create these functions)
