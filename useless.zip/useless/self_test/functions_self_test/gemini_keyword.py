# from home.sensor import Sensor
# from home.actuator import Actuator, Light, NotificationSender
# from home.home_plan import home_plan, get_room_curtains, get_room_lights, get_room_actuators, get_all_lights, get_all_windows, get_all_socket_actuators
#
# def get_room_light_level(home, room_name):
#     """Gets the light level from a room using a sensor.
#
#     Args:
#         home: List of rooms representing the home plan.
#         room_name: The name of the room.
#
#     Returns:
#         The light level as a float (assuming a sensor provides this value), or None if no sensor is found.
#     """
#     room_sensors = get_room_sensors(home, room_name)
#     if room_sensors:
#         for sensor in room_sensors:
#             if sensor.sensor_type == "LightIntensive":
#                 return sensor.get_reading()
#     return None
#
# def execute_home_plan(plan_name, home=None):
#     """Executes a home plan by calling appropriate actuator methods.
#
#     Args:
#         plan_name: The name of the plan ("MorningRoutine", "EveningRoutine", "Home", "Away", or "Movie").
#         home: Optional list of rooms representing the home plan (defaults to calling home_plan()).
#     """
#
#     if not home:
#         home = home_plan()
#
#     # Morning Routine (7:00 AM)
#     if plan_name == "MorningRoutine":
#         living_room_curtains = get_room_curtains(home, "LivingRoom")
#         if living_room_curtains:
#             for curtain in living_room_curtains:
#                 curtain.open()
#
#         light_level = get_room_light_level(home, "LivingRoom")
#         if light_level is not None and light_level < 100:  # Adjust threshold as needed
#             living_room_lights = get_room_lights(home, "LivingRoom")
#             if living_room_lights:
#                 for light in living_room_lights:
#                     light.turn_on()
#
#         coffee_machine = get_room_actuators(home, "CoffeeMachine")
#         if coffee_machine:
#             for machine in coffee_machine:
#                 machine.make_coffee()  # Assuming a make_coffee() method exists
#
#         music_player = get_room_actuators(home, "MusicPlayer")
#         if music_player:
#             for player in music_player:
#                 player.play_music(playlist="daily_news")  # Assuming a playlist exists
#
#     # Evening Routine (11:00 PM)
#     elif plan_name == "EveningRoutine":
#         living_room_curtains = get_room_curtains(home, "LivingRoom")
#         if living_room_curtains:
#             for curtain in living_room_curtains:
#                 curtain.close()
#
#         music_player = get_room_actuators(home, "MusicPlayer")
#         if music_player:
#             for player in music_player:
#                 player.play_music(playlist="bedtime_music")  # Assuming a playlist exists
#
#         living_room_lights = get_room_lights(home, "LivingRoom")
#         if living_room_lights:
#             for light in living_room_lights:
#                 light.set_brightness_level("medium")
#                 # Use a timer library (not included here) to turn off lights in 30 minutes
#
#     # Home Plan
#     elif plan_name == "Home":
#         living_room_lights = get_room_lights(home, "LivingRoom")
#         if living_room_lights:
#             for light in living_room_lights:
#                 light.turn_on()
#
#         living_room_curtains = get_room_curtains(home, "LivingRoom")
#         if living_room_curtains:
#             for curtain in living_room_curtains:
#                 curtain.close()
#
#         all_sockets = get_all_socket_actuators(home)
#         if all_sockets:
#             for socket in all_sockets:
#                 socket.turn_on()
#
#     # Away Plan
#     elif plan_name == "Away":
#         all_lights = get_all_lights(home)
#         if all_lights:
