# It looks like you've implemented a basic smart home system with Python classes for sensors and actuators. Here are some suggestions to improve the code:
# 
# 1. **Use type hints**: Add type hints for function parameters and return types to make the code more readable and self-documenting.
# 
# 2. **Consider using a database**: Instead of storing room information in memory, consider using a database like SQLite or MongoDB to store the data persistently.
# 
# 3. **Implement error handling**: Add try-except blocks to handle potential errors that might occur during execution, such as division by zero or invalid input.
# 
# 4. **Follow PEP 8 conventions**: Ensure your code adheres to Python's official style guide (PEP 8) for indentation, spacing, and naming conventions.
# 
# 5. **Consider using a library like `homeassistant`**: If you're building a smart home system, consider using a library like Home Assistant to simplify the integration of various sensors and actuators.
# 
# 6. **Add more functionality to each class**: Currently, the classes are quite basic. You might want to add more methods to each class to make them more useful in your smart home system.
# 
# 7. **Use descriptive variable names**: Use more descriptive variable names instead of single-letter names like `x` or `y`.
# 
# 8. **Consider using a configuration file**: Instead of hardcoding settings, consider storing them in a separate configuration file (like the one you've shown) to make it easier to modify settings without modifying the code.
# 
# 9. **Add logging**: Consider adding logging statements throughout your code to help with debugging and monitoring.
# 
# 10. **Test thoroughly**: Write unit tests and integration tests to ensure that your smart home system works correctly in various scenarios.
# 
# Here's an updated version of your `Room` class with some of these suggestions applied:
# 
# ```python
class Room:
    def __init__(self, name: str):
        self.name = name
        self.sensors: List[Sensor] = []
        self.actuators: List[Actuator] = []

    def add_sensor(self, sensor: Sensor) -> None:
        self.sensors.append(sensor)

    def add_actuator(self, actuator: Actuator) -> None:
        self.actuators.append(actuator)

    def print_info(self) -> None:
        print(f"\n{self.name}:")
        print("Sensors:")
        for sensor in self.sensors:
            print("-", sensor.id)
        print("Actuators:")
        for actuator in self.actuators:
            print("-", actuator.id)


class Sensor:
    def __init__(self, id: str):
        self.sensor_type = None
        self.id = id


class Actuator:
    def __init__(self, id: str):
        self.actuator_type = None
        self.id = id
# ```