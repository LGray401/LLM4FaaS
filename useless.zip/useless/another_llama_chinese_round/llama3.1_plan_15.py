# The provided code snippet appears to be a part of a larger system that simulates home automation. It defines various components, such as sensors and actuators, and uses these components to create different rooms in the home.
# 
# Here's an overview of what each section does:
# 
# 1. **Components**: The code starts by importing necessary classes from other modules (`home.logger_config.py`, `LightIntensiveSensor.py`, etc.). It then defines various sensor and actuator classes (e.g., `LightIntensiveSensor`, `IndoorTemperatureSensor`, `Door`, `SmartSocket`, etc.).
# 
# 2. **Room Class**: The code introduces the `Room` class, which has attributes for a room's name, sensors, and actuators. This class can add sensors or actuators to the room.
# 
# 3. **Create Room Functionality**: The `create_room_with_components()` function generates a room with the given name and adds specified types of sensors and actuators to it.
# 
# 4. **Home Plan Generation**: The `home_plan()` function creates a list of rooms, each with its own set of sensors and actuators. These components are generated based on predefined lists (`sensor_types` and `actuator_types`).
# 
# 5. **Room Accessors**: The code provides functions to access specific rooms in the home by name, as well as functions to retrieve all sensors or actuators within a specified room or type.
# 
# 6. **Config Module**: A separate module named `config.py` is provided with some predefined constants (e.g., temperature thresholds, humidity thresholds).
# 
# However, there are several issues and potential improvements that can be made:
# 
# - The code could benefit from comments to explain what each section of the code does.
# 
# - There's a need for more robust error handling in functions like `get_room()` or `get_all_sensors()`. Currently, if no room or sensor is found, it simply prints an error message and returns `None`.
# 
# - Some variable names (e.g., `home`) could be more descriptive to make the code easier to understand.
# 
# - It might be beneficial to encapsulate the logic of creating a home plan into its own class, similar to how the `Room` class is implemented.
# 
# - The functions in this script seem quite specialized. Consider breaking them down further into smaller, more focused functions that each perform one specific task. This will improve code readability and maintainability.
# 
# Here's an improved version of your provided code with the above suggestions applied:
# 
# ```python
from home.logger_config import logger


class Room:
    def __init__(self, name):
        self.name = name
        self.sensors = []
        self.actuators = []

    def add_sensor(self, sensor):
        self.sensors.append(sensor)

    def add_actuator(self, actor):
        self.actuators.append(actor)

    def print_info(self):
        print(f"\n{self.name}:")
        print("Sensors:")
        for sensor in self.sensors:
            print("-", sensor.id)
        print("Actuators:")
        for actor in self.actuators:
            print("-", actor.id)


class HomePlan:
    def __init__(self):
        self.rooms = []

    def add_room(self, room):
        self.rooms.append(room)

    def get_room_by_name(self, name):
        return next((room for room in self.rooms if room.name == name), None)

    def get_all_sensors_in_room(self, room_name, sensor_type):
        room = self.get_room_by_name(room_name)
        return [sensor for sensor in room.sensors if isinstance(sensor.sensor_type, type) and issubclass(sensor.sensor_type, sensor_type)]

    def get_all_actuators_in_room(self, room_name, actuator_type):
        room = self.get_room_by_name(room_name)
        return [actor for actor in room.actuators if isinstance(actor.actuator_type, type) and issubclass(actor.actuator_type, actuator_type)]


def create_home_plan():
    home = HomePlan()

    living_room = Room("LivingRoom")
    kitchen = Room("Kitchen")
    bedroom = Room("Bedroom")

    # Adding sensors to rooms
    for room in [living_room, kitchen, bedroom]:
        room.add_sensor(IndoorTemperatureSensor(room))
        room.add_sensor(HumiditySensor(room))

    # Adding actuators to rooms
    living_room.add_actuator(Door())
    living_room.add_actuator(Light())

    return home


def main():
    home = create_home_plan()
    
    print("Home Plan:")
    for i, room in enumerate(home.rooms):
        print(f"Room {i+1}: {room.name}")
        room.print_info()

    # Get a specific room
    room = home.get_room_by_name("LivingRoom")
    if room:
        print("\nSensors in Living Room:")
        for sensor in room.sensors:
            print("-", sensor.id)
        
        print("\nActuators in Living Room:")
        for actor in room.actuators:
            print("-", actor.id)


if __name__ == "__main__":
    main()
# ```