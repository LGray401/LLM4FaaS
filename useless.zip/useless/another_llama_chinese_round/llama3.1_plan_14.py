# This is a well-structured and readable Python code for home automation. Here are some suggestions to improve it:
# 
# 1. **Consistent naming conventions**: The code uses both camelCase and underscore notation for variable and method names. It's better to stick with one convention throughout the code.
# 
# 2. **Type hints**: Add type hints for function parameters and return types to make the code more understandable and self-documenting.
# 
# 3. **Method documentation**: Document each method with a docstring that describes what it does, its parameters, and its return value (if any).
# 
# 4. **Error handling**: In some places, you're simply printing error messages when something goes wrong. Consider raising exceptions instead to make the code more robust.
# 
# 5. **Magic numbers**: Avoid using magic numbers (e.g., `1`, `15`, `25`) directly in the code. Instead, define them as constants at the top of the file or in a separate configuration module.
# 
# 6. **Use list comprehensions**: In places like `get_all_sensors()` and `get_all_actuators()`, consider using list comprehensions to make the code more concise and readable.
# 
# 7. **Consider using a database**: If you plan to store sensor readings, actuator states, or other data, consider using a database (e.g., SQLite) instead of in-memory storage.
# 
# 8. **Use a logging library**: The `logger` variable is used throughout the code. Consider using a logging library like Python's built-in `logging` module to make logging more flexible and customizable.
# 
# 9. **Consider adding unit tests**: Unit testing can help ensure that your code works as expected and catch bugs early on.
# 
# 10. **Code organization**: While the code is relatively well-organized, consider breaking it down into smaller modules or classes if it becomes too complex or difficult to maintain.
# 
# Here's an updated version of `config.py` with some suggested improvements:
# ```python
# Home automation configuration

class Config:
    TEMP_CHANGE_DURATION_WINDOW = 1  # wait duration in minutes
    TEMP_LOW = 15  # temperature threshold (Celsius)
    TEMP_HIGH = 25  # temperature threshold (Celsius)
    HUMIDITY_LOW = 30  # humidity threshold (%)
    HUMIDITY_HIGH = 50  # humidity threshold (%)
    LIGHT_INTENSITY_LOW = 300  # light intensity threshold (lux)
    LIGHT_INTENSITY_HIGH = 900  # light intensity threshold (lux)

    DAILY_ROUTINE_DURATION = 5  # daily routine duration in minutes
# ```
# And here's an updated version of the main code with some suggested improvements:
# ```python
def get_all_sensors(home, sensor_type):
    """Get all sensors of a specific type from a list of rooms."""
    return [sensor for room in home for sensor in room.sensors if sensor.sensor_type == sensor_type]

def get_all_actuators(home, actuator_type):
    """Get all actuators of a specific type from a list of rooms."""
    return [actuator for room in home for actuator in room.actuators if actuator.actuator_type == actuator_type]
# ```
# Remember to consider these suggestions when refactoring your code.