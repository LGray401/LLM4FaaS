# This code appears to be part of a home automation system, where sensors and actuators are categorized into different rooms. Here's a breakdown of the code:
# 
# **Room Class**
# 
# The `Room` class represents a room in the house, with attributes for its name, sensors, and actuators.
# 
# *   `__init__`: Initializes the Room object with a name.
# *   `add_sensor`: Adds a sensor to the room's list of sensors.
# *   `add_actuator`: Adds an actuator (e.g., device) to the room's list of actuators.
# *   `print_info`: Prints information about the room, including its name, sensors, and actuators.
# 
# **Functions**
# 
# The following functions are defined:
# 
# *   `create_room_with_components`: Creates a Room object with specified sensor and actuator types.
# *   `home_plan`: Returns a list of Room objects representing different rooms in the house. Each room is populated with various sensors and actuators based on their types.
# *   `print_home_plan`: Prints information about each room, including its name and components (sensors and actuators).
# *   `get_room`: Retrieves a specific Room object from the home plan by name.
# *   `get_room_sensors` and `get_room_actuators`: Retrieve lists of sensors or actuators for a given room by name.
# *   `get_all_sensors` and `get_all_actuators`: Return lists of all sensors or actuators of a specific type in the entire home plan.
# 
# **Config**
# 
# The `config.py` file contains constants defining various thresholds and durations used throughout the code. These values can be adjusted as needed to fine-tune the system's behavior.
# 
# Overall, this code provides a structured way to manage and interact with different components (sensors and actuators) in a smart home setup.