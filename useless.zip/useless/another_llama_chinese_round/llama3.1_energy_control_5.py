# This code defines a home automation system with various components such as sensors and actuators. The system consists of different rooms, each with its own set of sensors and actuators.
# 
# Here's how you can use this code:
# 
# 1. Create a room with specific sensors and actuators using the `create_room_with_components` function.
# 2. Define the home plan by creating multiple rooms and specifying their components.
# 3. Print out the home plan to see which rooms have which sensors and actuators.
# 4. Get a specific room from the home plan using the `get_room` function.
# 5. Retrieve all sensors or actuators of a particular type in a given room using the `get_all_sensors` and `get_all_actuators` functions.
# 
# To extend this code, you can:
# 
# * Add more types of sensors and actuators to the system.
# * Implement logic for these sensors and actuators, such as temperature control, lighting automation, etc.
# * Integrate with external systems like smart home hubs or voice assistants.
# * Visualize the data from the sensors using a dashboard or charting library.
# 
# Note that this code does not include any actual hardware or firmware components. It is purely a software design to demonstrate how a home automation system can be structured and interacted with programmatically.