# The provided code appears to be a part of a home automation system, where sensors and actuators are managed within different rooms. Here's a summary of the code:
# 
# **Room Class**
# 
# * The `Room` class represents a room in the house.
# * It has attributes for name, sensors, and actuators.
# * Methods to add sensors and actuators to the room.
# 
# **Home Plan**
# 
# * The `home_plan()` function creates a list of rooms with their respective sensors and actuators.
# * Each room is an instance of the `Room` class.
# * Sensors and actuators are instances of specific classes (e.g., `LightIntensiveSensor`, `Door`, etc.).
# 
# **Utility Functions**
# 
# * `print_home_plan(home)` prints the home plan, including all rooms and their components.
# * `get_room(home, room_name)` returns a room by its name.
# * `get_room_sensors(home, room_name)` returns a list of sensors in a specific room.
# * `get_room_actuators(home, room_name)` returns a list of actuators in a specific room.
# * `get_all_sensors(home, sensor_type)` returns a list of all instances of a specific sensor type across all rooms.
# * `get_all_actuators(home, actuator_type)` returns a list of all instances of a specific actuator type across all rooms.
# 
# **Config File**
# 
# * The `config.py` file contains constants for temperature and humidity thresholds, light intensity thresholds, and daily routine duration.
# 
# The code seems well-structured and easy to follow. However, there are a few suggestions I can make:
# 
# 1. Consider adding docstrings to the functions and classes to provide more context about what they do.
# 2. In `get_room(home, room_name)`, you might want to handle cases where the room is not found (e.g., return an error message or None).
# 3. The `Room` class has a method `print_info()`. You might want to consider making it a private method (i.e., `_print_info()`) since it's primarily for internal use.
# 4. In the `if __name__ == "__main__":` block, you have two commented-out lines. Consider removing them or uncommenting them if they're intended to be executed.
# 
# Overall, the code looks good, and with a few tweaks, it can become even more maintainable and efficient!