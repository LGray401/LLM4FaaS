# This code is a Python implementation of a smart home system. It defines various sensors and actuators, such as temperature, humidity, light intensity, door, lights, heaters, etc., and organizes them into different rooms in the house.
# 
# Here are some key features:
# 
# 1.  **Room Representation**: Each room is represented by an instance of the `Room` class. This class has methods to add sensors and actuators to the room.
# 2.  **Sensor and Actuator Classes**: There are classes for various sensors (e.g., `IndoorTemperatureSensor`, `LightIntensiveSensor`, etc.) and actuators (e.g., `Door`, `Light`, `Heater`, etc.). These classes inherit from a base class (`Sensor` or `Actuator`) and contain attributes specific to the sensor or actuator type.
# 3.  **Room Configuration**: The `create_room_with_components` function is used to create rooms with specified sensors and actuators.
# 4.  **Home Plan Management**: The `home_plan` function creates a list of rooms, each with its respective components (sensors and actuators).
# 5.  **Querying the Home Plan**: There are functions to query the home plan for specific information:
#     *   `get_room`: Retrieves a room by name.
#     *   `get_room_sensors`/`get_room_actuators`: Returns the sensors or actuators in a specific room.
#     *   `get_all_sensors`/`get_all_actuators`: Finds all instances of a particular sensor or actuator type across the home.
# 
# The provided code snippet demonstrates how to use these functions by creating a home plan and querying it for information. The `config.py` file contains threshold values and time durations that are used in the smart home system (e.g., temperature range, humidity limits, etc.).
# 
# To extend this code, you could:
# 
# 1.  Add more sensor and actuator classes.
# 2.  Implement logic to handle sensor data and perform actions based on actuator capabilities.
# 3.  Integrate external APIs for weather forecasts or other services that can enhance the smart home system's functionality.
# 
# Overall, this code serves as a foundation for building a comprehensive smart home management system in Python.