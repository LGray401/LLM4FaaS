# This is a Python script that defines a home automation system with various components, such as rooms, sensors, and actuators. Here's an overview of the code:
# 
# **Components**
# 
# The script defines several classes for different components:
# 
# 1. `Room`: represents a room in the house.
# 2. `Sensor`: base class for all sensors (e.g., temperature, humidity, light intensity).
# 3. `Actuator`: base class for all actuators (e.g., lights, heaters, fans).
# 
# **Room Creation**
# 
# The script defines a function `create_room_with_components` to create a room with specific sensors and actuators.
# 
# **Home Plan**
# 
# The script defines a function `home_plan` to generate a home plan with various rooms, each containing a set of sensors and actuators. The plan includes:
# 
# 1. Living Room
# 2. Bedroom
# 3. Kitchen
# 4. Bathroom
# 5. Balcony
# 
# Each room is created using the `create_room_with_components` function.
# 
# **Functions**
# 
# The script defines several functions to interact with the home plan:
# 
# 1. `print_home_plan`: prints out the home plan, including each room's sensors and actuators.
# 2. `get_room`: returns a specific room by name.
# 3. `get_room_sensors`: returns all sensors in a specific room.
# 4. `get_room_actuators`: returns all actuators in a specific room.
# 5. `get_all_sensors`: returns all sensors of a specific type (e.g., temperature, humidity).
# 6. `get_all_actuators`: returns all actuators of a specific type (e.g., light, heater).
# 
# **Config**
# 
# The script defines a separate file `config.py` that contains configuration settings for the home automation system, such as:
# 
# 1. Temperature thresholds
# 2. Humidity thresholds
# 3. Light intensity thresholds
# 
# These values can be adjusted in the `config.py` file to fine-tune the system's behavior.
# 
# Overall, this script provides a basic framework for building a home automation system with various components and sensors.