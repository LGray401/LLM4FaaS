# This is a Python code for home automation. It's well-structured, readable and follows professional guidelines.
# 
# Here are some specific observations:
# 
# 1. The code uses object-oriented programming (OOP) principles to model the home with rooms, sensors, and actuators.
# 2. Each component (sensor or actuator) has its own class, which is a good practice for code organization and reusability.
# 3. The `create_room_with_components` function creates a room with specified sensor and actuator types.
# 4. The `home_plan` function returns a list of rooms, each with their components.
# 5. The `get_room`, `get_room_sensors`, and `get_room_actuators` functions help to retrieve specific information from the home plan.
# 6. The `get_all_sensors` and `get_all_actuators` functions return all sensors or actuators of a specified type, regardless of their location in the home.
# 7. The code uses logging for debugging purposes.
# 
# Some minor suggestions:
# 
# 1. Consider adding docstrings to functions to explain what they do and what inputs/outputs are expected.
# 2. In some places, you have hardcoded values (e.g., `TEMP_CHANGE_DURATION_WINDOW`, `HUMIDITY_LOW`). You might consider defining these as constants in a separate file (`config.py`).
# 3. The `print_home_plan` function could be replaced with a more robust way of printing the home plan, such as using a formatter or a template engine.
# 4. In the `get_room_sensors` and `get_room_actuators` functions, you have a comment suggesting that you might want to filter by room name in a case-insensitive manner. You could consider implementing this.
# 5. Consider adding more functionality to the code, such as simulating sensor readings or actuator behavior, or integrating with external APIs.
# 
# Overall, your code is well-organized and follows good practices. It's a solid foundation for further development! 
# 
# ### The config.py file is used here:
# 
# ```python
# wait duration
TEMP_CHANGE_DURATION_WINDOW = 1

# threshold
TEMP_LOW = 15 # Celsius degree
TEMP_HIGH = 25

HUMIDITY_LOW = 30 # percentage
HUMIDITY_HIGH = 50

LIGHT_INTENSITY_LOW = 300 #lux: lumen per square meter
LIGHT_INTENSITY_HIGH = 900


DAILY_ROUTINE_DURATION = 5
# ```