# This code is for a home automation system, where you can create rooms and add various sensors and actuators to them. The system also includes some basic functions to retrieve information about the rooms, their sensors, and actuators.
# 
# Here's a breakdown of what each part does:
# 
# 1. **Classes**:
#    - `Room`: Represents a room in the house with attributes like name, sensors, and actuators.
#    - Sensor and Actuator classes are not shown here but they would represent different types of sensors (e.g., temperature, humidity, light intensity) and actuators (e.g., light, heater, door).
# 
# 2. **Functions**:
#    - `create_room_with_components`: Creates a room with the specified name and adds various sensors and actuators to it.
#    - `home_plan`: Defines rooms in the house along with their components (sensors and actuators).
#    - `print_home_plan`: Prints out information about each room, including its sensors and actuators.
#    - `get_room`, `get_room_sensors`, `get_room_actuators`, `get_all_sensors`, `get_all_actuators`: These functions are used to retrieve specific rooms or components from the home plan.
# 
# 3. **Config**: The config module contains some predefined constants like temperature and humidity thresholds, light intensity ranges, and daily routine duration. This is useful if you want to change these values without modifying your code.
# 
# **Example usage:**
# 
# You can use this system by creating a `home` object using `home_plan()` and then calling various functions on it. For example:
# 
# ```python
home = home_plan()
get_room(home, "LivingRoom")
print_home_plan(home)
all_sensors = get_all_sensors(home, "IndoorTemperature")
all_actuators = get_all_actuators(home, "Light")
# ```
# 
# Note: This code is for demonstration purposes and might need modifications to suit your specific requirements. It does not include any actual implementation of the sensor and actuator classes which should be added according to your specific use case.