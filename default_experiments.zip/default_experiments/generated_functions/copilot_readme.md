### manually generate function in Intellij IDEA
as I do not find a way to auto-generate&store copilot answer, I copy the answer from Copilot Chat in IntelliJ based on the prompt mark down files

#### steps
1. input: give answer based on the md file content.
2. refer a specific md file
3. copy and paste the answer to 'generated_functions/copilot_functions' folder