- This folder record the experiment results based on the Chinese-Version questionnaire replies.
- There are 4 smart home ideas in the questionnaire, and the participants are required to provide the feature description.
1. The first smart home idea is about the remote control of devices at home. => participants want to control specific device(s) at home remotely.
2. The second smart home idea is about letting participants make plans for routines, i.e., Morning, Leave Home and Movie Time. 
=> participants give sets of operations for each routine.
3. The third smart home idea is to adjust home environment automatically from temperature, humidity and light intensity perspectives.
=> some participants provide the thresholds for each case, some specify the triggered operations when reaching the thresholds as well. 
-> but generally, the answer is quite simple and short 
=> seems like that when users interact with openAI/smart home app, they tend to provide quite short and simple commands.
4. The fourth smart home idea is about the energy-saving mode. 
=> surprisingly, some participants get my idea. I plan to let them pay attention to both indoor and outdoor sensors and trigger some operation accordingly.
=> other participants also give out reasonable answers, only not including the outdoor sensor part.


[//]: # (todo: get students' replies, i.e., in English or German=> detail everything in another folder)

There is a prompt markdown file in each function idea folder, only need to replace the 'Function Description' then get reply from LLM platforms.



